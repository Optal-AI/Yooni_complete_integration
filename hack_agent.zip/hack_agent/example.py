"""Example usage of the agent."""

from agent import Agent
from tools import CalculatorTool, FileReadTool, FileWriteTool, ListDirectoryTool


def example_usage():
    """Demonstrate agent usage."""
    # Create agent with tools
    tools = [
        CalculatorTool(),
        FileReadTool(),
        FileWriteTool(),
        ListDirectoryTool()
    ]
    
    agent = Agent(tools=tools)
    
    print("=== Example 1: Calculator ===\n")
    agent.run("What is 25 * 4?")
    
    print("\n=== Example 2: Calculator (subtract) ===\n")
    agent.run("100 - 37")
    
    print("\n=== Example 3: List Directory ===\n")
    agent.run("list directory .")
    
    print("\n=== Example 4: Read File ===\n")
    agent.run('read file "README.md"')


if __name__ == "__main__":
    example_usage()

