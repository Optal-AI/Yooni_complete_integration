# Research Paper Evaluator Agent

An AI-powered research paper evaluation agent that can evaluate papers from URLs and discover relevant papers for your research theme.

## Features

- **Paper Evaluation**: Evaluate papers from URLs (PDF or web pages) for relevance to your research theme
- **Paper Discovery**: Automatically find and evaluate relevant papers from arXiv
- **Quality Assessment**: Get scores for relevance, quality, and literature review suitability
- **Summarization**: Automatic paper summaries
- **Web Interface**: Simple, modern web frontend
- **REST API**: Backend API for integration

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up your OpenAI API key (required for evaluation and summarization):
```bash
# Create .env file
echo "OPENAI_API_KEY=your_api_key_here" > .env
```

Or set it as an environment variable:
```bash
export OPENAI_API_KEY=your_api_key_here
```

## Usage

### Quick Start (Both Servers)

**Easiest way - Use the start script:**
```bash
./start.sh
```

This will start both:
- **Backend (Flask)** on port 5001
- **Frontend (React)** on port 3000

Then open: **http://localhost:3000**

To stop both servers:
```bash
./stop.sh
```

### Manual Start

**You need to run TWO servers:**

1. **Start the Backend (Flask API):**
```bash
python3 app.py
```
or
```bash
python app.py
```
The backend runs on **port 5001** by default.

2. **Start the Frontend (React):**
In a separate terminal:
```bash
npm install  # First time only
npm run dev
```
The frontend runs on **port 3000** by default.

3. **Open your browser:**
```
http://localhost:3000
```

**Note:** The frontend communicates with the backend API. Both must be running for the application to work properly.

**Note:** If port 5001 is in use, you can specify a different port:
```bash
PORT=8080 python app.py
```

3. Use the interface to:
   - Set your research theme
   - Evaluate papers from URLs
   - Find and evaluate relevant papers

### API Usage

#### Evaluate a Paper from URL
```bash
curl -X POST http://localhost:5000/api/evaluate-paper \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://arxiv.org/pdf/2301.00001.pdf",
    "research_theme": "Machine Learning for Healthcare"
  }'
```

#### Find Relevant Papers
```bash
curl -X POST http://localhost:5000/api/find-papers \
  -H "Content-Type: application/json" \
  -d '{
    "research_topic": "transformer models",
    "research_theme": "NLP research",
    "max_papers": 5
  }'
```

### Python API

```python
from research_agent import ResearchAgent

# Initialize agent with research theme
agent = ResearchAgent(research_theme="Machine Learning for Healthcare")

# Evaluate a paper from URL
result = agent.evaluate_paper_from_url(
    "https://arxiv.org/pdf/2301.00001.pdf"
)

# Find and evaluate relevant papers
results = agent.find_and_evaluate_papers(
    "transformer models in NLP",
    max_papers=5
)
```

## Architecture

- `research_agent.py` - Main research agent class
- `research_tools.py` - Paper evaluation, search, and summarization tools
- `app.py` - Flask backend API
- `static/index.html` - Web frontend
- `agent.py` - Base agent framework
- `tools.py` - Base tool system

## Evaluation Criteria

The agent evaluates papers on:
- **Relevance Score** (1-10): How relevant is the paper to your research theme?
- **Quality Score** (1-10): What is the quality and rigor of the paper?
- **Literature Review Score** (1-10): How useful is it for literature review?
- **Overall Recommendation**: Yes/No for including in your research

## Supported Paper Sources

- arXiv (PDF and web pages)
- Direct PDF URLs
- Web pages with paper content
- Any URL that points to a PDF or paper content

## Notes

- The agent uses OpenAI's GPT models for evaluation and summarization
- PDF extraction may take time for large papers
- Paper search uses arXiv API (free, no API key required)
- Evaluation quality depends on the clarity of your research theme

