"""Writing evaluation and improvement tools."""

import os
import PyPDF2
import io
import openai
from dotenv import load_dotenv

load_dotenv()

# Initialize OpenAI client
openai.api_key = os.getenv('OPENAI_API_KEY')


def extract_text_from_pdf(file_path: str) -> str:
    """Extract text content from a PDF file."""
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text
    except Exception as e:
        raise Exception(f"Failed to extract text from PDF: {str(e)}")


def extract_text_from_docx(file_path: str) -> str:
    """Extract text content from a DOCX file."""
    try:
        from docx import Document
        doc = Document(file_path)
        text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
        return text
    except ImportError:
        raise Exception("python-docx library is required for DOCX files. Install it with: pip install python-docx")
    except Exception as e:
        raise Exception(f"Failed to extract text from DOCX: {str(e)}")


def extract_rubric_content(file_path: str, file_type: str) -> str:
    """Extract text content from rubric file (PDF or DOCX)."""
    if file_type.lower() == 'pdf':
        return extract_text_from_pdf(file_path)
    elif file_type.lower() in ['docx', 'doc']:
        return extract_text_from_docx(file_path)
    else:
        raise Exception(f"Unsupported file type: {file_type}")


def get_default_rubric() -> str:
    """Get default academic rubric for evaluating research papers and publications."""
    # Try to read from file first
    rubric_file_path = os.path.join(os.path.dirname(__file__), 'default_rubric.txt')
    try:
        if os.path.exists(rubric_file_path):
            with open(rubric_file_path, 'r', encoding='utf-8') as f:
                return f.read()
    except Exception as e:
        print(f"Warning: Could not read default_rubric.txt: {e}")
    
    # Fallback to hardcoded rubric if file doesn't exist
    return """ACADEMIC RESEARCH PAPER EVALUATION RUBRIC

Example Performance Levels

This rubric evaluates academic writing and research papers based on the following criteria:

LEVEL: Excellent
- Content and Analysis: Demonstrates a full understanding with original, insightful analysis; claims are fully supported.
- Organization: Paper has a clear and logical structure; transitions are seamless.
- Mechanics: Free of errors in grammar, spelling, and punctuation; language is precise.

LEVEL: Good
- Content and Analysis: Shows a solid understanding of the material with relevant analysis; most points are supported.
- Organization: Structure is mostly logical, with few disjointed sections.
- Mechanics: Minor errors in mechanics are present but do not significantly impede understanding.

LEVEL: Needs Improvement
- Content and Analysis: Demonstrates a partial understanding; analysis is limited and support is weak or inconsistent.
- Organization: Organization is sometimes unclear; transitions may be weak or missing.
- Mechanics: Multiple errors in mechanics distract the reader.

EVALUATION CRITERIA:

1. CONTENT AND ANALYSIS
   - Depth of understanding of the topic
   - Originality and insightfulness of analysis
   - Quality and relevance of supporting evidence
   - Strength and consistency of claims

2. ORGANIZATION
   - Clarity and logic of structure
   - Effectiveness of transitions between sections
   - Coherence and flow of ideas
   - Overall paper structure

3. MECHANICS
   - Grammar, spelling, and punctuation accuracy
   - Language precision and clarity
   - Consistency in formatting
   - Professional writing standards

Each paper should be evaluated based on these three main criteria, with performance levels ranging from Excellent to Needs Improvement. The evaluation should provide specific feedback for areas of strength and areas needing improvement, focusing on academic rigor and scholarly writing standards."""


def evaluate_writing_against_rubric(writing_content: str, rubric_content: str = None) -> dict:
    """Evaluate writing against a rubric using OpenAI."""
    if not rubric_content:
        rubric_content = get_default_rubric()
    
    try:
        client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
        
        prompt = f"""You are an expert writing evaluator. Evaluate the following writing sample against the provided rubric.

RUBRIC:
{rubric_content}

WRITING TO EVALUATE:
{writing_content}

Please provide:
1. A score for each rubric criterion (out of the maximum points for that criterion)
2. An overall total score
3. Specific feedback for each criterion explaining strengths and areas for improvement
4. A brief summary of the evaluation

Format your response as JSON with the following structure:
{{
    "sections": [
        {{
            "name": "Criterion Name",
            "score": <number>,
            "maxScore": <number>,
            "feedback": "<detailed feedback>"
        }}
    ],
    "totalScore": <number>,
    "maxTotalScore": <number>,
    "summary": "<overall evaluation summary>"
}}"""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert writing evaluator. Always respond with valid JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            response_format={"type": "json_object"}
        )
        
        import json
        result = json.loads(response.choices[0].message.content)
        
        # Ensure the response has the expected structure
        if "sections" not in result:
            # Try to parse if it's in a different format
            result = {
                "sections": result.get("sections", []),
                "totalScore": result.get("totalScore", 0),
                "maxTotalScore": result.get("maxTotalScore", 100),
                "summary": result.get("summary", "Evaluation completed.")
            }
        
        return {
            "success": True,
            "evaluation": result
        }
        
    except Exception as e:
        return {
            "success": False,
            "error": f"Failed to evaluate writing: {str(e)}"
        }


def rewrite_writing_with_rubric(writing_content: str, rubric_content: str = None, evaluation: dict = None) -> dict:
    """Rewrite writing to improve scores based on rubric using OpenAI."""
    if not rubric_content:
        rubric_content = get_default_rubric()
    
    try:
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            return {
                "success": False,
                "error": "OpenAI API key not found. Please set OPENAI_API_KEY in your .env file."
            }
        
        client = openai.OpenAI(api_key=api_key)
        
        # Build evaluation context if provided
        evaluation_context = ""
        if evaluation and "sections" in evaluation:
            evaluation_context = "\n\nCURRENT EVALUATION:\n"
            for section in evaluation.get("sections", []):
                evaluation_context += f"- {section.get('name', 'Unknown')}: {section.get('score', 0)}/{section.get('maxScore', 0)} - {section.get('feedback', '')}\n"
        
        prompt = f"""You are an expert writing tutor. Rewrite the following writing sample to improve its scores according to the provided rubric, while maintaining the author's authentic voice and writing style.

RUBRIC:
{rubric_content}
{evaluation_context}

ORIGINAL WRITING:
{writing_content}

Please rewrite the writing to:
1. Address all feedback points from the evaluation (if provided)
2. Improve scores in all rubric criteria
3. Maintain the author's original voice and style
4. Keep the same general structure and flow
5. Enhance clarity, depth, and argumentation
6. Fix any grammar or mechanical issues
7. Add or improve citations if needed
8. Ensure the writing meets academic standards

Provide ONLY the improved version of the writing. Do not include any meta-commentary, explanations, or notes - just provide the rewritten text."""

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert writing tutor. Rewrite writing to improve it according to rubrics while preserving the author's voice. Always provide only the rewritten text, no explanations."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=4000
        )
        
        improved_content = response.choices[0].message.content.strip()
        
        # Remove any potential meta-commentary that might have been added
        # Sometimes the model adds explanations, so we clean it up
        if improved_content.startswith("Here is the improved version:"):
            improved_content = improved_content.split("Here is the improved version:", 1)[1].strip()
        if improved_content.startswith("Improved version:"):
            improved_content = improved_content.split("Improved version:", 1)[1].strip()
        if improved_content.startswith("**Improved Writing:**"):
            improved_content = improved_content.split("**Improved Writing:**", 1)[1].strip()
        
        # Re-evaluate the improved version
        improved_evaluation = evaluate_writing_against_rubric(improved_content, rubric_content)
        
        return {
            "success": True,
            "improved_content": improved_content,
            "improved_evaluation": improved_evaluation.get("evaluation", {}) if improved_evaluation.get("success") else None
        }
        
    except Exception as e:
        error_msg = str(e)
        if "API key" in error_msg or "authentication" in error_msg.lower():
            return {
                "success": False,
                "error": "OpenAI API key is invalid or missing. Please check your .env file."
            }
        return {
            "success": False,
            "error": f"Failed to rewrite writing: {error_msg}"
        }

