"""Core agent implementation."""

from typing import List, Dict, Any, Optional
import json
from tools import Tool


class Agent:
    """Main agent class that can use tools and make decisions."""
    
    def __init__(self, tools: Optional[List[Tool]] = None, max_iterations: int = 10):
        """
        Initialize the agent.
        
        Args:
            tools: List of tools the agent can use
            max_iterations: Maximum number of tool calls per task
        """
        self.tools = {tool.name: tool for tool in (tools or [])}
        self.max_iterations = max_iterations
        self.conversation_history = []
    
    def get_available_tools(self) -> List[Dict[str, Any]]:
        """Get list of available tools in dictionary format."""
        return [tool.to_dict() for tool in self.tools.values()]
    
    def execute_tool(self, tool_name: str, parameters: Dict[str, Any]) -> Any:
        """
        Execute a tool with given parameters.
        
        Args:
            tool_name: Name of the tool to execute
            parameters: Parameters to pass to the tool
            
        Returns:
            Result from tool execution
        """
        if tool_name not in self.tools:
            return {"error": f"Tool '{tool_name}' not found"}
        
        tool = self.tools[tool_name]
        try:
            result = tool.execute(**parameters)
            return result
        except Exception as e:
            return {"error": f"Tool execution failed: {str(e)}"}
    
    def parse_user_input(self, user_input: str) -> Dict[str, Any]:
        """
        Parse user input to determine intent and extract parameters.
        This is a simple parser - in a real implementation, you'd use an LLM.
        
        Args:
            user_input: User's input string
            
        Returns:
            Dictionary with 'action' and 'parameters'
        """
        user_input_lower = user_input.lower().strip()
        
        # Simple pattern matching for demonstration
        # In production, you'd use an LLM to parse this
        
        # Calculator patterns
        if any(op in user_input_lower for op in ['+', 'add', 'plus']):
            return self._parse_calculation(user_input, 'add')
        elif any(op in user_input_lower for op in ['-', 'subtract', 'minus']):
            return self._parse_calculation(user_input, 'subtract')
        elif any(op in user_input_lower for op in ['*', 'multiply', 'times', 'x']):
            return self._parse_calculation(user_input, 'multiply')
        elif any(op in user_input_lower for op in ['/', 'divide', 'divided by']):
            return self._parse_calculation(user_input, 'divide')
        
        # File operations
        elif 'read' in user_input_lower and 'file' in user_input_lower:
            return self._parse_file_read(user_input)
        elif 'write' in user_input_lower and 'file' in user_input_lower:
            return self._parse_file_write(user_input)
        elif 'list' in user_input_lower and ('directory' in user_input_lower or 'dir' in user_input_lower):
            return self._parse_list_directory(user_input)
        
        # Default: try to interpret as a question or general query
        return {
            "action": "respond",
            "parameters": {"message": user_input}
        }
    
    def _parse_calculation(self, user_input: str, operation: str) -> Dict[str, Any]:
        """Parse calculation input."""
        import re
        # Try to extract numbers
        numbers = re.findall(r'-?\d+\.?\d*', user_input)
        if len(numbers) >= 2:
            return {
                "action": "use_tool",
                "tool": "calculator",
                "parameters": {
                    "operation": operation,
                    "a": float(numbers[0]),
                    "b": float(numbers[1])
                }
            }
        return {
            "action": "respond",
            "parameters": {"message": f"I couldn't parse the numbers for {operation}. Please provide two numbers."}
        }
    
    def _parse_file_read(self, user_input: str) -> Dict[str, Any]:
        """Parse file read request."""
        import re
        # Try to extract filepath
        # Look for quoted strings or paths
        match = re.search(r'["\']([^"\']+)["\']|(\S+\.\w+)', user_input)
        if match:
            filepath = match.group(1) or match.group(2)
            return {
                "action": "use_tool",
                "tool": "read_file",
                "parameters": {"filepath": filepath}
            }
        return {
            "action": "respond",
            "parameters": {"message": "Please specify a file path to read."}
        }
    
    def _parse_file_write(self, user_input: str) -> Dict[str, Any]:
        """Parse file write request."""
        # This is simplified - in production use LLM
        return {
            "action": "respond",
            "parameters": {"message": "File write parsing not fully implemented. Please use the tool directly."}
        }
    
    def _parse_list_directory(self, user_input: str) -> Dict[str, Any]:
        """Parse list directory request."""
        import re
        import os
        # Try to extract directory path
        match = re.search(r'["\']([^"\']+)["\']|(\S+)', user_input)
        if match:
            directory = match.group(1) or match.group(2)
            # Default to current directory if not specified
            if not os.path.isabs(directory) and not os.path.exists(directory):
                directory = "."
            return {
                "action": "use_tool",
                "tool": "list_directory",
                "parameters": {"directory": directory}
            }
        return {
            "action": "use_tool",
            "tool": "list_directory",
            "parameters": {"directory": "."}
        }
    
    def process(self, user_input: str) -> Dict[str, Any]:
        """
        Process user input and return a response.
        
        Args:
            user_input: User's input string
            
        Returns:
            Dictionary with response information
        """
        # Add to conversation history
        self.conversation_history.append({"role": "user", "content": user_input})
        
        # Parse input
        parsed = self.parse_user_input(user_input)
        
        response = {
            "input": user_input,
            "parsed": parsed,
            "result": None
        }
        
        if parsed["action"] == "use_tool":
            tool_name = parsed["tool"]
            parameters = parsed["parameters"]
            result = self.execute_tool(tool_name, parameters)
            response["result"] = result
            response["tool_used"] = tool_name
            
            # Format response message
            if "error" in result:
                message = f"Error: {result['error']}"
            else:
                message = f"Tool '{tool_name}' executed successfully. Result: {json.dumps(result, indent=2)}"
        else:
            message = parsed["parameters"].get("message", "I'm not sure how to help with that.")
            response["result"] = {"message": message}
        
        # Add to conversation history
        self.conversation_history.append({"role": "assistant", "content": message})
        
        return response
    
    def run(self, user_input: str, verbose: bool = True) -> Any:
        """
        Run the agent with user input.
        
        Args:
            user_input: User's input string
            verbose: Whether to print the response
            
        Returns:
            The result from processing
        """
        result = self.process(user_input)
        
        if verbose:
            print(f"\n🤖 Agent Response:")
            print(f"Input: {result['input']}")
            if 'tool_used' in result:
                print(f"Tool used: {result['tool_used']}")
            print(f"Result:\n{json.dumps(result['result'], indent=2)}")
            print()
        
        return result
    
    def interactive_mode(self):
        """Run the agent in interactive mode."""
        print("🤖 Agent is ready! Type 'quit' or 'exit' to stop.")
        print(f"Available tools: {', '.join(self.tools.keys())}\n")
        
        while True:
            try:
                user_input = input("You: ").strip()
                
                if user_input.lower() in ['quit', 'exit', 'q']:
                    print("Goodbye!")
                    break
                
                if not user_input:
                    continue
                
                self.run(user_input, verbose=True)
                
            except KeyboardInterrupt:
                print("\nGoodbye!")
                break
            except Exception as e:
                print(f"Error: {e}")

