"""Visualization utilities for research paper evaluations."""

from typing import List, Dict, Any
import json


def generate_radar_chart_data(evaluation: Dict[str, Any]) -> Dict[str, Any]:
    """Generate data for a radar chart showing all evaluation dimensions."""
    if not evaluation:
        return {}
    
    labels = [
        "Relevance",
        "Quality",
        "Literature Review",
        "Methodological Alignment",
        "Contribution Significance"
    ]
    
    scores = [
        evaluation.get("relevance_score", 0),
        evaluation.get("quality_score", 0),
        evaluation.get("literature_review_score", 0),
        evaluation.get("methodological_alignment_score", 0),
        evaluation.get("contribution_significance_score", 0)
    ]
    
    return {
        "labels": labels,
        "datasets": [{
            "label": "Evaluation Scores",
            "data": scores,
            "backgroundColor": "rgba(102, 126, 234, 0.2)",
            "borderColor": "rgba(102, 126, 234, 1)",
            "pointBackgroundColor": "rgba(102, 126, 234, 1)",
            "pointBorderColor": "#fff",
            "pointHoverBackgroundColor": "#fff",
            "pointHoverBorderColor": "rgba(102, 126, 234, 1)"
        }],
        "max": 10
    }


def generate_comparison_chart_data(evaluated_papers: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate data for comparing multiple papers."""
    if not evaluated_papers:
        return {}
    
    papers = []
    relevance_scores = []
    quality_scores = []
    literature_scores = []
    match_percentages = []
    
    for paper in evaluated_papers:
        eval_data = paper.get("evaluation", {})
        if eval_data:
            title = paper.get("paper_info", {}).get("title", "Unknown")[:50]
            papers.append(title)
            relevance_scores.append(eval_data.get("relevance_score", 0))
            quality_scores.append(eval_data.get("quality_score", 0))
            literature_scores.append(eval_data.get("literature_review_score", 0))
            match_percentages.append(eval_data.get("overall_match_percentage", 0))
    
    return {
        "labels": papers,
        "datasets": [
            {
                "label": "Relevance Score",
                "data": relevance_scores,
                "backgroundColor": "rgba(102, 126, 234, 0.6)",
                "borderColor": "rgba(102, 126, 234, 1)",
                "borderWidth": 1
            },
            {
                "label": "Quality Score",
                "data": quality_scores,
                "backgroundColor": "rgba(118, 75, 162, 0.6)",
                "borderColor": "rgba(118, 75, 162, 1)",
                "borderWidth": 1
            },
            {
                "label": "Literature Review Score",
                "data": literature_scores,
                "backgroundColor": "rgba(255, 159, 64, 0.6)",
                "borderColor": "rgba(255, 159, 64, 1)",
                "borderWidth": 1
            }
        ]
    }


def generate_match_percentage_chart(evaluated_papers: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate data for match percentage comparison chart."""
    if not evaluated_papers:
        return {}
    
    papers = []
    percentages = []
    colors = []
    
    for paper in evaluated_papers:
        eval_data = paper.get("evaluation", {})
        if eval_data:
            title = paper.get("paper_info", {}).get("title", "Unknown")[:40]
            papers.append(title)
            percentage = eval_data.get("overall_match_percentage", 0)
            percentages.append(percentage)
            
            # Color based on match percentage
            if percentage >= 70:
                colors.append("rgba(40, 167, 69, 0.8)")  # Green
            elif percentage >= 50:
                colors.append("rgba(255, 193, 7, 0.8)")  # Yellow
            else:
                colors.append("rgba(220, 53, 69, 0.8)")  # Red
    
    return {
        "labels": papers,
        "datasets": [{
            "label": "Match Percentage",
            "data": percentages,
            "backgroundColor": colors,
            "borderColor": [c.replace("0.8", "1") for c in colors],
            "borderWidth": 2
        }]
    }


def generate_score_breakdown_data(evaluation: Dict[str, Any]) -> Dict[str, Any]:
    """Generate data for score breakdown visualization."""
    if not evaluation:
        return {}
    
    scores = {
        "Relevance": evaluation.get("relevance_score", 0),
        "Quality": evaluation.get("quality_score", 0),
        "Literature Review": evaluation.get("literature_review_score", 0),
        "Methodological Alignment": evaluation.get("methodological_alignment_score", 0),
        "Contribution Significance": evaluation.get("contribution_significance_score", 0),
        "Confidence": evaluation.get("confidence_score", 0)
    }
    
    return {
        "labels": list(scores.keys()),
        "data": list(scores.values()),
        "colors": [
            "rgba(102, 126, 234, 0.8)",
            "rgba(118, 75, 162, 0.8)",
            "rgba(255, 159, 64, 0.8)",
            "rgba(75, 192, 192, 0.8)",
            "rgba(153, 102, 255, 0.8)",
            "rgba(255, 99, 132, 0.8)"
        ]
    }

