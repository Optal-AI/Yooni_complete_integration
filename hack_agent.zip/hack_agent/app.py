"""Flask backend API for research agent."""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import tempfile
from dotenv import load_dotenv
from research_agent import ResearchAgent
from visualizations import (
    generate_radar_chart_data,
    generate_comparison_chart_data,
    generate_match_percentage_chart,
    generate_score_breakdown_data
)
from writing_tools import (
    extract_rubric_content,
    get_default_rubric,
    evaluate_writing_against_rubric,
    rewrite_writing_with_rubric
)

# Load environment variables
load_dotenv()

app = Flask(__name__, static_folder='static')
CORS(app)  # Enable CORS for frontend

# Global agent instance (can be initialized per request if needed)
agent = None


def get_agent(research_theme: str = "") -> ResearchAgent:
    """Get or create agent instance."""
    global agent
    if agent is None or (research_theme and agent.research_theme != research_theme):
        agent = ResearchAgent(research_theme=research_theme)
    return agent


@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({"status": "ok", "message": "Research Agent API is running"})


@app.route('/api/evaluate-paper', methods=['POST'])
def evaluate_paper():
    """Evaluate a paper from URL."""
    try:
        data = request.json
        url = data.get('url')
        research_theme = data.get('research_theme', '')
        
        if not url:
            return jsonify({"error": "URL is required"}), 400
        
        agent = get_agent(research_theme=research_theme)
        result = agent.evaluate_paper_from_url(url, research_theme)
        
        if "error" in result:
            return jsonify(result), 400
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/find-papers', methods=['POST'])
def find_papers():
    """Find and evaluate papers for a research topic."""
    try:
        data = request.json
        research_topic = data.get('research_topic')
        research_theme = data.get('research_theme', research_topic or '')
        max_papers = data.get('max_papers', 5)
        
        if not research_topic:
            return jsonify({"error": "research_topic is required"}), 400
        
        agent = get_agent(research_theme=research_theme)
        result = agent.find_and_evaluate_papers(research_topic, max_papers=max_papers)
        
        if "error" in result:
            return jsonify(result), 400
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/evaluate-pdf', methods=['POST'])
def evaluate_pdf():
    """Evaluate a paper from uploaded PDF."""
    try:
        if 'pdf' not in request.files:
            return jsonify({"error": "PDF file is required"}), 400
        
        pdf_file = request.files['pdf']
        if pdf_file.filename == '':
            return jsonify({"error": "No file selected"}), 400
        
        option = request.form.get('option', 'theme')
        research_theme = request.form.get('research_theme', '')
        max_papers = int(request.form.get('max_papers', 5))
        
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
            pdf_file.save(tmp_file.name)
            tmp_path = tmp_file.name
        
        try:
            # Convert to file:// URL for the agent
            pdf_url = f"file://{tmp_path}"
            
            agent = get_agent(research_theme=research_theme)
            
            if option == 'theme':
                # Evaluate PDF against theme
                if not research_theme:
                    return jsonify({"error": "Research theme is required"}), 400
                
                result = agent.evaluate_paper_from_url(pdf_url, research_theme)
                
                if "error" in result:
                    return jsonify(result), 400
                
                # Add filename to result
                result['paper_info']['filename'] = pdf_file.filename
                
                return jsonify(result), 200
            else:
                # Find relevant papers based on PDF content
                # First extract content from PDF
                content_result = agent.execute_tool("extract_paper_content", {"url": pdf_url})
                
                if "error" in content_result:
                    return jsonify(content_result), 400
                
                # Use PDF title/abstract as search query
                pdf_title = content_result.get("title", "research paper")
                pdf_abstract = content_result.get("abstract", "")
                
                # Create search query from PDF content
                search_query = f"{pdf_title} {pdf_abstract[:200]}"
                
                # Find and evaluate papers
                result = agent.find_and_evaluate_papers(search_query, max_papers=max_papers)
                
                if "error" in result:
                    return jsonify(result), 400
                
                # Add PDF info to result
                result['source_pdf'] = {
                    'filename': pdf_file.filename,
                    'title': pdf_title,
                    'abstract': pdf_abstract[:500]
                }
                
                return jsonify(result), 200
                
        finally:
            # Clean up temporary file
            try:
                os.unlink(tmp_path)
            except:
                pass
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/visualization-data', methods=['POST'])
def get_visualization_data():
    """Get visualization data for evaluation results."""
    try:
        data = request.json
        evaluation = data.get('evaluation')
        evaluated_papers = data.get('evaluated_papers', [])
        
        result = {}
        
        # Single paper evaluation - radar chart and score breakdown
        if evaluation:
            result['radar_chart'] = generate_radar_chart_data(evaluation)
            result['score_breakdown'] = generate_score_breakdown_data(evaluation)
        
        # Multiple papers - comparison charts
        if evaluated_papers:
            result['comparison_chart'] = generate_comparison_chart_data(evaluated_papers)
            result['match_percentage_chart'] = generate_match_percentage_chart(evaluated_papers)
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/upload-rubric', methods=['POST'])
def upload_rubric():
    """Upload and extract rubric content from PDF/DOCX file."""
    try:
        if 'rubric' not in request.files:
            return jsonify({"error": "Rubric file is required"}), 400
        
        rubric_file = request.files['rubric']
        if rubric_file.filename == '':
            return jsonify({"error": "No file selected"}), 400
        
        # Determine file type
        filename = rubric_file.filename.lower()
        if filename.endswith('.pdf'):
            file_type = 'pdf'
        elif filename.endswith(('.docx', '.doc')):
            file_type = 'docx'
        else:
            return jsonify({"error": "Unsupported file type. Please upload PDF or DOCX."}), 400
        
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=f'.{file_type}') as tmp_file:
            rubric_file.save(tmp_file.name)
            tmp_path = tmp_file.name
        
        try:
            # Extract rubric content
            rubric_content = extract_rubric_content(tmp_path, file_type)
            
            return jsonify({
                "success": True,
                "rubric_content": rubric_content,
                "filename": rubric_file.filename
            }), 200
            
        finally:
            # Clean up temporary file
            try:
                os.unlink(tmp_path)
            except:
                pass
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/evaluate-writing', methods=['POST'])
def evaluate_writing():
    """Evaluate writing against a rubric (or default rubric if none provided)."""
    try:
        data = request.json
        writing_content = data.get('writing_content')
        rubric_content = data.get('rubric_content')  # Optional - will use default if not provided
        
        if not writing_content:
            return jsonify({"error": "Writing content is required"}), 400
        
        # Evaluate writing
        result = evaluate_writing_against_rubric(writing_content, rubric_content)
        
        if not result.get("success"):
            return jsonify(result), 400
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/improve-writing', methods=['POST'])
def improve_writing():
    """Rewrite writing to improve scores based on rubric."""
    try:
        data = request.json
        writing_content = data.get('writing_content')
        rubric_content = data.get('rubric_content')  # Optional - will use default if not provided
        evaluation = data.get('evaluation')  # Optional - current evaluation results
        
        if not writing_content:
            return jsonify({"error": "Writing content is required"}), 400
        
        # Rewrite writing
        result = rewrite_writing_with_rubric(writing_content, rubric_content, evaluation)
        
        if not result.get("success"):
            return jsonify(result), 400
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/api/default-rubric', methods=['GET'])
def get_default_rubric_endpoint():
    """Get the default rubric for evaluating paragraphs."""
    try:
        return jsonify({
            "success": True,
            "rubric_content": get_default_rubric()
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/')
def index():
    """API root endpoint - frontend is served separately on port 3000."""
    return jsonify({
        "message": "Research Agent API",
        "status": "running",
        "frontend": "Please access the frontend at http://localhost:3000",
        "api_docs": {
            "health": "GET /api/health",
            "evaluate_paper": "POST /api/evaluate-paper",
            "evaluate_pdf": "POST /api/evaluate-pdf",
            "find_papers": "POST /api/find-papers",
            "visualization_data": "POST /api/visualization-data",
            "upload_rubric": "POST /api/upload-rubric",
            "evaluate_writing": "POST /api/evaluate-writing",
            "improve_writing": "POST /api/improve-writing",
            "default_rubric": "GET /api/default-rubric"
        }
    })


if __name__ == '__main__':
    port = int(os.getenv('PORT', 5001))  # Changed default to 5001 to avoid conflict
    debug = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    print(f"🚀 Starting Research Paper Evaluator on http://localhost:{port}")
    print(f"📱 Open http://localhost:{port} in your browser")
    app.run(host='0.0.0.0', port=port, debug=debug)

