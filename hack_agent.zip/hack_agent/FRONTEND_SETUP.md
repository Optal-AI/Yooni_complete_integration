# Frontend Setup Guide

The frontend is a React + TypeScript application using Vite as the build tool.

## Prerequisites

- Node.js 18+ and npm/yarn
- Python 3.8+ (for backend)

## Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start the Flask backend** (in one terminal):
   ```bash
   python3 app.py
   ```
   The backend will run on `http://localhost:5001`

3. **Start the frontend dev server** (in another terminal):
   ```bash
   npm run dev
   ```
   The frontend will run on `http://localhost:3000` and proxy API requests to the backend.

## Development

- **Frontend dev server**: `npm run dev` (runs on port 3000)
- **Backend server**: `python3 app.py` (runs on port 5001)
- **Build for production**: `npm run build` (outputs to `dist/` folder)

## Environment Variables

Create a `.env` file in the root directory (if not already present):
```
OPENAI_API_KEY=your_openai_api_key_here
```

For frontend-specific environment variables, create a `.env.local` file:
```
VITE_API_BASE_URL=http://localhost:5001
```

## Production Build

To build the frontend for production:

```bash
npm run build
```

The built files will be in the `dist/` directory. The Flask backend is configured to serve these files when running in production mode.

## Features

- ✅ Research paper upload and evaluation
- ✅ PDF analysis against research themes
- ✅ Paper library management
- ✅ Citation generation (APA, MLA, Chicago)
- ✅ Relevance scoring and recommendations
- ✅ Paper search and filtering

## API Integration

The frontend communicates with the Flask backend through the following endpoints:

- `POST /api/evaluate-pdf` - Upload and evaluate a PDF
- `POST /api/evaluate-paper` - Evaluate a paper from URL
- `POST /api/find-papers` - Find relevant papers for a topic
- `GET /api/health` - Health check

All API calls are configured in `src/config/api.ts` and services are in `src/services/`.

