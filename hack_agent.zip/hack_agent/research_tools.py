"""Research paper evaluation and search tools."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import requests
import re
from urllib.parse import urlparse
import PyPDF2
import io
from bs4 import BeautifulSoup
import arxiv
from tools import Tool


class PaperContentTool(Tool):
    """Tool to extract content from paper URLs (PDF or web pages)."""
    
    @property
    def name(self) -> str:
        return "extract_paper_content"
    
    @property
    def description(self) -> str:
        return "Extracts text content from a paper URL (supports PDF and web pages)"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL of the paper to extract"
                }
            },
            "required": ["url"]
        }
    
    def execute(self, url: str, **kwargs) -> Dict[str, Any]:
        """Extract content from paper URL."""
        try:
            # Check if it's a PDF
            if url.lower().endswith('.pdf') or 'pdf' in url.lower():
                return self._extract_from_pdf(url)
            else:
                return self._extract_from_web(url)
        except Exception as e:
            return {"error": f"Failed to extract content: {str(e)}"}
    
    def _extract_from_pdf(self, url: str) -> Dict[str, Any]:
        """Extract text from PDF URL or local file."""
        try:
            # Handle file:// URLs (local files)
            if url.startswith('file://'):
                file_path = url.replace('file://', '')
                with open(file_path, 'rb') as f:
                    pdf_file = io.BytesIO(f.read())
            else:
                # Handle HTTP URLs
                response = requests.get(url, timeout=30, headers={
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                response.raise_for_status()
                pdf_file = io.BytesIO(response.content)
            
            pdf_reader = PyPDF2.PdfReader(pdf_file)
            
            text_content = []
            metadata = {}
            
            # Extract metadata
            if pdf_reader.metadata:
                metadata = {
                    "title": pdf_reader.metadata.get('/Title', ''),
                    "author": pdf_reader.metadata.get('/Author', ''),
                    "subject": pdf_reader.metadata.get('/Subject', '')
                }
            
            # Extract text from all pages
            for page_num, page in enumerate(pdf_reader.pages):
                text = page.extract_text()
                if text.strip():
                    text_content.append(text)
            
            full_text = "\n\n".join(text_content)
            
            # Extract title, abstract, and key sections
            title = self._extract_title(full_text)
            abstract = self._extract_abstract(full_text)
            introduction = self._extract_section(full_text, "introduction")
            conclusion = self._extract_section(full_text, "conclusion")
            
            # Create enhanced content with key sections prioritized
            enhanced_content = f"Title: {title}\n\n"
            if abstract:
                enhanced_content += f"Abstract: {abstract}\n\n"
            if introduction:
                enhanced_content += f"Introduction: {introduction}\n\n"
            if conclusion:
                enhanced_content += f"Conclusion: {conclusion}\n\n"
            # Add remaining content if needed
            if len(enhanced_content) < 5000:
                enhanced_content += f"Additional Content: {full_text[:8000]}"
            
            return {
                "success": True,
                "url": url,
                "type": "pdf",
                "metadata": metadata,
                "title": title,
                "abstract": abstract,
                "introduction": introduction,
                "conclusion": conclusion,
                "full_text": full_text[:50000],  # Limit to 50k chars
                "enhanced_content": enhanced_content[:15000],  # Prioritized content
                "page_count": len(pdf_reader.pages),
                "text_length": len(full_text)
            }
        except Exception as e:
            return {"error": f"PDF extraction failed: {str(e)}"}
    
    def _extract_from_web(self, url: str) -> Dict[str, Any]:
        """Extract text from web page."""
        try:
            response = requests.get(url, timeout=30, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()
            
            # Try to find title
            title = ""
            if soup.title:
                title = soup.title.string
            elif soup.find('h1'):
                title = soup.find('h1').get_text()
            
            # Extract main content
            text_content = soup.get_text()
            
            # Clean up text
            lines = (line.strip() for line in text_content.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)
            
            # Try to extract abstract
            abstract = self._extract_abstract(text)
            
            return {
                "success": True,
                "url": url,
                "type": "web",
                "title": title,
                "abstract": abstract,
                "full_text": text[:50000],  # Limit to 50k chars
                "text_length": len(text)
            }
        except Exception as e:
            return {"error": f"Web extraction failed: {str(e)}"}
    
    def _extract_title(self, text: str) -> str:
        """Extract title from paper text."""
        lines = text.split('\n')[:20]  # Check first 20 lines
        for line in lines:
            line = line.strip()
            if len(line) > 10 and len(line) < 200:
                # Likely a title
                return line
        return ""
    
    def _extract_abstract(self, text: str) -> str:
        """Extract abstract from paper text."""
        # Look for common abstract patterns
        patterns = [
            r'abstract[:\s]+(.*?)(?:\n\n|introduction|1\.|background)',
            r'abstract\s*\n\s*(.*?)(?:\n\n|introduction|1\.)',
            r'abstract[:\s]*(.{100,2000})',
        ]
        
        text_lower = text.lower()
        abstract_start = text_lower.find('abstract')
        
        if abstract_start != -1:
            # Extract text after "abstract"
            abstract_text = text[abstract_start + 8:abstract_start + 2000]
            # Clean up
            abstract_text = re.sub(r'\s+', ' ', abstract_text).strip()
            if len(abstract_text) > 50:
                return abstract_text[:1000]  # Limit abstract length
        
        return ""
    
    def _extract_section(self, text: str, section_name: str) -> str:
        """Extract a specific section (introduction, conclusion, etc.) from paper text."""
        text_lower = text.lower()
        section_start = text_lower.find(section_name)
        
        if section_start != -1:
            # Find the end of the section (next major section or end of text)
            next_sections = ['methodology', 'methods', 'results', 'discussion', 'references', 'bibliography']
            section_end = len(text)
            
            for next_section in next_sections:
                next_pos = text_lower.find(next_section, section_start + len(section_name))
                if next_pos != -1 and next_pos < section_end:
                    section_end = next_pos
            
            section_text = text[section_start + len(section_name):section_end]
            # Clean up
            section_text = re.sub(r'\s+', ' ', section_text).strip()
            if len(section_text) > 100:
                return section_text[:2000]  # Limit section length
        
        return ""


class PaperEvaluatorTool(Tool):
    """Tool to evaluate a paper's usefulness for research."""
    
    def __init__(self, openai_client=None):
        """
        Initialize the evaluator.
        
        Args:
            openai_client: OpenAI client instance (optional)
        """
        self.openai_client = openai_client
    
    @property
    def name(self) -> str:
        return "evaluate_paper"
    
    @property
    def description(self) -> str:
        return "Evaluates a paper's usefulness for a research theme and literature review"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "paper_content": {
                    "type": "string",
                    "description": "The content of the paper (title, abstract, or full text)"
                },
                "research_theme": {
                    "type": "string",
                    "description": "The research theme or topic to evaluate against"
                },
                "paper_title": {
                    "type": "string",
                    "description": "Title of the paper"
                },
                "paper_url": {
                    "type": "string",
                    "description": "URL of the paper"
                }
            },
            "required": ["paper_content", "research_theme"]
        }
    
    def execute(self, paper_content: str, research_theme: str, 
                paper_title: str = "", paper_url: str = "", **kwargs) -> Dict[str, Any]:
        """Evaluate paper usefulness."""
        if not self.openai_client:
            return {
                "error": "OpenAI client not configured. Please set OPENAI_API_KEY."
            }
        
        try:
            # Prepare enhanced evaluation prompt with detailed criteria
            evaluation_prompt = f"""You are an expert research paper evaluator with deep knowledge in academic research methodology. Evaluate the following paper for its usefulness in a research project.

Research Theme/Topic: {research_theme}

Paper Title: {paper_title if paper_title else "Not provided"}
Paper URL: {paper_url if paper_url else "Not provided"}

Paper Content:
{paper_content[:12000]}

EVALUATION CRITERIA (be precise and detailed):

1. RELEVANCE TO RESEARCH THEME (1-10):
   - 9-10: Directly addresses the research theme, core topic matches perfectly
   - 7-8: Highly relevant, addresses key aspects of the theme
   - 5-6: Moderately relevant, some connection to the theme
   - 3-4: Loosely related, tangential connection
   - 1-2: Not relevant, different topic area

2. QUALITY AND RIGOR (1-10):
   - 9-10: Excellent methodology, rigorous analysis, strong evidence
   - 7-8: Good methodology, solid analysis, adequate evidence
   - 5-6: Acceptable methodology, some limitations
   - 3-4: Weak methodology, significant limitations
   - 1-2: Poor methodology, major flaws

3. LITERATURE REVIEW SUITABILITY (1-10):
   - 9-10: Highly suitable, provides comprehensive background, key references
   - 7-8: Suitable, good background coverage
   - 5-6: Moderately suitable, some useful information
   - 3-4: Limited suitability, minimal useful content
   - 1-2: Not suitable for literature review

4. METHODOLOGICAL ALIGNMENT (1-10):
   - How well does the paper's methodology align with the research theme?
   - Consider if methods are applicable, transferable, or provide insights

5. CONTRIBUTION SIGNIFICANCE (1-10):
   - How significant are the contributions to the research theme?
   - Novelty, impact, and advancement of knowledge

6. CONFIDENCE LEVEL (1-10):
   - How confident are you in this evaluation?
   - Based on content quality, clarity, and completeness

Provide your evaluation in the following JSON format (ALL fields required):
{{
    "relevance_score": <1-10 integer>,
    "quality_score": <1-10 integer>,
    "literature_review_score": <1-10 integer>,
    "methodological_alignment_score": <1-10 integer>,
    "contribution_significance_score": <1-10 integer>,
    "confidence_score": <1-10 integer>,
    "overall_recommendation": "<Yes/No/Maybe>",
    "overall_match_percentage": <0-100 integer>,
    "reasoning": "<detailed 2-3 sentence explanation>",
    "key_contributions": "<main contributions of the paper>",
    "suitability_for_literature_review": "<Yes/No/Partial>",
    "strengths": "<list 2-3 key strengths>",
    "weaknesses": "<list 2-3 key weaknesses or limitations>",
    "topic_match_details": "<explain how well it matches the research theme>"
}}

Calculate overall_match_percentage as: (relevance_score * 0.3 + quality_score * 0.2 + literature_review_score * 0.25 + methodological_alignment_score * 0.15 + contribution_significance_score * 0.1) * 10

Be thorough, precise, and provide detailed reasoning."""

            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",  # Using mini for cost efficiency
                messages=[
                    {"role": "system", "content": "You are an expert research paper evaluator with PhD-level expertise. Always respond with valid JSON. Be precise with scores and detailed in explanations."},
                    {"role": "user", "content": evaluation_prompt}
                ],
                temperature=0.2,  # Lower temperature for more consistent evaluations
                max_tokens=1500
            )
            
            evaluation_text = response.choices[0].message.content.strip()
            
            # Try to parse JSON from response
            try:
                # Extract JSON from markdown code blocks if present
                json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', evaluation_text, re.DOTALL)
                if json_match:
                    evaluation_text = json_match.group(1)
                
                import json
                evaluation = json.loads(evaluation_text)
            except Exception as parse_error:
                # If JSON parsing fails, create structured response from text
                evaluation = {
                    "raw_response": evaluation_text,
                    "relevance_score": 5,
                    "quality_score": 5,
                    "literature_review_score": 5,
                    "methodological_alignment_score": 5,
                    "contribution_significance_score": 5,
                    "confidence_score": 5,
                    "overall_recommendation": "Maybe",
                    "overall_match_percentage": 50,
                    "reasoning": evaluation_text,
                    "parse_error": str(parse_error)
                }
            
            return {
                "success": True,
                "evaluation": evaluation,
                "paper_title": paper_title,
                "paper_url": paper_url
            }
            
        except Exception as e:
            return {"error": f"Evaluation failed: {str(e)}"}


class PaperSearchTool(Tool):
    """Tool to search for relevant papers using arXiv."""
    
    @property
    def name(self) -> str:
        return "search_papers"
    
    @property
    def description(self) -> str:
        return "Searches for relevant research papers on a given topic using arXiv"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query or research topic"
                },
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default: 10)",
                    "default": 10
                }
            },
            "required": ["query"]
        }
    
    def execute(self, query: str, max_results: int = 10, **kwargs) -> Dict[str, Any]:
        """Search for papers on arXiv."""
        try:
            search = arxiv.Search(
                query=query,
                max_results=min(max_results, 20),  # Limit to 20
                sort_by=arxiv.SortCriterion.Relevance
            )
            
            papers = []
            for result in search.results():
                paper_info = {
                    "title": result.title,
                    "authors": [author.name for author in result.authors],
                    "summary": result.summary,
                    "published": result.published.strftime("%Y-%m-%d") if result.published else "",
                    "arxiv_id": result.entry_id.split('/')[-1],
                    "arxiv_url": result.entry_id,
                    "pdf_url": result.pdf_url,
                    "categories": result.categories
                }
                papers.append(paper_info)
            
            return {
                "success": True,
                "query": query,
                "papers_found": len(papers),
                "papers": papers
            }
        except Exception as e:
            return {"error": f"Paper search failed: {str(e)}"}


class PaperSummarizerTool(Tool):
    """Tool to generate summaries of research papers."""
    
    def __init__(self, openai_client=None):
        """
        Initialize the summarizer.
        
        Args:
            openai_client: OpenAI client instance (optional)
        """
        self.openai_client = openai_client
    
    @property
    def name(self) -> str:
        return "summarize_paper"
    
    @property
    def description(self) -> str:
        return "Generates a concise summary of a research paper"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "paper_content": {
                    "type": "string",
                    "description": "The content of the paper to summarize"
                },
                "paper_title": {
                    "type": "string",
                    "description": "Title of the paper"
                }
            },
            "required": ["paper_content"]
        }
    
    def execute(self, paper_content: str, paper_title: str = "", **kwargs) -> Dict[str, Any]:
        """Generate paper summary."""
        if not self.openai_client:
            return {
                "error": "OpenAI client not configured. Please set OPENAI_API_KEY."
            }
        
        try:
            summary_prompt = f"""Please provide a concise summary of the following research paper.

Paper Title: {paper_title if paper_title else "Not provided"}

Paper Content:
{paper_content[:8000]}

Provide a summary that includes:
1. Main research question/problem
2. Key methodology/approach
3. Main findings/results
4. Significance/contributions

Keep the summary concise (200-300 words)."""

            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an expert at summarizing research papers concisely."},
                    {"role": "user", "content": summary_prompt}
                ],
                temperature=0.3,
                max_tokens=500
            )
            
            summary = response.choices[0].message.content.strip()
            
            return {
                "success": True,
                "summary": summary,
                "paper_title": paper_title
            }
            
        except Exception as e:
            return {"error": f"Summarization failed: {str(e)}"}

