# How to Start the Research Paper Evaluator Server

## Quick Start

1. **Navigate to the project directory:**
   ```bash
   cd /Users/dinokp/Documents/hack_agent
   ```

2. **Make sure dependencies are installed:**
   ```bash
   pip install -r requirements.txt
   ```
   or
   ```bash
   pip3 install -r requirements.txt
   ```

3. **Set up your OpenAI API key (required for evaluation):**
   ```bash
   echo "OPENAI_API_KEY=your_api_key_here" > .env
   ```
   Or edit the `.env` file manually.

4. **Start the server:**
   ```bash
   python app.py
   ```
   or
   ```bash
   python3 app.py
   ```

5. **Open your browser:**
   ```
   http://localhost:5001
   ```

## Using a Different Port

If port 5001 is already in use, you can specify a different port:

```bash
PORT=8080 python app.py
```

Then access it at: `http://localhost:8080`

## Stopping the Server

Press `Ctrl+C` in the terminal where the server is running.

## Troubleshooting

- **Port already in use:** Use a different port with `PORT=XXXX python app.py`
- **Module not found errors:** Make sure all dependencies are installed: `pip install -r requirements.txt`
- **OpenAI API errors:** Check that your `.env` file has a valid `OPENAI_API_KEY`
- **Server won't start:** Check for Python version compatibility (Python 3.8+ required)

## What You'll See

When the server starts successfully, you should see:
```
🚀 Starting Research Paper Evaluator on http://localhost:5001
📱 Open http://localhost:5001 in your browser
 * Running on http://0.0.0.0:5001
```

Then you can use the web interface to:
- Set your research theme
- Evaluate papers from URLs
- Find and evaluate relevant papers with visualizations

