#!/bin/bash

# Start both frontend and backend servers
# Usage: ./start.sh

echo "🚀 Starting Research Agent Application..."
echo ""

# Check if backend is already running
if lsof -Pi :5001 -sTCP:LISTEN -t >/dev/null ; then
    echo "⚠️  Backend is already running on port 5001"
else
    echo "📡 Starting Flask backend on port 5001..."
    cd "$(dirname "$0")"
    python3 app.py > /tmp/flask_server.log 2>&1 &
    BACKEND_PID=$!
    echo "   Backend started (PID: $BACKEND_PID)"
    echo "   Logs: /tmp/flask_server.log"
    sleep 2
fi

# Check if frontend is already running
if lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null ; then
    echo "⚠️  Frontend is already running on port 3000"
else
    echo "🎨 Starting React frontend on port 3000..."
    cd "$(dirname "$0")"
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        echo "   Installing frontend dependencies..."
        npm install
    fi
    
    npm run dev > /tmp/vite_server.log 2>&1 &
    FRONTEND_PID=$!
    echo "   Frontend started (PID: $FRONTEND_PID)"
    echo "   Logs: /tmp/vite_server.log"
fi

echo ""
echo "✅ Both servers are running!"
echo ""
echo "📱 Frontend: http://localhost:3000"
echo "📡 Backend:  http://localhost:5001"
echo ""
echo "To stop servers, run: ./stop.sh"
echo "Or manually: kill $BACKEND_PID $FRONTEND_PID"

