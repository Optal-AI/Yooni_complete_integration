"""Research paper evaluation agent."""

from typing import Dict, Any, Optional, List
import os
from openai import OpenAI
from agent import Agent
from research_tools import (
    PaperContentTool,
    PaperEvaluatorTool,
    PaperSearchTool,
    PaperSummarizerTool
)


class ResearchAgent(Agent):
    """Specialized agent for research paper evaluation and discovery."""
    
    def __init__(self, research_theme: str = "", openai_api_key: Optional[str] = None):
        """
        Initialize the research agent.
        
        Args:
            research_theme: The research theme/topic for paper evaluation
            openai_api_key: OpenAI API key (if not provided, uses OPENAI_API_KEY env var)
        """
        # Initialize OpenAI client
        api_key = openai_api_key or os.getenv("OPENAI_API_KEY")
        if api_key:
            self.openai_client = OpenAI(api_key=api_key)
        else:
            self.openai_client = None
            print("Warning: OpenAI API key not found. Some features may not work.")
        
        # Initialize tools
        tools = [
            PaperContentTool(),
            PaperEvaluatorTool(openai_client=self.openai_client),
            PaperSearchTool(),
            PaperSummarizerTool(openai_client=self.openai_client)
        ]
        
        super().__init__(tools=tools)
        self.research_theme = research_theme
    
    def evaluate_paper_from_url(self, url: str, research_theme: Optional[str] = None) -> Dict[str, Any]:
        """
        Evaluate a paper from a URL.
        
        Args:
            url: URL of the paper
            research_theme: Research theme to evaluate against (uses default if not provided)
            
        Returns:
            Evaluation results
        """
        theme = research_theme or self.research_theme
        
        if not theme:
            return {
                "error": "Research theme not specified. Please provide a research theme."
            }
        
        # Step 1: Extract paper content
        print(f"📄 Extracting content from: {url}")
        content_result = self.execute_tool("extract_paper_content", {"url": url})
        
        if "error" in content_result:
            return content_result
        
        if not content_result.get("success"):
            return {"error": "Failed to extract paper content"}
        
        # Step 2: Evaluate the paper (use enhanced content if available)
        print(f"🔍 Evaluating paper for research theme: {theme}")
        paper_content = content_result.get("enhanced_content") or content_result.get("full_text", "")
        evaluation_result = self.execute_tool(
            "evaluate_paper",
            {
                "paper_content": paper_content[:12000],
                "research_theme": theme,
                "paper_title": content_result.get("title", ""),
                "paper_url": url
            }
        )
        
        if "error" in evaluation_result:
            return evaluation_result
        
        # Step 3: Generate summary
        print("📝 Generating summary...")
        summary_result = self.execute_tool(
            "summarize_paper",
            {
                "paper_content": paper_content[:12000],
                "paper_title": content_result.get("title", "")
            }
        )
        
        # Combine results
        return {
            "success": True,
            "paper_info": {
                "title": content_result.get("title", ""),
                "url": url,
                "abstract": content_result.get("abstract", ""),
                "type": content_result.get("type", "")
            },
            "evaluation": evaluation_result.get("evaluation", {}),
            "summary": summary_result.get("summary", "") if "error" not in summary_result else None,
            "summary_error": summary_result.get("error") if "error" in summary_result else None
        }
    
    def find_and_evaluate_papers(self, research_topic: str, max_papers: int = 5) -> Dict[str, Any]:
        """
        Find relevant papers for a research topic and evaluate them.
        
        Args:
            research_topic: The research topic to search for
            max_papers: Maximum number of papers to evaluate
            
        Returns:
            List of evaluated papers
        """
        # Step 1: Search for papers
        print(f"🔎 Searching for papers on: {research_topic}")
        search_result = self.execute_tool("search_papers", {
            "query": research_topic,
            "max_results": max_papers * 2  # Get more to filter
        })
        
        if "error" in search_result:
            return search_result
        
        papers = search_result.get("papers", [])
        if not papers:
            return {
                "success": True,
                "papers_found": 0,
                "evaluated_papers": []
            }
        
        # Step 2: Evaluate each paper
        evaluated_papers = []
        theme = self.research_theme or research_topic
        
        for i, paper in enumerate(papers[:max_papers], 1):
            print(f"\n📊 Evaluating paper {i}/{min(len(papers), max_papers)}: {paper['title'][:60]}...")
            
            # Use abstract and summary as content for evaluation
            paper_content = f"Title: {paper['title']}\n\nAbstract: {paper['summary']}"
            
            # Evaluate
            evaluation_result = self.execute_tool(
                "evaluate_paper",
                {
                    "paper_content": paper_content,
                    "research_theme": theme,
                    "paper_title": paper['title'],
                    "paper_url": paper.get('pdf_url', paper.get('arxiv_url', ''))
                }
            )
            
            # Generate summary
            summary_result = self.execute_tool(
                "summarize_paper",
                {
                    "paper_content": paper_content,
                    "paper_title": paper['title']
                }
            )
            
            evaluated_paper = {
                "paper_info": {
                    "title": paper['title'],
                    "authors": paper['authors'],
                    "published": paper['published'],
                    "arxiv_id": paper['arxiv_id'],
                    "arxiv_url": paper['arxiv_url'],
                    "pdf_url": paper['pdf_url'],
                    "categories": paper['categories']
                },
                "evaluation": evaluation_result.get("evaluation", {}) if "error" not in evaluation_result else None,
                "evaluation_error": evaluation_result.get("error") if "error" in evaluation_result else None,
                "summary": summary_result.get("summary", "") if "error" not in summary_result else None,
                "summary_error": summary_result.get("error") if "error" in summary_result else None
            }
            
            evaluated_papers.append(evaluated_paper)
        
        # Sort by relevance score (if available)
        evaluated_papers.sort(
            key=lambda x: x.get("evaluation", {}).get("relevance_score", 0) if x.get("evaluation") else 0,
            reverse=True
        )
        
        return {
            "success": True,
            "research_topic": research_topic,
            "papers_found": len(papers),
            "evaluated_papers": evaluated_papers
        }
    
    def set_research_theme(self, theme: str):
        """Set the research theme for evaluation."""
        self.research_theme = theme

