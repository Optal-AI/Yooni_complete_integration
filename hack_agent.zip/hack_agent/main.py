"""Main entry point for the agent."""

from agent import Agent
from tools import CalculatorTool, FileReadTool, FileWriteTool, ListDirectoryTool


def main():
    """Main function to run the agent."""
    # Create agent with tools
    tools = [
        CalculatorTool(),
        FileReadTool(),
        FileWriteTool(),
        ListDirectoryTool()
    ]
    
    agent = Agent(tools=tools)
    
    # Run in interactive mode
    agent.interactive_mode()


if __name__ == "__main__":
    main()

