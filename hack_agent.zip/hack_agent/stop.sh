#!/bin/bash

# Stop both frontend and backend servers
# Usage: ./stop.sh

echo "🛑 Stopping Research Agent Application..."
echo ""

# Stop backend
if lsof -Pi :5001 -sTCP:LISTEN -t >/dev/null ; then
    echo "📡 Stopping Flask backend on port 5001..."
    lsof -ti:5001 | xargs kill -9 2>/dev/null
    echo "   Backend stopped"
else
    echo "   Backend is not running"
fi

# Stop frontend
if lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null ; then
    echo "🎨 Stopping React frontend on port 3000..."
    lsof -ti:3000 | xargs kill -9 2>/dev/null
    echo "   Frontend stopped"
else
    echo "   Frontend is not running"
fi

echo ""
echo "✅ All servers stopped!"

