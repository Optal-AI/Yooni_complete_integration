"""Tool system for the agent."""

from abc import ABC, abstractmethod
from typing import Any, Dict, List
import json


class Tool(ABC):
    """Base class for all tools."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Return the name of the tool."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Return a description of what the tool does."""
        pass
    
    @property
    @abstractmethod
    def parameters(self) -> Dict[str, Any]:
        """Return the parameters schema for the tool."""
        pass
    
    @abstractmethod
    def execute(self, **kwargs) -> Any:
        """Execute the tool with given parameters."""
        pass
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert tool to dictionary format."""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters
        }


class CalculatorTool(Tool):
    """A simple calculator tool."""
    
    @property
    def name(self) -> str:
        return "calculator"
    
    @property
    def description(self) -> str:
        return "Performs basic mathematical calculations (add, subtract, multiply, divide)"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["add", "subtract", "multiply", "divide"],
                    "description": "The mathematical operation to perform"
                },
                "a": {
                    "type": "number",
                    "description": "First number"
                },
                "b": {
                    "type": "number",
                    "description": "Second number"
                }
            },
            "required": ["operation", "a", "b"]
        }
    
    def execute(self, operation: str, a: float, b: float, **kwargs) -> Dict[str, Any]:
        """Execute the calculation."""
        try:
            if operation == "add":
                result = a + b
            elif operation == "subtract":
                result = a - b
            elif operation == "multiply":
                result = a * b
            elif operation == "divide":
                if b == 0:
                    return {"error": "Division by zero"}
                result = a / b
            else:
                return {"error": f"Unknown operation: {operation}"}
            
            return {
                "result": result,
                "expression": f"{a} {operation} {b} = {result}"
            }
        except Exception as e:
            return {"error": str(e)}


class FileReadTool(Tool):
    """Tool to read files."""
    
    @property
    def name(self) -> str:
        return "read_file"
    
    @property
    def description(self) -> str:
        return "Reads the contents of a file"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "filepath": {
                    "type": "string",
                    "description": "Path to the file to read"
                }
            },
            "required": ["filepath"]
        }
    
    def execute(self, filepath: str, **kwargs) -> Dict[str, Any]:
        """Read a file."""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            return {
                "success": True,
                "content": content,
                "filepath": filepath
            }
        except FileNotFoundError:
            return {"error": f"File not found: {filepath}"}
        except Exception as e:
            return {"error": str(e)}


class FileWriteTool(Tool):
    """Tool to write files."""
    
    @property
    def name(self) -> str:
        return "write_file"
    
    @property
    def description(self) -> str:
        return "Writes content to a file"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "filepath": {
                    "type": "string",
                    "description": "Path to the file to write"
                },
                "content": {
                    "type": "string",
                    "description": "Content to write to the file"
                }
            },
            "required": ["filepath", "content"]
        }
    
    def execute(self, filepath: str, content: str, **kwargs) -> Dict[str, Any]:
        """Write to a file."""
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return {
                "success": True,
                "filepath": filepath,
                "bytes_written": len(content.encode('utf-8'))
            }
        except Exception as e:
            return {"error": str(e)}


class ListDirectoryTool(Tool):
    """Tool to list directory contents."""
    
    @property
    def name(self) -> str:
        return "list_directory"
    
    @property
    def description(self) -> str:
        return "Lists files and directories in a given path"
    
    @property
    def parameters(self) -> Dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "directory": {
                    "type": "string",
                    "description": "Path to the directory to list"
                }
            },
            "required": ["directory"]
        }
    
    def execute(self, directory: str, **kwargs) -> Dict[str, Any]:
        """List directory contents."""
        import os
        try:
            items = os.listdir(directory)
            return {
                "success": True,
                "directory": directory,
                "items": items
            }
        except FileNotFoundError:
            return {"error": f"Directory not found: {directory}"}
        except Exception as e:
            return {"error": str(e)}

