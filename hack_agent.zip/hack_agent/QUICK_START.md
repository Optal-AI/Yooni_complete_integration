# Quick Start Guide

## Running the Application

Yes, you need to run **two servers**:
1. **Backend (Flask)** - Port 5001 - Handles API requests and AI processing
2. **Frontend (React)** - Port 3000 - The web interface you interact with

## Easiest Way: Use the Start Script

```bash
./start.sh
```

This automatically starts both servers. Then open:
**http://localhost:3000**

To stop both servers:
```bash
./stop.sh
```

## Manual Start (Step by Step)

### Terminal 1 - Backend Server
```bash
# Install Python dependencies (first time only)
pip3 install -r requirements.txt

# Start backend
python3 app.py
```

You should see:
```
🚀 Starting Research Paper Evaluator on http://localhost:5001
```

### Terminal 2 - Frontend Server
```bash
# Install Node dependencies (first time only)
npm install

# Start frontend
npm run dev
```

You should see:
```
  VITE v4.x.x  ready in xxx ms

  ➜  Local:   http://localhost:3000/
```

### Open in Browser
Go to: **http://localhost:3000**

## Prerequisites

1. **Python 3.8+** installed
2. **Node.js and npm** installed
3. **OpenAI API Key** in `.env` file:
   ```bash
   echo "OPENAI_API_KEY=your_key_here" > .env
   ```

## Troubleshooting

- **Port 5001 already in use?** 
  - Kill the process: `lsof -ti:5001 | xargs kill -9`
  - Or change port: `PORT=8080 python3 app.py`

- **Port 3000 already in use?**
  - Kill the process: `lsof -ti:3000 | xargs kill -9`
  - Or Vite will automatically use the next available port

- **"Failed to fetch" errors?**
  - Make sure the backend is running on port 5001
  - Check that both servers are running

- **Frontend can't connect to backend?**
  - Verify backend is running: `curl http://localhost:5001/api/health`
  - Check browser console for errors

## What Each Server Does

- **Backend (5001)**: 
  - Processes paper evaluations
  - Handles AI requests (OpenAI API)
  - Manages file uploads
  - Provides REST API endpoints

- **Frontend (3000)**:
  - User interface
  - Makes API calls to backend
  - Handles user interactions
  - Displays results

Both must be running for the app to work!

