# Backend Integration Guide

This document explains how to integrate Yooni with a real backend.

## Architecture Overview

The codebase is structured to make backend integration seamless:

```
/types/index.ts           → All TypeScript interfaces matching your backend schema
/services/                → Service layer abstracting all data operations
  ├── researchService.ts      → Research paper operations
  ├── assignmentService.ts    → Assignment scoring & improvement
  └── writingStyleService.ts  → Writing style analysis
/config/api.ts            → API configuration and feature flags
```

## Quick Start

### 1. Configure API Mode

Edit `/config/api.ts`:

```typescript
export const API_CONFIG = {
  MODE: 'production', // Change from 'mock' to 'production'
  
  // Add your Supabase credentials
  SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
  SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
};
```

### 2. Database Schema

Create these tables in Supabase:

```sql
-- Users
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Research Papers
CREATE TABLE research_papers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  topic_id UUID REFERENCES research_topics(id),
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  title TEXT NOT NULL,
  authors TEXT NOT NULL,
  year TEXT NOT NULL,
  relevance_score FLOAT,
  recommendation TEXT CHECK (recommendation IN ('include', 'exclude', 'maybe')),
  abstract TEXT,
  key_findings JSONB,
  methodology TEXT,
  strengths TEXT,
  limitations TEXT,
  upload_date TIMESTAMP DEFAULT NOW()
);

-- Research Topics
CREATE TABLE research_topics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  topic TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Assignments
CREATE TABLE assignments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  course_id UUID,
  due_date TIMESTAMP NOT NULL,
  original_text TEXT NOT NULL,
  improved_text TEXT,
  rubric_id UUID REFERENCES rubrics(id),
  current_score JSONB,
  improved_score JSONB,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Rubrics
CREATE TABLE rubrics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  criteria JSONB NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Writing Samples
CREATE TABLE writing_samples (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  type TEXT CHECK (type IN ('essay', 'email', 'discussion_post', 'other')),
  upload_date TIMESTAMP DEFAULT NOW()
);

-- Writing Styles
CREATE TABLE writing_styles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  characteristics JSONB NOT NULL,
  is_analyzed BOOLEAN DEFAULT FALSE,
  last_analyzed TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 3. Storage Buckets

Create these storage buckets in Supabase:

- `research-papers` - For uploaded PDF/DOCX papers
- `writing-samples` - For writing sample files
- `rubrics` - For custom rubric files

### 4. Edge Functions

Deploy these Supabase Edge Functions (or equivalent API endpoints):

#### `analyze-assignment`
Analyzes assignment text against rubric and returns scores.

**Input:**
```typescript
{
  text: string;
  rubricId?: string;
}
```

**Output:**
```typescript
{
  overall: number;
  maxScore: number;
  sections: SectionScore[];
  feedback: string;
}
```

#### `improve-assignment`
Rewrites assignment to improve score while maintaining writing style.

**Input:**
```typescript
{
  text: string;
  rubricId: string;
  writingStyleId: string;
  suggestedPapers?: string[];
}
```

**Output:**
```typescript
{
  improvedText: string;
  score: AssignmentScore;
  citations: InTextCitation[];
}
```

#### `analyze-relevance`
Analyzes research paper relevance to a topic.

**Input:**
```typescript
{
  paperText: string;
  researchTopic: string;
}
```

**Output:**
```typescript
{
  relevanceScore: number;
  recommendation: 'include' | 'exclude' | 'maybe';
  keyFindings: string[];
  methodology: string;
  strengths: string;
  limitations: string;
}
```

#### `analyze-writing-style`
Analyzes writing samples to create style profile.

**Input:**
```typescript
{
  sampleIds: string[];
  userId: string;
}
```

**Output:**
```typescript
{
  characteristics: {
    sentenceLength: 'short' | 'medium' | 'long';
    vocabulary: 'simple' | 'moderate' | 'advanced';
    tone: string[];
    commonPhrases: string[];
  };
}
```

#### `suggest-papers`
Suggests relevant papers from library for an assignment.

**Input:**
```typescript
{
  assignmentText: string;
  researchTopicId?: string;
}
```

**Output:**
```typescript
{
  papers: SuggestedPaper[];
}
```

### 5. Update Service Files

Replace mock implementations in `/services/*.ts` with real API calls. Look for `// TODO: Backend implementation` comments.

**Example - Research Service:**

```typescript
// Before (Mock)
export async function uploadPaper(file: File, researchTopic: string) {
  await new Promise(resolve => setTimeout(resolve, 2000));
  return { data: mockPaper, success: true };
}

// After (Real Backend)
export async function uploadPaper(file: File, researchTopic: string) {
  const supabase = createClient();
  const userId = (await supabase.auth.getUser()).data.user?.id;
  
  // 1. Upload file
  const { data: uploadData, error: uploadError } = await supabase.storage
    .from('research-papers')
    .upload(`${userId}/${file.name}`, file);
    
  if (uploadError) throw uploadError;
  
  // 2. Analyze with AI
  const { data: analysis } = await supabase.functions.invoke('analyze-relevance', {
    body: { filePath: uploadData.path, researchTopic }
  });
  
  // 3. Store in database
  const { data: paper, error } = await supabase
    .from('research_papers')
    .insert({
      user_id: userId,
      file_name: file.name,
      file_path: uploadData.path,
      ...analysis
    })
    .select()
    .single();
    
  if (error) throw error;
  return { data: paper, success: true };
}
```

## AI Integration

### Recommended AI Providers

1. **OpenAI GPT-4** - Best for writing style analysis and improvement
2. **Anthropic Claude** - Great for academic analysis and citations
3. **Google Gemini** - Good for document parsing and summarization
4. **Cohere** - Excellent for semantic search and relevance scoring

### Key AI Operations

- **Research Paper Analysis**: Extract key findings, methodology, strengths/weaknesses
- **Relevance Scoring**: Semantic similarity between paper and research topic
- **Assignment Scoring**: Rubric-based evaluation with detailed feedback
- **Writing Style Analysis**: Extract patterns, vocabulary, tone from samples
- **Assignment Rewriting**: Improve score while maintaining authentic style
- **Citation Suggestions**: Match papers to assignment topics semantically

## File Processing

You'll need libraries to:

1. **Parse PDFs**: `pdf-parse`, `pdfjs-dist`
2. **Parse DOCX**: `mammoth`, `docx`
3. **Extract Text**: `tesseract.js` (for OCR if needed)

## Testing

1. Keep mock mode enabled during development
2. Test each service method individually
3. Switch to production mode gradually
4. Use feature flags to enable/disable features

## Security Considerations

- ✅ Use Row Level Security (RLS) in Supabase
- ✅ Validate file types and sizes
- ✅ Sanitize user inputs
- ✅ Rate limit API calls
- ✅ Don't expose AI API keys client-side
- ✅ Implement proper authentication

## Current Status

- ✅ TypeScript types defined
- ✅ Service layer architecture complete
- ✅ Mock implementations working
- ⏳ Backend integration pending
- ⏳ Database setup pending
- ⏳ Edge functions deployment pending

## Next Steps

1. Set up Supabase project
2. Create database schema
3. Deploy Edge Functions for AI operations
4. Replace mock implementations one service at a time
5. Test thoroughly with real data
6. Deploy to production

## Questions?

All backend integration points are clearly marked with `// TODO: Backend implementation` comments throughout the codebase. Start there!
