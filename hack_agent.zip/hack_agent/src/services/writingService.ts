/**
 * Writing Service
 * Handles writing project operations including rubric upload, evaluation, and improvement
 * Connected to Flask backend API
 */

import { API_CONFIG } from '../config/api';

export interface RubricUploadResponse {
  success: boolean;
  rubric_content?: string;
  filename?: string;
  error?: string;
}

export interface WritingEvaluation {
  sections: Array<{
    name: string;
    score: number;
    maxScore: number;
    feedback: string;
  }>;
  totalScore: number;
  maxTotalScore: number;
  summary: string;
}

export interface WritingEvaluationResponse {
  success: boolean;
  evaluation?: WritingEvaluation;
  error?: string;
}

export interface WritingImprovementResponse {
  success: boolean;
  improved_content?: string;
  improved_evaluation?: WritingEvaluation;
  error?: string;
}

/**
 * Upload rubric file and extract content
 */
export async function uploadRubric(file: File): Promise<RubricUploadResponse> {
  try {
    const formData = new FormData();
    formData.append('rubric', file);

    const response = await fetch(API_CONFIG.ENDPOINTS.UPLOAD_RUBRIC, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Failed to upload rubric' }));
      return {
        success: false,
        error: errorData.error || 'Failed to upload rubric'
      };
    }

    const result = await response.json();
    return result;
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to upload rubric'
    };
  }
}

/**
 * Get default rubric for evaluating paragraphs
 */
export async function getDefaultRubric(): Promise<{ success: boolean; rubric_content?: string; error?: string }> {
  try {
    const response = await fetch(API_CONFIG.ENDPOINTS.DEFAULT_RUBRIC, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { error: errorText || 'Failed to get default rubric' };
      }
      return {
        success: false,
        error: errorData.error || `Server error: ${response.status} ${response.statusText}`
      };
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Network error fetching default rubric:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to connect to server. Make sure the backend is running on port 5001.'
    };
  }
}

/**
 * Evaluate writing against a rubric (or default rubric if none provided)
 */
export async function evaluateWriting(
  writingContent: string,
  rubricContent?: string
): Promise<WritingEvaluationResponse> {
  try {
    const response = await fetch(API_CONFIG.ENDPOINTS.EVALUATE_WRITING, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        writing_content: writingContent,
        rubric_content: rubricContent,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Failed to evaluate writing' }));
      return {
        success: false,
        error: errorData.error || 'Failed to evaluate writing'
      };
    }

    const result = await response.json();
    return result;
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to evaluate writing'
    };
  }
}

/**
 * Rewrite writing to improve scores based on rubric
 */
export async function improveWriting(
  writingContent: string,
  rubricContent?: string,
  evaluation?: WritingEvaluation
): Promise<WritingImprovementResponse> {
  try {
    const response = await fetch(API_CONFIG.ENDPOINTS.IMPROVE_WRITING, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        writing_content: writingContent,
        rubric_content: rubricContent,
        evaluation: evaluation,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { error: errorText || 'Failed to improve writing' };
      }
      return {
        success: false,
        error: errorData.error || `Server error: ${response.status} ${response.statusText}`
      };
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Network error improving writing:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to connect to server. Make sure the backend is running on port 5001.'
    };
  }
}

