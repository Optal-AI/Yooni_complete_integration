/**
 * Research Paper Service
 * Handles all research paper-related operations
 * Connected to Flask backend API
 */

import { ResearchPaper, ResearchTopic, Citation, ApiResponse } from '../types';
import { API_CONFIG } from '../config/api';

// Mock data - REPLACE WITH BACKEND
const mockPapers: ResearchPaper[] = [
  {
    id: '1',
    fileName: 'attention-is-all-you-need.pdf',
    uploadDate: '2025-11-10',
    title: 'Attention Is All You Need',
    authors: 'Vaswani, A., Shazeer, N., Parmar, N., et al.',
    year: '2017',
    relevanceScore: 0.95,
    recommendation: 'include',
    abstract: 'We propose a new simple network architecture, the Transformer...',
    keyFindings: [
      'Introduces self-attention mechanism for sequence modeling',
      'Eliminates recurrence and convolutions entirely',
      'Achieves state-of-the-art on translation tasks'
    ],
    methodology: 'Proposes encoder-decoder architecture using only attention mechanisms',
    strengths: 'Highly parallelizable, captures long-range dependencies effectively',
    limitations: 'Requires large amounts of training data',
  },
  {
    id: '2',
    fileName: 'bert-pretraining.pdf',
    uploadDate: '2025-11-12',
    title: 'BERT: Pre-training of Deep Bidirectional Transformers',
    authors: 'Devlin, J., Chang, M., Lee, K., Toutanova, K.',
    year: '2018',
    relevanceScore: 0.88,
    recommendation: 'include',
    abstract: 'We introduce BERT, which stands for Bidirectional Encoder Representations...',
    keyFindings: [
      'Bidirectional pre-training improves performance',
      'Masked language modeling enables bidirectional learning',
      'Fine-tuning achieves state-of-the-art on 11 NLP tasks'
    ],
    methodology: 'Pre-trains bidirectional representations using masked language modeling',
    strengths: 'Strong transfer learning capabilities, bidirectional context',
    limitations: 'Computationally expensive to train',
  }
];

/**
 * Upload and analyze a research paper
 * Connects to Flask backend for PDF evaluation
 */
export async function uploadPaper(
  file: File,
  researchTopic: string
): Promise<ApiResponse<ResearchPaper>> {
  try {
    const formData = new FormData();
    formData.append('pdf', file);
    formData.append('option', 'theme');
    formData.append('research_theme', researchTopic);

    const response = await fetch(API_CONFIG.ENDPOINTS.UPLOAD_PAPER, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Failed to upload paper' }));
      throw new Error(errorData.error || 'Failed to upload paper');
    }

    const result = await response.json();
    
    // Transform backend response to frontend format
    const paper: ResearchPaper = {
      id: Date.now().toString(),
      fileName: result.paper_info?.filename || file.name,
      uploadDate: new Date().toISOString().split('T')[0],
      title: result.paper_info?.title || file.name.replace(/\.(pdf|docx)$/i, ''),
      authors: result.paper_info?.authors?.join(', ') || 'Unknown',
      year: result.paper_info?.published?.split('-')[0] || new Date().getFullYear().toString(),
      relevanceScore: (result.evaluation?.relevance_score || 0) / 10, // Convert 1-10 to 0-1
      recommendation: result.evaluation?.overall_recommendation?.toLowerCase() === 'yes' 
        ? 'include' 
        : result.evaluation?.overall_recommendation?.toLowerCase() === 'no'
        ? 'exclude'
        : 'maybe',
      abstract: result.paper_info?.abstract || result.summary || '',
      keyFindings: result.evaluation?.key_contributions 
        ? [result.evaluation.key_contributions] 
        : [],
      methodology: result.evaluation?.methodological_alignment_score 
        ? `Methodological Alignment: ${result.evaluation.methodological_alignment_score}/10`
        : undefined,
      strengths: result.evaluation?.strengths,
      limitations: result.evaluation?.weaknesses,
      citationAPA: result.evaluation ? generateAPACitation(result.paper_info) : undefined,
    };

    return { data: paper, success: true };
  } catch (error) {
    return { 
      error: error instanceof Error ? error.message : 'Failed to upload paper',
      success: false 
    };
  }
}

// Helper function to generate APA citation
function generateAPACitation(paperInfo: any): string {
  const authors = paperInfo.authors || [];
  const title = paperInfo.title || 'Untitled';
  const year = paperInfo.published?.split('-')[0] || new Date().getFullYear().toString();
  const arxivId = paperInfo.arxiv_id || '';
  
  let authorString = '';
  if (Array.isArray(authors) && authors.length > 0) {
    if (authors.length === 1) {
      authorString = formatAuthorName(authors[0]);
    } else if (authors.length <= 7) {
      authorString = authors.map((a: string) => formatAuthorName(a)).join(', ');
      authorString = authorString.replace(/,([^,]*)$/, ', &$1');
    } else {
      authorString = authors.slice(0, 6).map((a: string) => formatAuthorName(a)).join(', ') + 
                     ', ... ' + formatAuthorName(authors[authors.length - 1]);
    }
  } else {
    authorString = 'Author, A. A.';
  }
  
  let citation = `${authorString} (${year}). ${title}`;
  if (arxivId) {
    citation += `. arXiv preprint arXiv:${arxivId}`;
  }
  if (paperInfo.url || paperInfo.pdf_url) {
    citation += `. ${paperInfo.url || paperInfo.pdf_url}`;
  } else {
    citation += '.';
  }
  
  return citation;
}

function formatAuthorName(fullName: string): string {
  if (!fullName) return 'Author, A. A.';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length === 0) return 'Author, A. A.';
  
  const lastName = parts[parts.length - 1];
  const firstNames = parts.slice(0, -1);
  
  let initials = '';
  if (firstNames.length > 0) {
    initials = firstNames.map((name: string) => name.charAt(0).toUpperCase() + '.').join(' ');
  } else {
    initials = 'A.';
  }
  
  return `${lastName}, ${initials}`;
}

/**
 * Get all papers for a research topic
 * Currently returns papers from localStorage (from previous evaluations)
 */
export async function getPapers(topicId?: string): Promise<ApiResponse<ResearchPaper[]>> {
  try {
    // Get papers from localStorage (saved from previous evaluations)
    const savedTabs = localStorage.getItem('researchTabs');
    const papers: ResearchPaper[] = [];
    
    if (savedTabs) {
      try {
        const tabs = JSON.parse(savedTabs);
        tabs.forEach((tab: any) => {
          if (tab.type === 'evaluation' && tab.data?.paper_info) {
            const paperInfo = tab.data.paper_info;
            const evaluation = tab.data.evaluation;
            papers.push({
              id: tab.id,
              fileName: paperInfo.filename || paperInfo.url?.split('/').pop() || 'paper.pdf',
              uploadDate: tab.createdAt?.split('T')[0] || new Date().toISOString().split('T')[0],
              title: paperInfo.title || 'Untitled',
              authors: Array.isArray(paperInfo.authors) 
                ? paperInfo.authors.join(', ') 
                : paperInfo.authors || 'Unknown',
              year: paperInfo.published?.split('-')[0] || new Date().getFullYear().toString(),
              relevanceScore: (evaluation?.relevance_score || 0) / 10,
              recommendation: evaluation?.overall_recommendation?.toLowerCase() === 'yes' 
                ? 'include' 
                : evaluation?.overall_recommendation?.toLowerCase() === 'no'
                ? 'exclude'
                : 'maybe',
              abstract: paperInfo.abstract || tab.data.summary || '',
              keyFindings: evaluation?.key_contributions ? [evaluation.key_contributions] : [],
              strengths: evaluation?.strengths,
              limitations: evaluation?.weaknesses,
            });
          } else if (tab.type === 'search' && tab.data?.evaluated_papers) {
            tab.data.evaluated_papers.forEach((item: any) => {
              const paperInfo = item.paper_info;
              const evaluation = item.evaluation;
              if (paperInfo) {
                papers.push({
                  id: `${tab.id}-${paperInfo.arxiv_id || Date.now()}`,
                  fileName: paperInfo.title || 'paper.pdf',
                  uploadDate: paperInfo.published || new Date().toISOString().split('T')[0],
                  title: paperInfo.title || 'Untitled',
                  authors: Array.isArray(paperInfo.authors) 
                    ? paperInfo.authors.join(', ') 
                    : 'Unknown',
                  year: paperInfo.published?.split('-')[0] || new Date().getFullYear().toString(),
                  relevanceScore: (evaluation?.relevance_score || 0) / 10,
                  recommendation: evaluation?.overall_recommendation?.toLowerCase() === 'yes' 
                    ? 'include' 
                    : evaluation?.overall_recommendation?.toLowerCase() === 'no'
                    ? 'exclude'
                    : 'maybe',
                  abstract: item.summary || '',
                  keyFindings: evaluation?.key_contributions ? [evaluation.key_contributions] : [],
                });
              }
            });
          }
        });
      } catch (e) {
        console.error('Error parsing saved tabs:', e);
      }
    }
    
    // Also check favorites
    const favorites = localStorage.getItem('favoritePapers');
    if (favorites) {
      try {
        const favs = JSON.parse(favorites);
        favs.forEach((fav: any) => {
          if (!papers.find(p => p.id === fav.id)) {
            papers.push({
              id: fav.id || Date.now().toString(),
              fileName: fav.filename || fav.url?.split('/').pop() || 'paper.pdf',
              uploadDate: fav.favoritedAt?.split('T')[0] || new Date().toISOString().split('T')[0],
              title: fav.title || 'Untitled',
              authors: Array.isArray(fav.authors) ? fav.authors.join(', ') : fav.authors || 'Unknown',
              year: fav.published?.split('-')[0] || new Date().getFullYear().toString(),
              relevanceScore: 0.5,
              recommendation: 'maybe',
            });
          }
        });
      } catch (e) {
        console.error('Error parsing favorites:', e);
      }
    }
    
    return { data: papers, success: true };
  } catch (error) {
    return { 
      error: error instanceof Error ? error.message : 'Failed to fetch papers',
      success: false 
    };
  }
}

/**
 * Delete a paper
 * Removes from localStorage (saved tabs and favorites)
 */
export async function deletePaper(paperId: string): Promise<ApiResponse<void>> {
  try {
    // Remove from saved tabs
    const savedTabs = localStorage.getItem('researchTabs');
    if (savedTabs) {
      try {
        const tabs = JSON.parse(savedTabs);
        const filteredTabs = tabs.filter((tab: any) => tab.id !== paperId);
        localStorage.setItem('researchTabs', JSON.stringify(filteredTabs));
      } catch (e) {
        console.error('Error deleting from tabs:', e);
      }
    }
    
    // Remove from favorites
    const favorites = localStorage.getItem('favoritePapers');
    if (favorites) {
      try {
        const favs = JSON.parse(favorites);
        const filteredFavs = favs.filter((fav: any) => 
          (fav.id || fav.url || fav.title) !== paperId
        );
        localStorage.setItem('favoritePapers', JSON.stringify(filteredFavs));
      } catch (e) {
        console.error('Error deleting from favorites:', e);
      }
    }
    
    return { success: true };
  } catch (error) {
    return { 
      error: error instanceof Error ? error.message : 'Failed to delete paper',
      success: false 
    };
  }
}

/**
 * Generate citations for a paper
 * Uses APA format primarily, with MLA and Chicago variants
 */
export function generateCitations(paper: ResearchPaper): Citation[] {
  const authors = paper.authors || 'Author, A. A.';
  const title = paper.title || 'Untitled';
  const year = paper.year || new Date().getFullYear().toString();
  
  return [
    {
      format: 'APA',
      text: paper.citationAPA || `${authors} (${year}). ${title}.`
    },
    {
      format: 'MLA',
      text: `${authors}. "${title}." ${year}.`
    },
    {
      format: 'Chicago',
      text: `${authors}. "${title}" (${year}).`
    }
  ];
}

/**
 * Save or update research topic
 * Stores in localStorage for now
 */
export async function saveResearchTopic(
  topic: string,
  description?: string
): Promise<ApiResponse<ResearchTopic>> {
  try {
    const topics = localStorage.getItem('researchTopics');
    let topicsList: ResearchTopic[] = [];
    
    if (topics) {
      try {
        topicsList = JSON.parse(topics);
      } catch (e) {
        console.error('Error parsing topics:', e);
      }
    }
    
    const existingTopic = topicsList.find(t => t.topic === topic);
    const newTopic: ResearchTopic = existingTopic || {
      id: Date.now().toString(),
      topic,
      description,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    if (existingTopic) {
      newTopic.description = description || existingTopic.description;
      newTopic.updatedAt = new Date().toISOString();
      const index = topicsList.findIndex(t => t.id === existingTopic.id);
      topicsList[index] = newTopic;
    } else {
      topicsList.push(newTopic);
    }
    
    localStorage.setItem('researchTopics', JSON.stringify(topicsList));

    return { data: newTopic, success: true };
  } catch (error) {
    return { 
      error: error instanceof Error ? error.message : 'Failed to save topic',
      success: false 
    };
  }
}
