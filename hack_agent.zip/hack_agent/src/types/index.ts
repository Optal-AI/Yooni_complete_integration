/**
 * Core data types for Yooni
 * These match the expected backend schema
 */

// Research Paper types
export interface ResearchPaper {
  id: string;
  fileName: string;
  uploadDate: string;
  title: string;
  authors: string;
  year: string;
  relevanceScore: number;
  recommendation: 'include' | 'exclude' | 'maybe';
  abstract?: string;
  keyFindings?: string[];
  methodology?: string;
  strengths?: string;
  limitations?: string;
  citationAPA?: string;
  citationMLA?: string;
  citationChicago?: string;
}

export interface ResearchTopic {
  id: string;
  topic: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

// Assignment types
export interface Assignment {
  id: string;
  title: string;
  courseId?: string;
  dueDate: string;
  originalText: string;
  improvedText?: string;
  rubricId?: string;
  currentScore?: AssignmentScore;
  improvedScore?: AssignmentScore;
  createdAt: string;
  updatedAt: string;
}

export interface AssignmentScore {
  overall: number;
  maxScore: number;
  sections: SectionScore[];
  feedback: string;
}

export interface SectionScore {
  name: string;
  score: number;
  improvedScore?: number;
  maxScore: number;
  feedback: string;
  improvementNote?: string;
}

export interface Rubric {
  id: string;
  name: string;
  criteria: RubricCriterion[];
  createdAt: string;
}

export interface RubricCriterion {
  name: string;
  description: string;
  maxScore: number;
}

// Citation types
export interface Citation {
  format: 'APA' | 'MLA' | 'Chicago';
  text: string;
}

export interface SuggestedPaper {
  paperId: string;
  title: string;
  authors: string;
  year: string;
  relevance: string;
  whereToUse: string;
  relevanceScore: number;
}

export interface InTextCitation {
  text: string;
  paragraphIndex: number;
  position: number;
  paperId: string;
}

// Writing Style types
export interface WritingSample {
  id: string;
  text: string;
  type: 'essay' | 'email' | 'discussion_post' | 'other';
  uploadDate: string;
}

export interface WritingStyle {
  id: string;
  userId: string;
  samples: WritingSample[];
  characteristics: {
    sentenceLength: 'short' | 'medium' | 'long';
    vocabulary: 'simple' | 'moderate' | 'advanced';
    tone: string[];
    commonPhrases: string[];
  };
  isAnalyzed: boolean;
  lastAnalyzed?: string;
}

// User types (for future multi-user support)
export interface User {
  id: string;
  email: string;
  name?: string;
  createdAt: string;
}

// API Response types
export interface ApiResponse<T> {
  data?: T;
  error?: string;
  success: boolean;
}
