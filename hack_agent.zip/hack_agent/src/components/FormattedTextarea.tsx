import React, { useRef, forwardRef } from 'react';

interface FormattedTextareaProps {
  value: string;
  onChange: (value: string) => void;
  onFormat?: (format: string, selectedText: string, start: number, end: number) => void;
  rows?: number;
  placeholder?: string;
  className?: string;
}

export const FormattedTextarea = forwardRef<HTMLTextAreaElement, FormattedTextareaProps>(
  ({ value, onChange, onFormat, rows = 20, placeholder, className = '' }, ref) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const actualRef = (ref as React.RefObject<HTMLTextAreaElement>) || textareaRef;

    const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      onChange(e.target.value);
    };

    return (
      <textarea
        ref={actualRef}
        value={value}
        onChange={handleChange}
        rows={rows}
        placeholder={placeholder}
        className={`w-full px-4 py-3 bg-white border border-[#D7D7D2] rounded-lg text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:ring-1 focus:ring-[#AEC8A6] transition-shadow resize-none ${className}`}
        style={{
          fontFamily: "'Inter Tight', sans-serif",
          lineHeight: '1.75'
        }}
      />
    );
  }
);

FormattedTextarea.displayName = 'FormattedTextarea';
