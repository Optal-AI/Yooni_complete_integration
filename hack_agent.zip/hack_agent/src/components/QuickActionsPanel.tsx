import React from 'react';
import { Upload, FileCheck, PenLine, Calendar } from 'lucide-react';

export function QuickActionsPanel() {
  const actions = [
    {
      icon: Upload,
      label: 'Upload Paper',
      description: 'Add research source',
      color: 'text-[#AEC8A6]'
    },
    {
      icon: FileCheck,
      label: 'Score Assignment',
      description: 'Get rubric feedback',
      color: 'text-[#8BAA82]'
    },
    {
      icon: PenLine,
      label: 'Improve Writing',
      description: 'Style-preserving edits',
      color: 'text-[#AEC8A6]'
    },
  ];

  return (
    <div className="w-80 bg-white border-l border-[#D7D7D2] h-screen flex flex-col sticky top-0 p-6">
      <div className="mb-6">
        <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60 mb-1" style={{ fontWeight: 600 }}>
          Quick Actions
        </h3>
        <p className="text-xs text-[#1C1C1C]/40">Start something new</p>
      </div>

      <div className="space-y-3 mb-8">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              className="w-full flex items-start gap-3 p-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left"
            >
              <Icon className={`w-5 h-5 ${action.color} flex-shrink-0 mt-0.5`} strokeWidth={1.5} />
              <div className="flex-1">
                <div className="text-sm text-[#1C1C1C] mb-0.5" style={{ fontWeight: 500 }}>
                  {action.label}
                </div>
                <div className="text-xs text-[#1C1C1C]/50">
                  {action.description}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="border-t border-[#D7D7D2] pt-6">
        <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60 mb-4" style={{ fontWeight: 600 }}>
          Today's Schedule
        </h3>
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-1 h-12 bg-[#AEC8A6] rounded-full flex-shrink-0"></div>
            <div className="flex-1">
              <div className="text-xs text-[#1C1C1C]/50 mb-0.5">1:30 PM</div>
              <div className="text-sm text-[#1C1C1C]" style={{ fontWeight: 500 }}>CS 224N Lecture</div>
              <div className="text-xs text-[#1C1C1C]/60">Deep Learning</div>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <div className="w-1 h-12 bg-[#D7D7D2] rounded-full flex-shrink-0"></div>
            <div className="flex-1">
              <div className="text-xs text-[#1C1C1C]/50 mb-0.5">3:00 PM</div>
              <div className="text-sm text-[#1C1C1C]" style={{ fontWeight: 500 }}>Office Hours</div>
              <div className="text-xs text-[#1C1C1C]/60">PSYCH 254</div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-auto pt-6 border-t border-[#D7D7D2]">
        <div className="text-xs text-[#1C1C1C]/40">
          Last opened: Research Proposal
        </div>
      </div>
    </div>
  );
}
