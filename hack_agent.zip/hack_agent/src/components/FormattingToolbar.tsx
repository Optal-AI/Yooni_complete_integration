import React, { useState } from 'react';
import { Tooltip } from './Tooltip';
import { 
  Type, 
  Bold, 
  Italic, 
  List, 
  ListOrdered,
  Quote,
  AlignLeft,
  AlignCenter,
  ChevronDown
} from 'lucide-react';

interface FormattingToolbarProps {
  onFormat: (format: FormatType, value?: string) => void;
  citationStyle: 'APA' | 'MLA' | 'Chicago' | 'Harvard';
}

export type FormatType = 
  | 'title' 
  | 'author' 
  | 'institution'
  | 'abstract'
  | 'heading1' 
  | 'heading2' 
  | 'heading3' 
  | 'heading4'
  | 'heading5'
  | 'normal'
  | 'blockquote'
  | 'bold'
  | 'italic'
  | 'bullet'
  | 'numbered';

export function FormattingToolbar({ onFormat, citationStyle }: FormattingToolbarProps) {
  const [showHeadingMenu, setShowHeadingMenu] = useState(false);

  const headingOptions = [
    { value: 'title', label: 'Title', description: 'Paper title (centered, bold)' },
    { value: 'author', label: 'Author', description: 'Author name (centered)' },
    { value: 'institution', label: 'Institution', description: 'Institution name (centered)' },
    { value: 'abstract', label: 'Abstract', description: 'Abstract heading (centered, bold)' },
    { value: 'heading1', label: 'Heading 1', description: 'Centered, Bold' },
    { value: 'heading2', label: 'Heading 2', description: 'Left-aligned, Bold' },
    { value: 'heading3', label: 'Heading 3', description: 'Left-aligned, Bold, Italic' },
    { value: 'heading4', label: 'Heading 4', description: 'Indented, Bold' },
    { value: 'heading5', label: 'Heading 5', description: 'Indented, Bold, Italic' },
    { value: 'normal', label: 'Normal Text', description: 'Body paragraph' },
  ];

  return (
    <div className="flex items-center gap-2 p-3 bg-[#F5F5F2] border border-[#D7D7D2] rounded-lg mb-3">
      {/* Heading/Style Selector */}
      <div className="relative">
        <Tooltip content="Text Style">
          <button
            onClick={() => setShowHeadingMenu(!showHeadingMenu)}
            className="flex items-center gap-2 px-3 py-2 bg-white hover:bg-[#D7D7D2]/30 rounded-lg transition-colors border border-[#D7D7D2]"
          >
            <Type className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
            <span className="text-[13px] text-[#1C1C1C]">Style</span>
            <ChevronDown className="w-3.5 h-3.5 text-[#1C1C1C]/40" strokeWidth={1.5} />
          </button>
        </Tooltip>
        
        {showHeadingMenu && (
          <div className="absolute top-full left-0 mt-2 bg-white border border-[#D7D7D2] rounded-lg shadow-lg z-20 overflow-hidden w-72 animate-in fade-in zoom-in-95 duration-150">
            <div className="p-2 bg-[#AEC8A6]/10 border-b border-[#D7D7D2]">
              <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/60" style={{ fontWeight: 600 }}>
                {citationStyle} Format
              </div>
            </div>
            {headingOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => {
                  onFormat(option.value as FormatType);
                  setShowHeadingMenu(false);
                }}
                className="block w-full px-4 py-3 text-left hover:bg-[#AEC8A6]/10 transition-colors border-b border-[#D7D7D2] last:border-0"
              >
                <div className="text-[14px] text-[#1C1C1C] mb-0.5" style={{ fontWeight: 500 }}>
                  {option.label}
                </div>
                <div className="text-[12px] text-[#1C1C1C]/50">
                  {option.description}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="w-px h-6 bg-[#D7D7D2]" />

      {/* Text Formatting */}
      <Tooltip content="Bold">
        <button
          onClick={() => onFormat('bold')}
          className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
        >
          <Bold className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
        </button>
      </Tooltip>

      <Tooltip content="Italic">
        <button
          onClick={() => onFormat('italic')}
          className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
        >
          <Italic className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
        </button>
      </Tooltip>

      <div className="w-px h-6 bg-[#D7D7D2]" />

      {/* Lists */}
      <Tooltip content="Bullet List">
        <button
          onClick={() => onFormat('bullet')}
          className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
        >
          <List className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
        </button>
      </Tooltip>

      <Tooltip content="Numbered List">
        <button
          onClick={() => onFormat('numbered')}
          className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
        >
          <ListOrdered className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
        </button>
      </Tooltip>

      <div className="w-px h-6 bg-[#D7D7D2]" />

      {/* Block Quote */}
      <Tooltip content="Block Quote (40+ words)">
        <button
          onClick={() => onFormat('blockquote')}
          className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
        >
          <Quote className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
        </button>
      </Tooltip>

      <div className="flex-1" />

      {/* APA Guidelines Button */}
      <button
        onClick={() => window.open('https://apastyle.apa.org/', '_blank')}
        className="px-3 py-2 text-[12px] text-[#8BAA82] hover:text-[#1C1C1C] transition-colors"
        style={{ fontWeight: 500 }}
      >
        {citationStyle} Guidelines →
      </button>
    </div>
  );
}
