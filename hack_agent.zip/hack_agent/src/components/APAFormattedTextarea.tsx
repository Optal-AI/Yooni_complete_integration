import React, { useRef, useEffect } from 'react';

interface APAFormattedTextareaProps {
  value: string;
  onChange: (value: string) => void;
  rows?: number;
  placeholder?: string;
  className?: string;
}

export function APAFormattedTextarea({
  value,
  onChange,
  rows = 20,
  placeholder,
  className = ''
}: APAFormattedTextareaProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
  };

  // Auto-resize functionality
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [value]);

  return (
    <div className="relative">
      <textarea
        ref={textareaRef}
        value={value}
        onChange={handleChange}
        rows={rows}
        placeholder={placeholder}
        className={`w-full px-4 py-3 bg-white border border-[#D7D7D2] rounded-lg text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:ring-1 focus:ring-[#AEC8A6] transition-shadow resize-none ${className}`}
        style={{
          fontFamily: "'Inter Tight', sans-serif",
          lineHeight: '2',
          minHeight: '400px'
        }}
      />
    </div>
  );
}

export function APAPreviewPane({ content }: { content: string }) {
  // Function to render text with bold and italic formatting
  const renderTextWithFormatting = (text: string) => {
    // Split by bold (**text**) and italic (*text*)
    const parts: React.ReactNode[] = [];
    let currentText = text;
    let key = 0;

    while (currentText.length > 0) {
      // Check for bold first (**text**)
      const boldMatch = currentText.match(/\*\*(.+?)\*\*/);
      if (boldMatch && boldMatch.index !== undefined) {
        // Add text before the match
        if (boldMatch.index > 0) {
          parts.push(currentText.substring(0, boldMatch.index));
        }
        // Add bold text
        parts.push(
          <strong key={`bold-${key++}`} style={{ fontWeight: 700 }}>
            {boldMatch[1]}
          </strong>
        );
        currentText = currentText.substring(boldMatch.index + boldMatch[0].length);
        continue;
      }

      // Check for italic (*text*)
      const italicMatch = currentText.match(/\*(.+?)\*/);
      if (italicMatch && italicMatch.index !== undefined) {
        // Add text before the match
        if (italicMatch.index > 0) {
          parts.push(currentText.substring(0, italicMatch.index));
        }
        // Add italic text
        parts.push(
          <em key={`italic-${key++}`} style={{ fontStyle: 'italic' }}>
            {italicMatch[1]}
          </em>
        );
        currentText = currentText.substring(italicMatch.index + italicMatch[0].length);
        continue;
      }

      // No more formatting found
      parts.push(currentText);
      break;
    }

    return parts;
  };

  const renderFormattedContent = () => {
    const lines = content.split('\n');
    
    return lines.map((line, index) => {
      // Check for formatting markers
      if (line.startsWith('[TITLE]')) {
        return (
          <div key={index} className="text-center mb-8">
            <h1 className="text-[#1C1C1C] mb-0" style={{ fontWeight: 700 }}>
              {renderTextWithFormatting(line.replace('[TITLE]', '').trim())}
            </h1>
          </div>
        );
      }
      
      if (line.startsWith('[AUTHOR]')) {
        return (
          <div key={index} className="text-center mb-2">
            <p className="text-[#1C1C1C]">
              {renderTextWithFormatting(line.replace('[AUTHOR]', '').trim())}
            </p>
          </div>
        );
      }
      
      if (line.startsWith('[INSTITUTION]')) {
        return (
          <div key={index} className="text-center mb-8">
            <p className="text-[#1C1C1C]">
              {renderTextWithFormatting(line.replace('[INSTITUTION]', '').trim())}
            </p>
          </div>
        );
      }
      
      if (line.startsWith('[ABSTRACT]')) {
        return (
          <div key={index} className="text-center mb-4">
            <h2 className="text-[#1C1C1C]" style={{ fontWeight: 700 }}>
              {renderTextWithFormatting(line.replace('[ABSTRACT]', '').trim() || 'Abstract')}
            </h2>
          </div>
        );
      }
      
      if (line.startsWith('[H1]')) {
        return (
          <div key={index} className="text-center mt-8 mb-4">
            <h2 className="text-[#1C1C1C]" style={{ fontWeight: 700 }}>
              {renderTextWithFormatting(line.replace('[H1]', '').trim())}
            </h2>
          </div>
        );
      }
      
      if (line.startsWith('[H2]')) {
        return (
          <div key={index} className="mt-6 mb-3">
            <h3 className="text-[#1C1C1C]" style={{ fontWeight: 700 }}>
              {renderTextWithFormatting(line.replace('[H2]', '').trim())}
            </h3>
          </div>
        );
      }
      
      if (line.startsWith('[H3]')) {
        return (
          <div key={index} className="mt-5 mb-3">
            <h4 className="text-[#1C1C1C]" style={{ fontWeight: 700, fontStyle: 'italic' }}>
              {renderTextWithFormatting(line.replace('[H3]', '').trim())}
            </h4>
          </div>
        );
      }
      
      if (line.startsWith('[H4]')) {
        return (
          <div key={index} className="mt-4 mb-2">
            <h5 className="text-[#1C1C1C] pl-8" style={{ fontWeight: 700 }}>
              {renderTextWithFormatting(line.replace('[H4]', '').trim())}
            </h5>
          </div>
        );
      }
      
      if (line.startsWith('[H5]')) {
        return (
          <div key={index} className="mt-4 mb-2">
            <h6 className="text-[#1C1C1C] pl-8" style={{ fontWeight: 700, fontStyle: 'italic' }}>
              {renderTextWithFormatting(line.replace('[H5]', '').trim())}
            </h6>
          </div>
        );
      }
      
      if (line.startsWith('[QUOTE]')) {
        return (
          <div key={index} className="my-4 pl-12 pr-4">
            <p className="text-[#1C1C1C]" style={{ lineHeight: '2' }}>
              {renderTextWithFormatting(line.replace('[QUOTE]', '').trim())}
            </p>
          </div>
        );
      }
      
      if (line.trim().length === 0) {
        return <div key={index} className="h-4" />;
      }
      
      return (
        <p key={index} className="mb-4 text-[#1C1C1C] indent-12" style={{ lineHeight: '2' }}>
          {renderTextWithFormatting(line)}
        </p>
      );
    });
  };

  return (
    <div className="bg-white rounded-lg border border-[#D7D7D2] p-12" style={{ fontFamily: "'Inter Tight', sans-serif" }}>
      {renderFormattedContent()}
    </div>
  );
}