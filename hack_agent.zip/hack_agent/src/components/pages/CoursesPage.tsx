import React, { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { StatusDot } from '../StatusDot';
import { YooniInput } from '../YooniInput';

const courses = [
  {
    id: 1,
    code: 'CS 224N',
    name: 'Natural Language Processing',
    progress: 65,
    hasUpdate: true,
  },
  {
    id: 2,
    code: 'CS 229',
    name: 'Machine Learning',
    progress: 58,
    hasUpdate: false,
  },
  {
    id: 3,
    code: 'PSYCH 254',
    name: 'Research Methods',
    progress: 72,
    hasUpdate: true,
  },
  {
    id: 4,
    code: 'PHIL 181',
    name: 'Philosophy of Mind',
    progress: 80,
    hasUpdate: false,
  },
];

export function CoursesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'updates'>('all');

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.code.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterType === 'all' || (filterType === 'updates' && course.hasUpdate);
    return matchesSearch && matchesFilter;
  });

  return (
    <div>
      <PageHeader title="Courses" />

      {/* Search and filters */}
      <div className="mb-8 flex items-center gap-4">
        <div className="flex-1 max-w-md">
          <YooniInput
            placeholder="Search courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setFilterType('all')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterType === 'all'
                ? 'bg-[#AEC8A6]/20 text-[#1C1C1C]'
                : 'text-[#1C1C1C]/60 hover:bg-[#D7D7D2]/30'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilterType('updates')}
            className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
              filterType === 'updates'
                ? 'bg-[#AEC8A6]/20 text-[#1C1C1C]'
                : 'text-[#1C1C1C]/60 hover:bg-[#D7D7D2]/30'
            }`}
          >
            New Updates
            {courses.filter((c) => c.hasUpdate).length > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#AEC8A6] text-[#1C1C1C] text-xs flex items-center justify-center">
                {courses.filter((c) => c.hasUpdate).length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Courses grid */}
      {filteredCourses.length > 0 ? (
        <div className="grid grid-cols-12 gap-8">
          {filteredCourses.map((course) => (
            <div key={course.id} className="col-span-12 md:col-span-6 lg:col-span-4">
              <YooniCard>
                <div className="mb-4 flex items-start justify-between">
                  <div>
                    <div className="text-sm text-[#1C1C1C]/60 mb-1">{course.code}</div>
                    <h3 className="text-[#1C1C1C]">{course.name}</h3>
                  </div>
                  {course.hasUpdate && <StatusDot />}
                </div>

                {/* Progress bar */}
                <div className="mb-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm text-[#1C1C1C]/60">Progress</div>
                    <div className="text-sm text-[#1C1C1C]/60">{course.progress}%</div>
                  </div>
                  <div className="w-full h-1 bg-[#D7D7D2] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#8BAA82] rounded-full"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>
              </YooniCard>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-[#1C1C1C]/60">No courses found matching your search.</p>
        </div>
      )}
    </div>
  );
}