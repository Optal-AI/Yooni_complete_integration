import React, { useState, useEffect, useRef } from 'react';
import { YooniCard } from '../YooniCard';
import { YooniButton } from '../YooniButton';
import { YooniTextarea } from '../YooniTextarea';
import { RichTextEditor } from '../RichTextEditor';
import { StatusTag } from '../StatusTag';
import { ScoreChip } from '../ScoreChip';
import { CitationManager } from '../CitationManager';
import { AutosaveIndicator } from '../AutosaveIndicator';
import { Breadcrumbs } from '../Breadcrumbs';
import { KeyboardShortcut, KeyboardShortcutBadge } from '../KeyboardShortcut';
import { ConfirmDialog } from '../ConfirmDialog';
import { Tooltip } from '../Tooltip';
import { FormattingToolbar, FormatType } from '../FormattingToolbar';
import { APAFormattedTextarea, APAPreviewPane } from '../APAFormattedTextarea';
import { 
  ArrowLeft, 
  FileText, 
  Save, 
  CheckCircle2,
  BookOpen,
  TrendingUp,
  Clock,
  Upload,
  Eye,
  ChevronDown,
  Maximize2,
  Minimize2,
  Download,
  History,
  RotateCcw,
  Target,
  Undo,
  Redo,
  Layout,
  Code,
  Sparkles,
  Loader2
} from 'lucide-react';

interface WritingProjectDetailPageProps {
  projectId: string;
  onBack: () => void;
  onCheckScore: () => void;
  improvedContent?: string | null;
  onClearImprovedContent: () => void;
}

interface Citation {
  id: string;
  authors: string;
  year: string;
  title: string;
  source: string;
  pages?: string;
  doi?: string;
  url?: string;
}

export function WritingProjectDetailPage({ projectId, onBack, onCheckScore, improvedContent, onClearImprovedContent }: WritingProjectDetailPageProps) {
  const initialContent = `The debate between free will and determinism has persisted throughout philosophical history, challenging our fundamental assumptions about human agency and moral responsibility. This essay advances the thesis that compatibilism offers the most coherent framework for understanding free will within a deterministic universe.

Determinism posits that every event, including human actions, is the inevitable result of prior causes. However, this need not negate free will if we reconceptualize freedom not as absolute independence from causation, but rather as the capacity to act in accordance with one's own rational desires and deliberative processes without external constraint.

Classical incompatibilists such as van Inwagen (1983) argue that if determinism is true, then our actions are the inevitable consequences of the laws of nature and events in the remote past. Therefore, we cannot be truly responsible for our actions since we had no control over these antecedent conditions.`;

  // Load content from localStorage if available
  const [content, setContent] = useState(() => {
    const saved = localStorage.getItem(`writing_content_${projectId}`);
    return saved || initialContent;
  });
  
  const [originalContent, setOriginalContent] = useState(content);
  const [lastSavedDate, setLastSavedDate] = useState<Date | null>(new Date());
  const [isSaving, setIsSaving] = useState(false);
  const [hasRubric, setHasRubric] = useState(() => {
    const rubric = localStorage.getItem(`rubric_content_${projectId}`);
    return !!rubric;
  });
  const [rubricName, setRubricName] = useState(() => {
    // Try to get rubric name from localStorage or use default
    const stored = localStorage.getItem(`rubric_name_${projectId}`);
    return stored || 'Research_Proposal_Rubric.pdf';
  });
  const [citationStyle, setCitationStyle] = useState<'APA' | 'MLA' | 'Chicago' | 'Harvard'>('APA');
  const [showCitationStyleMenu, setShowCitationStyleMenu] = useState(false);
  const [isFocusMode, setIsFocusMode] = useState(false);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);
  const [showRevertDialog, setShowRevertDialog] = useState(false);
  const [wordGoal, setWordGoal] = useState(1500);
  const [showFormattedView, setShowFormattedView] = useState(false);
  const [isImproving, setIsImproving] = useState(false);
  
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);

  // Apply improved content when available
  useEffect(() => {
    if (improvedContent) {
      setOriginalContent(content); // Save current before applying improvements
      setContent(improvedContent);
      handleSave();
    }
  }, [improvedContent]);

  const wordCount = content.trim().split(/\s+/).length;
  const charCount = content.length;
  const wordProgress = Math.min((wordCount / wordGoal) * 100, 100);

  const handleSave = () => {
    setIsSaving(true);
    // Save content to localStorage
    localStorage.setItem(`writing_content_${projectId}`, content);
    setTimeout(() => {
      setIsSaving(false);
      setLastSavedDate(new Date());
      setOriginalContent(content);
    }, 500);
  };

  const handleRevert = () => {
    setContent(originalContent);
    setShowRevertDialog(false);
  };

  // Format content in APA style
  const formatContentAsAPA = () => {
    const title = "Research Paper"; // Could be dynamic based on project
    const author = "Student Name";
    const institution = "University Name";
    const courseName = "Course Name";
    const instructor = "Instructor Name";
    const dueDate = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    
    return `${title}

${author}
${institution}
${courseName}
${instructor}
${dueDate}


${content}`;
  };

  // Export as PDF (opens print dialog)
  const handleExportPDF = () => {
    const apaContent = formatContentAsAPA();
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Export as PDF</title>
            <style>
              @page {
                margin: 1in;
              }
              body {
                font-family: 'Times New Roman', Times, serif;
                font-size: 12pt;
                line-height: 2;
                color: #000;
                max-width: 6.5in;
                margin: 0 auto;
              }
              h1 {
                text-align: center;
                font-weight: bold;
                font-size: 12pt;
                margin-bottom: 24pt;
              }
              .title-page {
                text-align: center;
                margin-top: 3in;
              }
              .title-page > div {
                margin-bottom: 12pt;
              }
              p {
                text-indent: 0.5in;
                margin: 0;
                text-align: left;
              }
              @media print {
                body { margin: 0; }
              }
            </style>
          </head>
          <body>
            <pre style="font-family: 'Times New Roman', Times, serif; white-space: pre-wrap; word-wrap: break-word;">${apaContent}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
      }, 250);
    }
    setShowExportMenu(false);
  };

  // Export as DOCX
  const handleExportDOCX = () => {
    const apaContent = formatContentAsAPA();
    // Create a simple Word-compatible HTML
    const docContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head>
          <meta charset='utf-8'>
          <title>Export Document</title>
          <style>
            body { 
              font-family: 'Times New Roman', Times, serif; 
              font-size: 12pt; 
              line-height: 2;
            }
            p { 
              margin: 0; 
              text-indent: 0.5in; 
            }
          </style>
        </head>
        <body>
          <pre style="font-family: 'Times New Roman', Times, serif; white-space: pre-wrap; word-wrap: break-word;">${apaContent}</pre>
        </body>
      </html>
    `;
    
    const blob = new Blob([docContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'paper.doc';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  // Export as TXT
  const handleExportTXT = () => {
    const apaContent = formatContentAsAPA();
    const blob = new Blob([apaContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'paper.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setShowExportMenu(false);
  };

  // Copy to Clipboard
  const handleCopyToClipboard = async () => {
    const apaContent = formatContentAsAPA();
    try {
      await navigator.clipboard.writeText(apaContent);
      // You could add a toast notification here
      setShowExportMenu(false);
    } catch (err) {
      console.error('Failed to copy to clipboard:', err);
    }
  };

  const handleInsertCitation = (citation: Citation, inTextFormat: string) => {
    const textarea = textareaRef.current;
    if (!textarea) {
      setContent(content + ' ' + inTextFormat);
      return;
    }

    // Use insertText to preserve undo stack
    textarea.focus();
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    
    // Insert text using execCommand to preserve undo
    const textToInsert = ' ' + inTextFormat;
    if (document.queryCommandSupported('insertText')) {
      document.execCommand('insertText', false, textToInsert);
    } else {
      // Fallback for browsers that don't support insertText
      const newContent = content.substring(0, start) + textToInsert + content.substring(end);
      setContent(newContent);
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + textToInsert.length;
      }, 0);
    }
  };

  const handleFormat = (format: FormatType, value?: string) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    textarea.focus();
    
    // Handle bold and italic with native browser commands
    if (format === 'bold') {
      document.execCommand('bold', false);
      return;
    }
    
    if (format === 'italic') {
      document.execCommand('italic', false);
      return;
    }

    // Handle all other formatting with text insertion
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);

    let formattedText = '';
    
    switch (format) {
      case 'title':
        formattedText = `[TITLE] ${selectedText || 'Your Title Here'}`;
        break;
      case 'author':
        formattedText = `[AUTHOR] ${selectedText || 'Author Name'}`;
        break;
      case 'institution':
        formattedText = `[INSTITUTION] ${selectedText || 'Institution Name'}`;
        break;
      case 'abstract':
        formattedText = `[ABSTRACT]\n${selectedText || 'Your abstract text here...'}`;
        break;
      case 'heading1':
        formattedText = `[H1] ${selectedText || 'Heading 1'}`;
        break;
      case 'heading2':
        formattedText = `[H2] ${selectedText || 'Heading 2'}`;
        break;
      case 'heading3':
        formattedText = `[H3] ${selectedText || 'Heading 3'}`;
        break;
      case 'heading4':
        formattedText = `[H4] ${selectedText || 'Heading 4'}`;
        break;
      case 'heading5':
        formattedText = `[H5] ${selectedText || 'Heading 5'}`;
        break;
      case 'blockquote':
        formattedText = `[QUOTE] ${selectedText || 'Block quote text here'}`;
        break;
      case 'bullet':
        formattedText = `• ${selectedText || 'List item'}`;
        break;
      case 'numbered':
        formattedText = `1. ${selectedText || 'List item'}`;
        break;
      case 'normal':
        formattedText = selectedText;
        break;
      default:
        return;
    }

    // Use insertText to preserve undo stack
    if (document.queryCommandSupported('insertText')) {
      // Select the range we want to replace
      textarea.setSelectionRange(start, end);
      // Insert the formatted text
      document.execCommand('insertText', false, formattedText);
      // Update React state to match
      setTimeout(() => {
        setContent(textarea.value);
      }, 0);
    } else {
      // Fallback for browsers that don't support insertText
      const beforeText = content.substring(0, start);
      const afterText = content.substring(end);
      const newContent = beforeText + formattedText + afterText;
      setContent(newContent);
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + formattedText.length;
      }, 0);
    }
  };

  return (
    <div className={isFocusMode ? 'fixed inset-0 bg-[#F5F5F2] z-50 overflow-auto' : ''}>
      {/* Keyboard Shortcuts */}
      <KeyboardShortcut keys={['mod', 's']} onTrigger={handleSave} />
      <KeyboardShortcut keys={['mod', 'k']} onTrigger={() => {/* Open citation search */}} />
      
      {/* Revert Confirmation Dialog */}
      <ConfirmDialog
        isOpen={showRevertDialog}
        onClose={() => setShowRevertDialog(false)}
        onConfirm={handleRevert}
        title="Revert to Previous Version?"
        description="This will replace your current content with the last saved version. This action cannot be undone."
        confirmLabel="Revert"
        cancelLabel="Cancel"
        variant="warning"
      />

      {isFocusMode ? (
        // Focus Mode UI
        <div className="max-w-4xl mx-auto px-12 py-12">
          <div className="flex items-center justify-between mb-8">
            <Breadcrumbs
              items={[
                { label: 'Writing Projects', onClick: onBack },
                { label: 'Research Proposal' }
              ]}
            />
            <div className="flex items-center gap-3">
              <AutosaveIndicator isSaving={isSaving} lastSaved={lastSavedDate} />
              <Tooltip content="Exit Focus Mode">
                <button
                  onClick={() => setIsFocusMode(false)}
                  className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
                >
                  <Minimize2 className="w-5 h-5 text-[#1C1C1C]/60" strokeWidth={1.5} />
                </button>
              </Tooltip>
            </div>
          </div>

          {/* Word Goal Progress */}
          <div className="mb-6 p-4 bg-white rounded-lg border border-[#D7D7D2]">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                <span className="text-[14px] text-[#1C1C1C]">
                  {wordCount} / {wordGoal} words
                </span>
              </div>
              <span className="text-[13px] text-[#1C1C1C]/60">
                {Math.round(wordProgress)}%
              </span>
            </div>
            <div className="w-full h-2 bg-[#D7D7D2]/30 rounded-full overflow-hidden">
              <div 
                className="h-full bg-[#AEC8A6] rounded-full transition-all duration-500"
                style={{ width: `${wordProgress}%` }}
              />
            </div>
          </div>

          <YooniTextarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={28}
            placeholder="Start writing your project..."
            className="font-serif text-[16px]"
          />
        </div>
      ) : (
        // Normal Mode UI
        <div className="max-w-[1200px] mx-auto">
          {/* Breadcrumbs */}
          <Breadcrumbs
            items={[
              { label: 'Writing Projects', onClick: onBack },
              { label: 'Research Proposal' }
            ]}
          />

          {/* Header */}
          <div className="mb-8">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-[#8BAA82]" strokeWidth={1.5} />
                </div>
                <div>
                  <h1 className="text-[#1C1C1C] mb-2">Research Proposal</h1>
                  <p className="text-[#1C1C1C]/60">Neural approaches to sentiment analysis</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <StatusTag label="Draft" variant="status" />
                <AutosaveIndicator isSaving={isSaving} lastSaved={lastSavedDate} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-12 gap-6">
            {/* Main Content Area */}
            <div className="col-span-12 lg:col-span-8">
              {/* Stats Bar */}
              <div className="grid grid-cols-4 gap-4 mb-6">
                <YooniCard>
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-[#AEC8A6]" strokeWidth={1.5} />
                    <div>
                      <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-0.5" style={{ fontWeight: 600 }}>
                        Words
                      </div>
                      <div className="text-[20px] text-[#1C1C1C]" style={{ fontWeight: 600 }}>
                        {wordCount.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </YooniCard>

                <YooniCard>
                  <div className="flex items-center gap-3">
                    <Target className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                    <div>
                      <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-0.5" style={{ fontWeight: 600 }}>
                        Goal
                      </div>
                      <div className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                        {Math.round(wordProgress)}%
                      </div>
                    </div>
                  </div>
                </YooniCard>

                <YooniCard>
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                    <div>
                      <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-0.5" style={{ fontWeight: 600 }}>
                        Due
                      </div>
                      <div className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                        Nov 22
                      </div>
                    </div>
                  </div>
                </YooniCard>

                <YooniCard>
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-5 h-5 text-[#AEC8A6]" strokeWidth={1.5} />
                    <div>
                      <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-0.5" style={{ fontWeight: 600 }}>
                        Citations
                      </div>
                      <div className="text-[20px] text-[#1C1C1C]" style={{ fontWeight: 600 }}>
                        3
                      </div>
                    </div>
                  </div>
                </YooniCard>
              </div>

              {/* Word Goal Progress */}
              <div className="mb-6 p-4 bg-white rounded-lg border border-[#D7D7D2]">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                    <span className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                      Word Goal: {wordCount} / {wordGoal}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      const newGoal = prompt('Set word goal:', wordGoal.toString());
                      if (newGoal) setWordGoal(parseInt(newGoal));
                    }}
                    className="text-[13px] text-[#8BAA82] hover:text-[#1C1C1C] transition-colors"
                  >
                    Edit Goal
                  </button>
                </div>
                <div className="w-full h-2 bg-[#D7D7D2]/30 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[#AEC8A6] rounded-full transition-all duration-500"
                    style={{ width: `${wordProgress}%` }}
                  />
                </div>
              </div>

              {/* Success Banner - Improved Content Applied */}
              {improvedContent && (
                <div className="mb-6 p-5 bg-[#AEC8A6]/10 rounded-lg border border-[#AEC8A6]/30 animate-in fade-in duration-300">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-[#8BAA82] flex-shrink-0 mt-0.5" strokeWidth={1.5} />
                    <div className="flex-1">
                      <div className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                        Improvements Applied!
                      </div>
                      <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed mb-3">
                        Your essay has been updated with the improved version. Review the changes and continue editing as needed.
                      </p>
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => setShowRevertDialog(true)}
                          className="text-[14px] text-[#1C1C1C]/60 hover:text-[#1C1C1C] transition-colors flex items-center gap-1.5"
                        >
                          <Undo className="w-3.5 h-3.5" strokeWidth={1.5} />
                          Revert
                        </button>
                        <span className="text-[#1C1C1C]/30">|</span>
                        <button
                          onClick={onClearImprovedContent}
                          className="text-[14px] text-[#8BAA82] hover:text-[#1C1C1C] transition-colors"
                          style={{ fontWeight: 500 }}
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Writing Area */}
              <YooniCard className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <h3 className="text-[#1C1C1C]">Your Writing</h3>
                    <span className="text-[13px] text-[#1C1C1C]/40">
                      {charCount.toLocaleString()} characters
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tooltip content="Toggle Formatted View">
                      <button
                        onClick={() => setShowFormattedView(!showFormattedView)}
                        className={`p-2 rounded-lg transition-colors ${
                          showFormattedView 
                            ? 'bg-[#AEC8A6]/20 text-[#8BAA82]' 
                            : 'hover:bg-[#D7D7D2]/30 text-[#1C1C1C]/60'
                        }`}
                      >
                        {showFormattedView ? (
                          <Code className="w-4 h-4" strokeWidth={1.5} />
                        ) : (
                          <Layout className="w-4 h-4" strokeWidth={1.5} />
                        )}
                      </button>
                    </Tooltip>
                    <Tooltip content={`Focus Mode (⌘+Shift+F)`}>
                      <button
                        onClick={() => setIsFocusMode(true)}
                        className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
                      >
                        <Maximize2 className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                      </button>
                    </Tooltip>
                  </div>
                </div>

                {/* Formatting Toolbar */}
                {!showFormattedView && (
                  <FormattingToolbar 
                    onFormat={handleFormat}
                    citationStyle={citationStyle}
                  />
                )}

                {/* Editor or Preview */}
                {showFormattedView ? (
                  <APAPreviewPane content={content} />
                ) : (
                  <YooniTextarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={20}
                    placeholder="Start writing your project..."
                    className="font-serif"
                    ref={textareaRef}
                  />
                )}
                
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center gap-3">
                    <YooniButton variant="primary" onClick={handleSave}>
                      <Save className="w-4 h-4 mr-2" strokeWidth={1.5} />
                      Save
                    </YooniButton>
                    <div className="flex items-center gap-2 text-[13px] text-[#1C1C1C]/50">
                      <KeyboardShortcutBadge keys={['mod', 's']} />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Tooltip content="Version History">
                      <button
                        onClick={() => setShowVersionHistory(true)}
                        className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
                      >
                        <History className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                      </button>
                    </Tooltip>
                    <div className="relative">
                      <Tooltip content="Export">
                        <button
                          onClick={() => setShowExportMenu(!showExportMenu)}
                          className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
                        >
                          <Download className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                        </button>
                      </Tooltip>
                      {showExportMenu && (
                        <div className="absolute right-0 top-full mt-2 bg-white border border-[#D7D7D2] rounded-lg shadow-lg z-10 overflow-hidden w-48 animate-in fade-in zoom-in-95 duration-150">
                          <button className="block w-full px-4 py-3 text-left text-[14px] text-[#1C1C1C] hover:bg-[#AEC8A6]/10 transition-colors" onClick={handleExportPDF}>
                            Export as PDF
                          </button>
                          <button className="block w-full px-4 py-3 text-left text-[14px] text-[#1C1C1C] hover:bg-[#AEC8A6]/10 transition-colors" onClick={handleExportDOCX}>
                            Export as DOCX
                          </button>
                          <button className="block w-full px-4 py-3 text-left text-[14px] text-[#1C1C1C] hover:bg-[#AEC8A6]/10 transition-colors" onClick={handleExportTXT}>
                            Export as TXT
                          </button>
                          <button className="block w-full px-4 py-3 text-left text-[14px] text-[#1C1C1C] hover:bg-[#AEC8A6]/10 transition-colors border-t border-[#D7D7D2]" onClick={handleCopyToClipboard}>
                            Copy to Clipboard
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </YooniCard>
            </div>

            {/* Sidebar */}
            <div className="col-span-12 lg:col-span-4">
              {/* Please Fix Button Card - Always visible at top */}
              <YooniCard className="mb-6" topAccent>
                <div className="flex items-start gap-3 mb-4">
                  <Sparkles className="w-5 h-5 text-[#8BAA82] mt-0.5" strokeWidth={1.5} />
                  <div className="flex-1">
                    <h3 className="text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                      Improve Your Writing
                    </h3>
                    <p className="text-[13px] text-[#1C1C1C]/60 mb-3">
                      {isImproving 
                        ? 'Rewriting your text with AI...'
                        : hasRubric 
                          ? `Using uploaded rubric: ${rubricName}`
                          : 'Using default academic rubric for research papers'}
                    </p>
                  </div>
                </div>
                
                {isImproving && (
                  <div className="mb-4 p-3 rounded-lg bg-[#AEC8A6]/10 border border-[#AEC8A6]/20">
                    <div className="flex items-center gap-2 text-[#8BAA82]">
                      <Loader2 className="w-4 h-4 animate-spin" strokeWidth={1.5} />
                      <span className="text-[13px]">Processing your writing with AI. This may take a moment...</span>
                    </div>
                  </div>
                )}
                
                <YooniButton 
                  variant="primary" 
                  className="w-full"
                  disabled={isImproving}
                  onClick={async () => {
                    if (!content || content.trim().length === 0) {
                      alert('Please add some writing content first');
                      return;
                    }

                    setIsImproving(true);
                    try {
                      // Save current content first
                      localStorage.setItem(`writing_content_${projectId}`, content);
                      
                      // Get rubric content - check uploaded first, otherwise backend will use default
                      const rubricContent = localStorage.getItem(`rubric_content_${projectId}`) || undefined;

                      // Call improve writing - backend will use default rubric if none provided
                      const { improveWriting } = await import('../../services/writingService');
                      const result = await improveWriting(content, rubricContent || undefined);

                      if (result.success && result.improved_content) {
                        // Apply improved content
                        setOriginalContent(content);
                        setContent(result.improved_content);
                        localStorage.setItem(`writing_content_${projectId}`, result.improved_content);
                        handleSave();
                        
                        alert('Writing improved successfully! Review the changes in the editor.');
                      } else {
                        alert(result.error || 'Failed to improve writing. Please try again.');
                      }
                    } catch (error) {
                      console.error('Error improving writing:', error);
                      const errorMessage = error instanceof Error ? error.message : 'Failed to improve writing';
                      if (errorMessage.includes('fetch')) {
                        alert('Failed to connect to backend. Please make sure the server is running on port 5001.');
                      } else {
                        alert(errorMessage + '. Please try again.');
                      }
                    } finally {
                      setIsImproving(false);
                    }
                  }}
                >
                  {isImproving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" strokeWidth={1.5} />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" strokeWidth={1.5} />
                      Please Fix
                    </>
                  )}
                </YooniButton>
              </YooniCard>

              {/* Rubric Card */}
              {hasRubric && (
                <YooniCard className="mb-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-9 h-9 rounded-lg bg-[#AEC8A6]/15 flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                        Rubric Active
                      </h3>
                      <p className="text-[13px] text-[#1C1C1C]/60 mb-3">
                        {rubricName}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#D7D7D2] space-y-3">
                    <YooniButton variant="primary" onClick={onCheckScore} className="w-full">
                      <TrendingUp className="w-4 h-4 mr-2" strokeWidth={1.5} />
                      Check Score
                    </YooniButton>
                    <YooniButton variant="secondary" className="w-full">
                      <Eye className="w-4 h-4 mr-2" strokeWidth={1.5} />
                      View Rubric
                    </YooniButton>
                  </div>
                </YooniCard>
              )}

              {/* Rubric Upload Card */}
              <YooniCard className="mb-6">
                <div className="flex items-start gap-3 mb-4">
                  {hasRubric ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-[#8BAA82] mt-0.5" strokeWidth={1.5} />
                      <div className="flex-1">
                        <h3 className="text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                          Rubric Uploaded
                        </h3>
                        <p className="text-[13px] text-[#1C1C1C]/60 mb-3">
                          {rubricName}
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <BookOpen className="w-5 h-5 text-[#1C1C1C]/40 mt-0.5" strokeWidth={1.5} />
                      <div className="flex-1">
                        <h3 className="text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                          Upload Rubric (Optional)
                        </h3>
                        <p className="text-[13px] text-[#1C1C1C]/60 mb-3">
                          Upload a PDF rubric for custom evaluation. Default academic rubric will be used if none is uploaded.
                        </p>
                      </div>
                    </>
                  )}
                </div>
                
                <input
                  type="file"
                  accept=".pdf"
                  className="hidden"
                  id="rubric-upload-detail"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      try {
                        const { uploadRubric } = await import('../../services/writingService');
                        const result = await uploadRubric(file);
                        
                        if (result.success && result.rubric_content) {
                          localStorage.setItem(`rubric_content_${projectId}`, result.rubric_content);
                          localStorage.setItem(`rubric_name_${projectId}`, result.filename || file.name);
                          setHasRubric(true);
                          setRubricName(result.filename || file.name);
                        } else {
                          alert(result.error || 'Failed to upload rubric');
                        }
                      } catch (error) {
                        console.error('Error uploading rubric:', error);
                        alert('Failed to upload rubric. Please try again.');
                      }
                    }
                    e.target.value = '';
                  }}
                />
                <label htmlFor="rubric-upload-detail">
                  <YooniButton variant={hasRubric ? "secondary" : "primary"} as="span" className="w-full">
                    <Upload className="w-4 h-4 mr-2" strokeWidth={1.5} />
                    {hasRubric ? 'Replace Rubric' : 'Upload Rubric (PDF)'}
                  </YooniButton>
                </label>
                {hasRubric && (
                  <button
                    onClick={() => {
                      localStorage.removeItem(`rubric_content_${projectId}`);
                      localStorage.removeItem(`rubric_name_${projectId}`);
                      setHasRubric(false);
                      setRubricName('Research_Proposal_Rubric.pdf');
                    }}
                    className="mt-2 w-full text-[13px] text-[#1C1C1C]/50 hover:text-[#1C1C1C] transition-colors"
                  >
                    Remove Rubric
                  </button>
                )}
              </YooniCard>

              {/* Writing Tips */}
              <YooniCard className="mb-6">
                <h3 className="text-[#1C1C1C] mb-4" style={{ fontWeight: 500 }}>
                  Writing Tips
                </h3>
                <div className="space-y-3 text-[13px] text-[#1C1C1C]/70 leading-relaxed">
                  <p>
                    • Focus on clear thesis statements in your introduction
                  </p>
                  <p>
                    • Use specific citations to support your arguments
                  </p>
                  <p>
                    • Include transitions between paragraphs for better flow
                  </p>
                  <p>
                    • Address counter-arguments to strengthen your position
                  </p>
                </div>
              </YooniCard>

              {/* Citation Style Selector & Manager */}
              <div className="mb-4">
                <YooniCard>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-[#1C1C1C]">Citation Format</h3>
                  </div>
                  <div className="relative">
                    <button
                      onClick={() => setShowCitationStyleMenu(!showCitationStyleMenu)}
                      className="w-full px-4 py-3 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2] text-left flex items-center justify-between hover:border-[#AEC8A6] transition-colors"
                    >
                      <span className="text-[#1C1C1C]">{citationStyle}</span>
                      <ChevronDown className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
                    </button>
                    {showCitationStyleMenu && (
                      <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-[#D7D7D2] rounded-lg shadow-lg z-10 overflow-hidden">
                        {(['APA', 'MLA', 'Chicago', 'Harvard'] as const).map((style) => (
                          <button
                            key={style}
                            className="block w-full px-4 py-3 text-left text-[#1C1C1C] hover:bg-[#AEC8A6]/10 transition-colors"
                            onClick={() => {
                              setCitationStyle(style);
                              setShowCitationStyleMenu(false);
                            }}
                          >
                            <div className="flex items-center justify-between">
                              <span>{style}</span>
                              {citationStyle === style && (
                                <CheckCircle2 className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                              )}
                            </div>
                            <div className="text-[12px] text-[#1C1C1C]/50 mt-0.5">
                              {style === 'APA' && 'American Psychological Association'}
                              {style === 'MLA' && 'Modern Language Association'}
                              {style === 'Chicago' && 'Chicago Manual of Style'}
                              {style === 'Harvard' && 'Harvard Referencing'}
                            </div>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </YooniCard>
              </div>

              {/* Citation Manager */}
              <CitationManager
                citationStyle={citationStyle}
                onInsertCitation={handleInsertCitation}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}