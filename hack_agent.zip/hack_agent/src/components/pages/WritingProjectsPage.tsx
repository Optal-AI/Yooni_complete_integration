import React, { useState, useEffect } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { YooniButton } from '../YooniButton';
import { StatusTag } from '../StatusTag';
import { 
  FileText, 
  Upload, 
  Plus, 
  BookOpen, 
  CheckCircle2,
  AlertCircle,
  X
} from 'lucide-react';

interface WritingProject {
  id: string;
  title: string;
  description: string;
  wordCount: number;
  status: 'outline' | 'draft' | 'review' | 'final';
  dueDate: string;
  hasRubric: boolean;
  rubricName?: string;
  lastModified: string;
}

interface WritingProjectsPageProps {
  onOpenProject: (projectId: string) => void;
  onCheckScore: (projectId: string) => void;
}

export function WritingProjectsPage({ onOpenProject, onCheckScore }: WritingProjectsPageProps) {
  const [showNewProjectForm, setShowNewProjectForm] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [uploadingRubricFor, setUploadingRubricFor] = useState<string | null>(null);
  const [newProjectRubric, setNewProjectRubric] = useState<File | null>(null);
  const [newProjectPaper, setNewProjectPaper] = useState<File | null>(null);
  const [newProjectPastedText, setNewProjectPastedText] = useState('');
  const [paperInputMethod, setPaperInputMethod] = useState<'upload' | 'paste'>('paste');
  const [newProjectTitle, setNewProjectTitle] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');
  const [newProjectDueDate, setNewProjectDueDate] = useState('');
  const [newProjectStatus, setNewProjectStatus] = useState<'outline' | 'draft' | 'review' | 'final'>('draft');
  // Load projects from localStorage or use defaults
  const [projects, setProjects] = useState<WritingProject[]>(() => {
    try {
      const saved = localStorage.getItem('writing_projects');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (error) {
      console.error('Error loading projects from localStorage:', error);
    }
    // Default projects
    return [
      {
        id: '1',
        title: 'Research Proposal',
        description: 'Neural approaches to sentiment analysis',
        wordCount: 3247,
        status: 'draft',
        dueDate: 'Nov 22, 2025',
        hasRubric: true,
        rubricName: 'Research_Proposal_Rubric.pdf',
        lastModified: '2 hours ago'
      },
      {
        id: '2',
        title: 'Literature Review',
        description: 'Transformer architectures survey',
        wordCount: 5892,
        status: 'review',
        dueDate: 'Nov 28, 2025',
        hasRubric: false,
        lastModified: '1 day ago'
      },
      {
        id: '3',
        title: 'Methodology Section',
        description: 'Experimental design outline',
        wordCount: 1423,
        status: 'outline',
        dueDate: 'Dec 5, 2025',
        hasRubric: false,
        lastModified: '3 days ago'
      }
    ];
  });

  // Save projects to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('writing_projects', JSON.stringify(projects));
    } catch (error) {
      console.error('Error saving projects to localStorage:', error);
    }
  }, [projects]);

  const handleRubricUpload = async (projectId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        // Import uploadRubric function
        const { uploadRubric } = await import('../../services/writingService');
        const result = await uploadRubric(file);
        
        if (result.success && result.rubric_content) {
          // Store rubric content and name in localStorage
          localStorage.setItem(`rubric_content_${projectId}`, result.rubric_content);
          localStorage.setItem(`rubric_name_${projectId}`, result.filename || file.name);
          
          // Update project state
          setProjects(projects.map(p => 
            p.id === projectId 
              ? { ...p, hasRubric: true, rubricName: result.filename || file.name }
              : p
          ));
        } else {
          alert(result.error || 'Failed to upload rubric');
        }
      } catch (error) {
        console.error('Error uploading rubric:', error);
        alert('Failed to upload rubric. Please try again.');
      } finally {
        setUploadingRubricFor(null);
        event.target.value = '';
      }
    }
  };

  const handleRemoveRubric = (projectId: string) => {
    setProjects(projects.map(p => 
      p.id === projectId 
        ? { ...p, hasRubric: false, rubricName: undefined }
        : p
    ));
    localStorage.removeItem(`rubric_content_${projectId}`);
    localStorage.removeItem(`rubric_name_${projectId}`);
  };

  const handleCreateProject = async () => {
    if (!newProjectTitle.trim()) {
      alert('Please enter a project title');
      return;
    }

    try {
      // Generate new project ID
      const newProjectId = Date.now().toString();
      
      // Handle rubric upload if provided
      if (newProjectRubric) {
        try {
          const { uploadRubric } = await import('../../services/writingService');
          const result = await uploadRubric(newProjectRubric);
          
          if (result.success && result.rubric_content) {
            localStorage.setItem(`rubric_content_${newProjectId}`, result.rubric_content);
            localStorage.setItem(`rubric_name_${newProjectId}`, result.filename || newProjectRubric.name);
          }
        } catch (error) {
          console.error('Error uploading rubric:', error);
          // Continue creating project even if rubric upload fails
        }
      }

      // Handle paper content if provided
      let initialContent = '';
      if (paperInputMethod === 'paste' && newProjectPastedText.trim()) {
        initialContent = newProjectPastedText.trim();
      } else if (paperInputMethod === 'upload' && newProjectPaper) {
        // For uploaded files, we'd need to extract text, but for now just save the file reference
        // The user can open the project and paste content
        initialContent = '';
      }

      // Save initial content if provided
      if (initialContent) {
        localStorage.setItem(`writing_content_${newProjectId}`, initialContent);
      }

      // Calculate word count
      const wordCount = initialContent ? initialContent.trim().split(/\s+/).length : 0;

      // Format due date
      let formattedDueDate = newProjectDueDate;
      if (newProjectDueDate) {
        try {
          const date = new Date(newProjectDueDate);
          formattedDueDate = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        } catch {
          // Keep original if parsing fails
        }
      } else {
        formattedDueDate = 'No due date';
      }

      // Create new project
      const newProject: WritingProject = {
        id: newProjectId,
        title: newProjectTitle.trim(),
        description: newProjectDescription.trim() || 'No description',
        wordCount: wordCount,
        status: newProjectStatus,
        dueDate: formattedDueDate,
        hasRubric: !!newProjectRubric,
        rubricName: newProjectRubric ? (newProjectRubric.name) : undefined,
        lastModified: 'Just now'
      };

      // Add to projects list
      setProjects([newProject, ...projects]);

      // Save to localStorage
      try {
        const savedProjects = localStorage.getItem('writing_projects');
        const projectsList = savedProjects ? JSON.parse(savedProjects) : [];
        projectsList.unshift(newProject);
        localStorage.setItem('writing_projects', JSON.stringify(projectsList));
      } catch (error) {
        console.error('Error saving projects to localStorage:', error);
      }

      // Reset form
      setNewProjectTitle('');
      setNewProjectDescription('');
      setNewProjectDueDate('');
      setNewProjectStatus('draft');
      setNewProjectRubric(null);
      setNewProjectPaper(null);
      setNewProjectPastedText('');
      setPaperInputMethod('paste');
      setShowNewProjectForm(false);

      alert('Project created successfully!');
    } catch (error) {
      console.error('Error creating project:', error);
      alert('Failed to create project. Please try again.');
    }
  };

  const getStatusVariant = (status: WritingProject['status']) => {
    switch (status) {
      case 'outline': return 'status';
      case 'draft': return 'status';
      case 'review': return 'due';
      case 'final': return 'priority';
      default: return 'status';
    }
  };

  const getStatusLabel = (status: WritingProject['status']) => {
    switch (status) {
      case 'outline': return 'Outline';
      case 'draft': return 'Draft';
      case 'review': return 'In Review';
      case 'final': return 'Final';
      default: return status;
    }
  };

  return (
    <div>
      <PageHeader 
        title="Writing Projects" 
        subtitle="Manage your writing assignments and rubrics."
      />

      {/* Quick Actions */}
      <div className="mb-8">
        <YooniButton 
          variant="primary"
          onClick={() => setShowNewProjectForm(!showNewProjectForm)}
        >
          <Plus className="w-4 h-4 mr-2" strokeWidth={1.5} />
          New Writing Project
        </YooniButton>
      </div>

      {/* New Project Form */}
      {showNewProjectForm && (
        <YooniCard className="mb-8 border-[#AEC8A6]">
          <div className="flex items-start justify-between mb-4">
            <h3 className="text-[#1C1C1C]">Create New Project</h3>
            <button
              onClick={() => setShowNewProjectForm(false)}
              className="text-[#1C1C1C]/40 hover:text-[#1C1C1C]"
            >
              <X className="w-5 h-5" strokeWidth={1.5} />
            </button>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-[#1C1C1C]/60 mb-2">Project Title</label>
              <input
                type="text"
                value={newProjectTitle}
                onChange={(e) => setNewProjectTitle(e.target.value)}
                placeholder="e.g., Research Proposal, Essay, Literature Review..."
                className="w-full px-4 py-2.5 rounded-lg border border-[#D7D7D2] bg-white text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:border-[#AEC8A6]"
              />
            </div>
            
            <div>
              <label className="block text-sm text-[#1C1C1C]/60 mb-2">Description</label>
              <input
                type="text"
                value={newProjectDescription}
                onChange={(e) => setNewProjectDescription(e.target.value)}
                placeholder="Brief description of the project..."
                className="w-full px-4 py-2.5 rounded-lg border border-[#D7D7D2] bg-white text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:border-[#AEC8A6]"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-[#1C1C1C]/60 mb-2">Due Date</label>
                <input
                  type="date"
                  value={newProjectDueDate}
                  onChange={(e) => setNewProjectDueDate(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-lg border border-[#D7D7D2] bg-white text-[#1C1C1C] focus:outline-none focus:border-[#AEC8A6]"
                />
              </div>
              
              <div>
                <label className="block text-sm text-[#1C1C1C]/60 mb-2">Status</label>
                <select 
                  value={newProjectStatus}
                  onChange={(e) => setNewProjectStatus(e.target.value as 'outline' | 'draft' | 'review' | 'final')}
                  className="w-full px-4 py-2.5 rounded-lg border border-[#D7D7D2] bg-white text-[#1C1C1C] focus:outline-none focus:border-[#AEC8A6]"
                >
                  <option value="outline">Outline</option>
                  <option value="draft">Draft</option>
                  <option value="review">In Review</option>
                  <option value="final">Final</option>
                </select>
              </div>
            </div>

            {/* Rubric Upload (Optional) */}
            <div>
              <label className="block text-sm text-[#1C1C1C]/60 mb-2">
                Rubric (Optional)
              </label>
              {newProjectRubric ? (
                <div className="flex items-center justify-between px-4 py-3 rounded-lg border border-[#AEC8A6] bg-[#AEC8A6]/5">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#AEC8A6]/15 flex items-center justify-center">
                      <CheckCircle2 className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                    </div>
                    <div>
                      <div className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                        {newProjectRubric.name}
                      </div>
                      <div className="text-[12px] text-[#1C1C1C]/50">
                        {(newProjectRubric.size / 1024).toFixed(1)} KB
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => setNewProjectRubric(null)}
                    className="p-2 text-[#1C1C1C]/40 hover:text-[#1C1C1C] rounded-lg hover:bg-white transition-colors"
                  >
                    <X className="w-4 h-4" strokeWidth={1.5} />
                  </button>
                </div>
              ) : (
                <div>
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setNewProjectRubric(file);
                    }}
                    className="hidden"
                    id="new-project-rubric"
                  />
                  <label 
                    htmlFor="new-project-rubric"
                    className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-lg border-2 border-dashed border-[#D7D7D2] hover:border-[#AEC8A6] hover:bg-[#AEC8A6]/5 text-[#1C1C1C]/60 hover:text-[#1C1C1C] cursor-pointer transition-colors"
                  >
                    <Upload className="w-4 h-4" strokeWidth={1.5} />
                    <span className="text-[14px]">Upload rubric PDF</span>
                  </label>
                  <p className="text-[12px] text-[#1C1C1C]/40 mt-2">
                    Optional: Upload a PDF rubric for custom evaluation. Default academic rubric will be used if none is uploaded.
                  </p>
                </div>
              )}
            </div>

            {/* Paper Input (Optional) */}
            <div>
              <label className="block text-sm text-[#1C1C1C]/60 mb-2">
                Existing Paper (Optional)
              </label>
              
              {/* Toggle between Upload and Paste */}
              <div className="flex items-center gap-4 mb-3">
                <button
                  onClick={() => setPaperInputMethod('paste')}
                  className={`px-3 py-1.5 rounded-lg text-[13px] transition-colors ${
                    paperInputMethod === 'paste' 
                      ? 'bg-[#AEC8A6]/15 text-[#1C1C1C]' 
                      : 'bg-transparent text-[#1C1C1C]/50 hover:text-[#1C1C1C]'
                  }`}
                >
                  Paste Text
                </button>
                <button
                  onClick={() => setPaperInputMethod('upload')}
                  className={`px-3 py-1.5 rounded-lg text-[13px] transition-colors ${
                    paperInputMethod === 'upload' 
                      ? 'bg-[#AEC8A6]/15 text-[#1C1C1C]' 
                      : 'bg-transparent text-[#1C1C1C]/50 hover:text-[#1C1C1C]'
                  }`}
                >
                  Upload File
                </button>
              </div>

              {paperInputMethod === 'paste' ? (
                <div>
                  <textarea
                    value={newProjectPastedText}
                    onChange={(e) => setNewProjectPastedText(e.target.value)}
                    placeholder="Paste your existing paper text here..."
                    className="w-full px-4 py-3 rounded-lg border border-[#D7D7D2] bg-white text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:border-[#AEC8A6] resize-none"
                    rows={8}
                  />
                  {newProjectPastedText && (
                    <div className="flex items-center justify-between mt-2">
                      <p className="text-[12px] text-[#1C1C1C]/50">
                        {newProjectPastedText.trim().split(/\s+/).length} words
                      </p>
                      <button
                        onClick={() => setNewProjectPastedText('')}
                        className="text-[12px] text-[#1C1C1C]/40 hover:text-[#1C1C1C] transition-colors"
                      >
                        Clear
                      </button>
                    </div>
                  )}
                  <p className="text-[12px] text-[#1C1C1C]/40 mt-2">
                    Paste your paper content to import it into Yooni for editing and analysis.
                  </p>
                </div>
              ) : (
                newProjectPaper ? (
                  <div className="flex items-center justify-between px-4 py-3 rounded-lg border border-[#AEC8A6] bg-[#AEC8A6]/5">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#AEC8A6]/15 flex items-center justify-center">
                        <FileText className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                      </div>
                      <div>
                        <div className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                          {newProjectPaper.name}
                        </div>
                        <div className="text-[12px] text-[#1C1C1C]/50">
                          {(newProjectPaper.size / 1024).toFixed(1)} KB
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => setNewProjectPaper(null)}
                      className="p-2 text-[#1C1C1C]/40 hover:text-[#1C1C1C] rounded-lg hover:bg-white transition-colors"
                    >
                      <X className="w-4 h-4" strokeWidth={1.5} />
                    </button>
                  </div>
                ) : (
                  <div>
                    <input
                      type="file"
                      accept=".pdf,.docx,.doc,.txt"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) setNewProjectPaper(file);
                      }}
                      className="hidden"
                      id="new-project-paper"
                    />
                    <label 
                      htmlFor="new-project-paper"
                      className="flex items-center justify-center gap-2 w-full px-4 py-3 rounded-lg border-2 border-dashed border-[#D7D7D2] hover:border-[#AEC8A6] hover:bg-[#AEC8A6]/5 text-[#1C1C1C]/60 hover:text-[#1C1C1C] cursor-pointer transition-colors"
                    >
                      <Upload className="w-4 h-4" strokeWidth={1.5} />
                      <span className="text-[14px]">Upload existing paper (PDF, DOCX, or TXT)</span>
                    </label>
                    <p className="text-[12px] text-[#1C1C1C]/40 mt-2">
                      Upload an existing paper file to import it into Yooni for editing and analysis.
                    </p>
                  </div>
                )
              )}
            </div>
            
            <div className="flex gap-3 pt-4">
              <YooniButton variant="primary" onClick={handleCreateProject}>
                Create Project
              </YooniButton>
              <YooniButton variant="secondary" onClick={() => {
                setShowNewProjectForm(false);
                // Reset form
                setNewProjectTitle('');
                setNewProjectDescription('');
                setNewProjectDueDate('');
                setNewProjectStatus('draft');
                setNewProjectRubric(null);
                setNewProjectPaper(null);
                setNewProjectPastedText('');
                setPaperInputMethod('paste');
              }}>
                Cancel
              </YooniButton>
            </div>
          </div>
        </YooniCard>
      )}

      {/* Projects Grid */}
      <div className="grid grid-cols-1 gap-6">
        {projects.map((project) => (
          <YooniCard 
            key={project.id} 
            hover
            className={selectedProject === project.id ? 'border-[#AEC8A6]' : ''}
          >
            {/* Header Section */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-4 flex-1">
                <div className="w-11 h-11 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center flex-shrink-0">
                  <FileText className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                </div>
                <div className="flex-1">
                  <h3 className="text-[18px] text-[#1C1C1C] mb-1.5" style={{ fontWeight: 500 }}>
                    {project.title}
                  </h3>
                  <p className="text-[14px] text-[#1C1C1C]/60 leading-relaxed">
                    {project.description}
                  </p>
                </div>
              </div>
              <StatusTag 
                label={getStatusLabel(project.status)} 
                variant={getStatusVariant(project.status)}
              />
            </div>

            {/* Metadata Row */}
            <div className="flex items-center gap-8 mb-6 px-[60px]">
              <div>
                <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-1" style={{ fontWeight: 600 }}>
                  Words
                </div>
                <div className="text-[15px] text-[#1C1C1C]">
                  {project.wordCount.toLocaleString()}
                </div>
              </div>
              <div className="h-8 w-px bg-[#D7D7D2]" />
              <div>
                <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-1" style={{ fontWeight: 600 }}>
                  Due Date
                </div>
                <div className="text-[15px] text-[#1C1C1C]">
                  {project.dueDate}
                </div>
              </div>
              <div className="h-8 w-px bg-[#D7D7D2]" />
              <div>
                <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/40 mb-1" style={{ fontWeight: 600 }}>
                  Modified
                </div>
                <div className="text-[15px] text-[#1C1C1C]/60">
                  {project.lastModified}
                </div>
              </div>
            </div>

            {/* Rubric Section */}
            <div className="px-[60px] py-5 bg-[#F5F5F2] -mx-6 -mb-6 rounded-b-lg border-t border-[#D7D7D2]">
              {project.hasRubric ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#AEC8A6]/15 flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                    </div>
                    <div>
                      <div className="text-[14px] text-[#1C1C1C] mb-0.5" style={{ fontWeight: 500 }}>
                        Rubric Uploaded
                      </div>
                      <div className="text-[13px] text-[#1C1C1C]/50">
                        {project.rubricName}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <YooniButton 
                      variant="primary"
                      onClick={() => onOpenProject(project.id)}
                    >
                      Open Project
                    </YooniButton>
                    <YooniButton 
                      variant="secondary"
                      onClick={() => onCheckScore(project.id)}
                    >
                      Check Score
                    </YooniButton>
                    <button
                      onClick={() => handleRemoveRubric(project.id)}
                      className="p-2.5 text-[#1C1C1C]/30 hover:text-[#1C1C1C]/60 hover:bg-white rounded-lg"
                      title="Remove rubric"
                    >
                      <X className="w-4 h-4" strokeWidth={1.5} />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#1C1C1C]/5 flex items-center justify-center">
                      <AlertCircle className="w-5 h-5 text-[#1C1C1C]/30" strokeWidth={1.5} />
                    </div>
                    <div>
                      <div className="text-[14px] text-[#1C1C1C]/60 mb-0.5" style={{ fontWeight: 500 }}>
                        No rubric uploaded
                      </div>
                      <div className="text-[13px] text-[#1C1C1C]/40">
                        Upload a rubric to enable AI scoring and analysis
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <YooniButton 
                      variant="secondary"
                      onClick={() => onOpenProject(project.id)}
                    >
                      Open Project
                    </YooniButton>
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={(e) => handleRubricUpload(project.id, e)}
                      className="hidden"
                      id={`rubric-upload-${project.id}`}
                    />
                    <label htmlFor={`rubric-upload-${project.id}`}>
                      <YooniButton 
                        variant="primary"
                        as="span"
                      >
                        <Upload className="w-4 h-4 mr-2" strokeWidth={1.5} />
                        Upload Rubric (PDF)
                      </YooniButton>
                    </label>
                  </div>
                </div>
              )}
            </div>
          </YooniCard>
        ))}
      </div>

      {/* Empty State */}
      {projects.length === 0 && (
        <YooniCard className="text-center py-12">
          <BookOpen className="w-12 h-12 text-[#1C1C1C]/20 mx-auto mb-4" strokeWidth={1.5} />
          <h3 className="text-[#1C1C1C] mb-2">No writing projects yet</h3>
          <p className="text-[#1C1C1C]/60 mb-6">
            Create your first project to get started with AI-powered rubric scoring
          </p>
          <YooniButton 
            variant="primary"
            onClick={() => setShowNewProjectForm(true)}
          >
            <Plus className="w-4 h-4 mr-2" strokeWidth={1.5} />
            Create First Project
          </YooniButton>
        </YooniCard>
      )}
    </div>
  );
}