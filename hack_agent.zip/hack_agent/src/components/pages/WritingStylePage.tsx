import React, { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { YooniButton } from '../YooniButton';
import { YooniTextarea } from '../YooniTextarea';
import { CheckCircle2, AlertCircle } from 'lucide-react';

export function WritingStylePage() {
  const [sampleText, setSampleText] = useState('');
  const [styleTrained, setStyleTrained] = useState(false);
  const [isTraining, setIsTraining] = useState(false);

  const handleTrainStyle = () => {
    if (sampleText.trim().length < 100) return;
    
    setIsTraining(true);
    setTimeout(() => {
      setIsTraining(false);
      setStyleTrained(true);
    }, 1500);
  };

  const exampleText = `When I think about the implications of determinism, I find myself drawn to the subtle ways our choices feel meaningful even within a causal framework. It's not that I reject the scientific view—quite the opposite. I think there's something profound in recognizing that our deliberations, our reasons, and our values are all part of the causal story. They don't stand outside it, but they shape how it unfolds through us.`;

  return (
    <div>
      <PageHeader title="Writing Style Training" />

      <div className="max-w-3xl">
        {/* Status indicator */}
        {styleTrained && (
          <div className="mb-8 p-4 bg-[#AEC8A6]/10 rounded-lg border border-[#AEC8A6]/30">
            <div className="flex items-center gap-2 text-[#8BAA82] mb-2">
              <CheckCircle2 className="w-5 h-5" strokeWidth={1.5} />
              <span>Writing style trained</span>
            </div>
            <p className="text-sm text-[#1C1C1C]/70">
              Your writing style has been analyzed. When you use "Improve my score" on assignments, 
              the rewrite will match your tone, vocabulary, and pacing.
            </p>
          </div>
        )}

        {/* Explanation */}
        <YooniCard className="mb-8">
          <h3 className="text-[#1C1C1C] mb-4">How It Works</h3>
          <p className="text-[#1C1C1C]/70 mb-4 leading-relaxed">
            To ensure rewrites sound authentic and personal, paste a sample of your writing below. 
            The agent will analyze your tone, word choice, sentence structure, and pacing. When it 
            rewrites your assignments to improve rubric scores, it will preserve your unique voice.
          </p>
          <p className="text-[#1C1C1C]/70 leading-relaxed">
            For best results, paste 2-3 paragraphs from a previous essay or writing sample that 
            represents your natural academic writing style.
          </p>
        </YooniCard>

        {/* Example */}
        <YooniCard className="mb-8">
          <div className="mb-4 flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-[#AEC8A6] mt-0.5" strokeWidth={1.5} />
            <div>
              <h3 className="text-[#1C1C1C] mb-2">Example Writing Sample</h3>
              <p className="text-sm text-[#1C1C1C]/60 mb-4">
                Here's what a good training sample looks like
              </p>
            </div>
          </div>
          <div className="p-4 bg-[#F5F5F2] rounded-lg">
            <p className="text-[#1C1C1C]/70 leading-relaxed italic">
              {exampleText}
            </p>
          </div>
        </YooniCard>

        {/* Training input */}
        <YooniCard className="mb-8">
          <h3 className="text-[#1C1C1C] mb-4">Your Writing Sample</h3>
          <YooniTextarea
            rows={12}
            value={sampleText}
            onChange={(e) => setSampleText(e.target.value)}
            placeholder="Paste 2-3 paragraphs of your writing here..."
          />
          
          {sampleText.trim().length > 0 && sampleText.trim().length < 100 && (
            <p className="text-sm text-[#1C1C1C]/60 mt-3">
              Please provide at least 100 characters for accurate style analysis
            </p>
          )}
        </YooniCard>

        {/* Train button */}
        <div className="mb-8">
          <YooniButton 
            variant="primary" 
            onClick={handleTrainStyle}
            className={sampleText.trim().length < 100 ? 'opacity-50 cursor-not-allowed' : ''}
          >
            {isTraining ? 'Analyzing your style...' : 'Train Writing Style'}
          </YooniButton>
          
          {isTraining && (
            <div className="mt-4">
              <div className="w-full h-1 bg-[#D7D7D2] rounded-full overflow-hidden">
                <div className="h-full bg-[#AEC8A6] rounded-full animate-pulse" style={{ width: '60%' }} />
              </div>
              <p className="text-sm text-[#1C1C1C]/60 mt-2">
                Analyzing tone, vocabulary, and sentence patterns...
              </p>
            </div>
          )}
        </div>

        {/* Analysis results */}
        {styleTrained && (
          <YooniCard>
            <h3 className="text-[#1C1C1C] mb-4">Style Analysis</h3>
            
            <div className="space-y-4">
              <div>
                <div className="text-sm text-[#1C1C1C]/60 mb-2">Tone</div>
                <div className="text-[#1C1C1C]/70">
                  Reflective and analytical, with a conversational academic voice
                </div>
              </div>

              <div>
                <div className="text-sm text-[#1C1C1C]/60 mb-2">Vocabulary Level</div>
                <div className="text-[#1C1C1C]/70">
                  Sophisticated but accessible, prefers clarity over jargon
                </div>
              </div>

              <div>
                <div className="text-sm text-[#1C1C1C]/60 mb-2">Sentence Structure</div>
                <div className="text-[#1C1C1C]/70">
                  Varied length with complex constructions balanced by clear phrasing
                </div>
              </div>

              <div>
                <div className="text-sm text-[#1C1C1C]/60 mb-2">Common Patterns</div>
                <div className="text-[#1C1C1C]/70">
                  Uses first-person reflection, rhetorical questions, and nuanced qualifiers
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-[#D7D7D2]">
              <p className="text-sm text-[#1C1C1C]/60">
                This profile will be used when rewriting your assignments to ensure they sound 
                authentic and match your natural writing style.
              </p>
            </div>
          </YooniCard>
        )}
      </div>
    </div>
  );
}