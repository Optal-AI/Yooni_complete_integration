import React from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { PriorityDot } from '../PriorityDot';
import { StatusTag } from '../StatusTag';
import { Clock, FileText, FlaskConical, Target, TrendingUp } from 'lucide-react';

interface TodayPageProps {
  onNavigate: (tab: string) => void;
  onOpenProject?: (projectId: string) => void;
}

export function TodayPage({ onNavigate, onOpenProject }: TodayPageProps) {
  return (
    <div>
      <PageHeader title="Dashboard" subtitle="Your research and writing workspace." />

      {/* Stats Overview */}
      <div className="grid grid-cols-12 gap-5 mb-8">
        <div className="col-span-12 md:col-span-3">
          <YooniCard>
            <div className="w-10 h-10 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center mb-4">
              <FlaskConical className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
            </div>
            <div className="text-[32px] text-[#1C1C1C] mb-1 tabular-nums" style={{ fontWeight: 600, letterSpacing: '-0.02em' }}>
              12
            </div>
            <div className="text-[13px] text-[#1C1C1C]/50">Research Papers</div>
          </YooniCard>
        </div>

        <div className="col-span-12 md:col-span-3">
          <YooniCard>
            <div className="w-10 h-10 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center mb-4">
              <FileText className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
            </div>
            <div className="text-[32px] text-[#1C1C1C] mb-1 tabular-nums" style={{ fontWeight: 600, letterSpacing: '-0.02em' }}>
              3
            </div>
            <div className="text-[13px] text-[#1C1C1C]/50">Writing Projects</div>
          </YooniCard>
        </div>

        <div className="col-span-12 md:col-span-3">
          <YooniCard>
            <div className="w-10 h-10 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center mb-4">
              <Target className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
            </div>
            <div className="text-[32px] text-[#1C1C1C] mb-1 tabular-nums" style={{ fontWeight: 600, letterSpacing: '-0.02em' }}>
              847
            </div>
            <div className="text-[13px] text-[#1C1C1C]/50">Words Today</div>
          </YooniCard>
        </div>

        <div className="col-span-12 md:col-span-3">
          <YooniCard>
            <div className="w-10 h-10 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center mb-4">
              <TrendingUp className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
            </div>
            <div className="text-[32px] text-[#1C1C1C] mb-1 tabular-nums" style={{ fontWeight: 600, letterSpacing: '-0.02em' }}>
              24
            </div>
            <div className="text-[13px] text-[#1C1C1C]/50">Citations Added</div>
          </YooniCard>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Active Research Focus */}
        <div className="col-span-12 lg:col-span-8">
          <YooniCard topAccent hover>
            <div className="mb-6">
              <h3 className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/50 mb-3" style={{ fontWeight: 600 }}>
                Active Research Focus
              </h3>
              <h4 className="text-[18px] text-[#1C1C1C] mb-2 leading-snug" style={{ fontWeight: 500 }}>
                Neural Networks for Sentiment Analysis
              </h4>
              <p className="text-[15px] text-[#1C1C1C]/70 leading-relaxed mb-4">
                Analyzing recent papers on transformer architectures and attention mechanisms for NLP tasks. 
                Current focus: comparing BERT, GPT, and newer models for sentiment classification.
              </p>
              <div className="flex items-center gap-2.5 mb-4">
                <div className="h-1.5 flex-1 bg-[#D7D7D2]/30 rounded-full overflow-hidden">
                  <div className="h-full bg-[#AEC8A6] rounded-full transition-all" style={{ width: '68%' }}></div>
                </div>
                <span className="text-[13px] text-[#1C1C1C]/50 tabular-nums" style={{ fontWeight: 500 }}>68%</span>
              </div>
            </div>
            
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <FlaskConical className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
                <span className="text-[13px] text-[#1C1C1C]/60">8 papers analyzed</span>
              </div>
              <div className="flex items-center gap-2">
                <PriorityDot level="high" />
                <StatusTag label="High Priority" variant="priority" />
              </div>
              <StatusTag label="Literature Review" variant="course" />
            </div>
          </YooniCard>
        </div>

        {/* Writing Goal */}
        <div className="col-span-12 lg:col-span-4">
          <YooniCard hover>
            <div className="mb-6">
              <h3 className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/50 mb-3" style={{ fontWeight: 600 }}>
                Today's Writing Goal
              </h3>
              <div className="text-[32px] text-[#1C1C1C] mb-1 tabular-nums leading-tight" style={{ fontWeight: 600, letterSpacing: '-0.02em' }}>
                1,200
              </div>
              <p className="text-[14px] text-[#1C1C1C]/50 mb-4">
                words remaining
              </p>
              <div className="h-1.5 bg-[#D7D7D2]/30 rounded-full overflow-hidden mb-3">
                <div className="h-full bg-[#AEC8A6] rounded-full transition-all" style={{ width: '41%' }}></div>
              </div>
            </div>
            
            <div className="text-[13px] text-[#1C1C1C]/60">
              <span style={{ fontWeight: 500 }} className="text-[#1C1C1C] tabular-nums">847</span> of <span className="tabular-nums">2,000</span> words
            </div>
          </YooniCard>
        </div>

        {/* Recent Papers */}
        <div className="col-span-12 lg:col-span-7">
          <YooniCard>
            <div className="mb-6">
              <h3 className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/50 mb-1" style={{ fontWeight: 600 }}>
                Recently Analyzed Papers
              </h3>
              <p className="text-[13px] text-[#1C1C1C]/40">Papers reviewed this week</p>
            </div>
            
            <div className="space-y-0">
              {/* Paper 1 */}
              <div className="py-4 border-b border-[#D7D7D2]/70 last:border-b-0 hover:bg-[#F5F5F2]/60 -mx-6 px-6 transition-colors cursor-pointer">
                <div className="flex items-start gap-3 mb-2">
                  <PriorityDot level="high" />
                  <div className="flex-1">
                    <h4 className="text-[15px] text-[#1C1C1C] mb-1 leading-snug" style={{ fontWeight: 500 }}>
                      Attention Is All You Need
                    </h4>
                    <p className="text-[13px] text-[#1C1C1C]/50 mb-2">
                      Vaswani et al. • 2017 • NeurIPS
                    </p>
                    <div className="flex items-center gap-2">
                      <StatusTag label="Transformers" variant="course" size="sm" />
                      <StatusTag label="Key Paper" variant="priority" size="sm" />
                    </div>
                  </div>
                  <div className="text-[12px] text-[#1C1C1C]/40">
                    2d
                  </div>
                </div>
              </div>

              {/* Paper 2 */}
              <div className="py-4 border-b border-[#D7D7D2]/70 last:border-b-0 hover:bg-[#F5F5F2]/60 -mx-6 px-6 transition-colors cursor-pointer">
                <div className="flex items-start gap-3 mb-2">
                  <PriorityDot level="medium" />
                  <div className="flex-1">
                    <h4 className="text-[15px] text-[#1C1C1C] mb-1 leading-snug" style={{ fontWeight: 500 }}>
                      BERT: Pre-training of Deep Bidirectional Transformers
                    </h4>
                    <p className="text-[13px] text-[#1C1C1C]/50 mb-2">
                      Devlin et al. • 2019 • NAACL
                    </p>
                    <div className="flex items-center gap-2">
                      <StatusTag label="Language Models" variant="course" size="sm" />
                    </div>
                  </div>
                  <div className="text-[12px] text-[#1C1C1C]/40">
                    3d
                  </div>
                </div>
              </div>

              {/* Paper 3 */}
              <div className="py-4 border-b border-[#D7D7D2]/70 last:border-b-0 hover:bg-[#F5F5F2]/60 -mx-6 px-6 transition-colors cursor-pointer">
                <div className="flex items-start gap-3 mb-2">
                  <PriorityDot level="low" />
                  <div className="flex-1">
                    <h4 className="text-[15px] text-[#1C1C1C] mb-1 leading-snug" style={{ fontWeight: 500 }}>
                      Sentiment Analysis Using Deep Learning Techniques
                    </h4>
                    <p className="text-[13px] text-[#1C1C1C]/50 mb-2">
                      Zhang et al. • 2021 • ACL
                    </p>
                    <div className="flex items-center gap-2">
                      <StatusTag label="Sentiment Analysis" variant="course" size="sm" />
                    </div>
                  </div>
                  <div className="text-[12px] text-[#1C1C1C]/40">
                    5d
                  </div>
                </div>
              </div>
            </div>
          </YooniCard>
        </div>

        {/* Writing Projects */}
        <div className="col-span-12 lg:col-span-5">
          <YooniCard>
            <div className="mb-6">
              <h3 className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/50 mb-1" style={{ fontWeight: 600 }}>
                Active Writing Projects
              </h3>
              <p className="text-[13px] text-[#1C1C1C]/40">In progress</p>
            </div>
            
            <div className="space-y-3">
              {/* Project 1 */}
              <div className="p-4 bg-[#F5F5F2]/60 rounded-lg border border-[#D7D7D2]/60 hover:bg-white hover:border-[#D7D7D2] hover:shadow-sm transition-all cursor-pointer">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-[18px] h-[18px] text-[#8BAA82]" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] text-[#1C1C1C] mb-1 leading-snug" style={{ fontWeight: 500 }}>
                      Research Proposal
                    </h4>
                    <p className="text-[13px] text-[#1C1C1C]/50">
                      Neural approaches to sentiment analysis
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[12px] text-[#1C1C1C]/50">
                  <span className="tabular-nums" style={{ fontWeight: 500 }}>3,247 words</span>
                  <StatusTag label="Draft" variant="status" size="sm" />
                </div>
              </div>

              {/* Project 2 */}
              <div className="p-4 bg-[#F5F5F2]/60 rounded-lg border border-[#D7D7D2]/60 hover:bg-white hover:border-[#D7D7D2] hover:shadow-sm transition-all cursor-pointer">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-[18px] h-[18px] text-[#8BAA82]" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] text-[#1C1C1C] mb-1 leading-snug" style={{ fontWeight: 500 }}>
                      Literature Review
                    </h4>
                    <p className="text-[13px] text-[#1C1C1C]/50">
                      Transformer architectures survey
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[12px] text-[#1C1C1C]/50">
                  <span className="tabular-nums" style={{ fontWeight: 500 }}>5,892 words</span>
                  <StatusTag label="In Review" variant="due" size="sm" />
                </div>
              </div>

              {/* Project 3 */}
              <div className="p-4 bg-[#F5F5F2]/60 rounded-lg border border-[#D7D7D2]/60 hover:bg-white hover:border-[#D7D7D2] hover:shadow-sm transition-all cursor-pointer">
                <div className="flex items-start gap-3 mb-3">
                  <div className="w-9 h-9 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-[18px] h-[18px] text-[#8BAA82]" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] text-[#1C1C1C] mb-1 leading-snug" style={{ fontWeight: 500 }}>
                      Methodology Section
                    </h4>
                    <p className="text-[13px] text-[#1C1C1C]/50">
                      Experimental design outline
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-[12px] text-[#1C1C1C]/50">
                  <span className="tabular-nums" style={{ fontWeight: 500 }}>1,423 words</span>
                  <StatusTag label="Outline" variant="status" size="sm" />
                </div>
              </div>
            </div>
          </YooniCard>
        </div>
      </div>
    </div>
  );
}