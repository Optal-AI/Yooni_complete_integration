import React, { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { YooniInput } from '../YooniInput';

const assignments = [
  {
    id: 1,
    title: 'Philosophy Essay — Free Will and Determinism',
    course: 'PHIL 181',
    dueDate: 'Nov 18, 2025',
    status: 'In Progress',
    score: 32,
    maxScore: 40,
  },
  {
    id: 2,
    title: 'Problem Set 3',
    course: 'CS 229',
    dueDate: 'Nov 18, 2025',
    status: 'Not Started',
    score: null,
    maxScore: 100,
  },
  {
    id: 3,
    title: 'Research Proposal Draft',
    course: 'PSYCH 254',
    dueDate: 'Nov 20, 2025',
    status: 'In Progress',
    score: null,
    maxScore: 50,
  },
  {
    id: 4,
    title: 'Reading Response',
    course: 'PHIL 181',
    dueDate: 'Nov 22, 2025',
    status: 'Not Started',
    score: null,
    maxScore: 20,
  },
  {
    id: 5,
    title: 'Transformer Implementation',
    course: 'CS 224N',
    dueDate: 'Nov 25, 2025',
    status: 'Not Started',
    score: null,
    maxScore: 100,
  },
  {
    id: 6,
    title: 'Literature Review',
    course: 'CS 224N',
    dueDate: 'Nov 15, 2025',
    status: 'Completed',
    score: 45,
    maxScore: 50,
  },
];

interface AssignmentsListPageProps {
  onSelectAssignment: (id: number) => void;
}

export function AssignmentsListPage({ onSelectAssignment }: AssignmentsListPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'in-progress' | 'not-started' | 'completed'>('all');

  const filteredAssignments = assignments.filter((assignment) => {
    const matchesSearch =
      assignment.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      assignment.course.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter =
      filterStatus === 'all' ||
      (filterStatus === 'in-progress' && assignment.status === 'In Progress') ||
      (filterStatus === 'not-started' && assignment.status === 'Not Started') ||
      (filterStatus === 'completed' && assignment.status === 'Completed');
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'text-[#8BAA82]';
      case 'In Progress':
        return 'text-[#AEC8A6]';
      default:
        return 'text-[#1C1C1C]/60';
    }
  };

  return (
    <div>
      <PageHeader title="Assignments" />

      {/* Search and filters */}
      <div className="mb-8">
        <div className="flex items-center gap-4 mb-4">
          <div className="flex-1 max-w-md">
            <YooniInput
              placeholder="Search assignments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterStatus === 'all'
                ? 'bg-[#AEC8A6]/20 text-[#1C1C1C]'
                : 'text-[#1C1C1C]/60 hover:bg-[#D7D7D2]/30'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilterStatus('in-progress')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterStatus === 'in-progress'
                ? 'bg-[#AEC8A6]/20 text-[#1C1C1C]'
                : 'text-[#1C1C1C]/60 hover:bg-[#D7D7D2]/30'
            }`}
          >
            In Progress
          </button>
          <button
            onClick={() => setFilterStatus('not-started')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterStatus === 'not-started'
                ? 'bg-[#AEC8A6]/20 text-[#1C1C1C]'
                : 'text-[#1C1C1C]/60 hover:bg-[#D7D7D2]/30'
            }`}
          >
            Not Started
          </button>
          <button
            onClick={() => setFilterStatus('completed')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filterStatus === 'completed'
                ? 'bg-[#AEC8A6]/20 text-[#1C1C1C]'
                : 'text-[#1C1C1C]/60 hover:bg-[#D7D7D2]/30'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      {/* Assignments list */}
      {filteredAssignments.length > 0 ? (
        <div className="space-y-4">
          {filteredAssignments.map((assignment) => (
            <YooniCard
              key={assignment.id}
              className="cursor-pointer hover:shadow-[0_2px_8px_rgba(0,0,0,0.06)] transition-shadow"
              onClick={() => onSelectAssignment(assignment.id)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-[#1C1C1C]">{assignment.title}</h3>
                    <span className={`text-sm ${getStatusColor(assignment.status)}`}>
                      {assignment.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4">
                    <p className="text-sm text-[#1C1C1C]/60">{assignment.course}</p>
                    <span className="text-sm text-[#1C1C1C]/60">Due: {assignment.dueDate}</span>
                  </div>
                </div>
                {assignment.score !== null && (
                  <div className="text-right">
                    <div className="text-sm text-[#1C1C1C]/60 mb-1">Score</div>
                    <div className="text-[#1C1C1C]">
                      {assignment.score} / {assignment.maxScore}
                    </div>
                  </div>
                )}
              </div>
            </YooniCard>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-[#1C1C1C]/60">No assignments found matching your search.</p>
        </div>
      )}
    </div>
  );
}
