import React, { useState, useEffect } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { YooniButton } from '../YooniButton';
import { YooniInput } from '../YooniInput';
import { YooniTextarea } from '../YooniTextarea';
import { StatusTag } from '../StatusTag';
import { Upload, FileText, X, Copy, CheckCircle2, Download, Sparkles, Star, Search } from 'lucide-react';
import { copyToClipboard } from '../../utils/clipboard';
import { uploadPaper, getPapers, deletePaper, generateCitations } from '../../services/researchService';
import { ResearchPaper } from '../../types';
import { API_CONFIG } from '../../config/api';

interface UploadedPaper extends ResearchPaper {
  status: 'analyzing' | 'ready';
  tags?: string[];
}

interface CitationFormat {
  format: string;
  text: string;
}

export function ResearchMatchPage() {
  const [researchTopic, setResearchTopic] = useState('Attention mechanisms in natural language processing models');
  const [selectedPaper, setSelectedPaper] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [copiedCitation, setCopiedCitation] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [uploadedPapers, setUploadedPapers] = useState<UploadedPaper[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [visualizationData, setVisualizationData] = useState<any>(null);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [showFavorites, setShowFavorites] = useState(false);

  // Load papers on mount
  useEffect(() => {
    loadPapers();
    loadFavorites();
  }, []);

  // Load favorites from localStorage
  const loadFavorites = () => {
    try {
      const saved = localStorage.getItem('favoritePapers');
      if (saved) {
        setFavorites(JSON.parse(saved));
      }
    } catch (err) {
      console.error('Error loading favorites:', err);
    }
  };

  // Save favorites to localStorage
  const saveFavorites = (favs: any[]) => {
    try {
      localStorage.setItem('favoritePapers', JSON.stringify(favs));
    } catch (err) {
      console.error('Error saving favorites:', err);
    }
  };

  const currentPaper = uploadedPapers.find(paper => paper && paper.id === selectedPaper) || null;

  const loadPapers = async () => {
    const result = await getPapers();
    if (result.success && result.data) {
      const papersWithStatus: UploadedPaper[] = result.data.map(paper => ({
        ...paper,
        status: 'ready' as const,
        tags: paper.keyFindings?.slice(0, 3) || [],
      }));
      setUploadedPapers(papersWithStatus);
      if (papersWithStatus.length > 0 && !selectedPaper) {
        setSelectedPaper(papersWithStatus[0].id);
      }
    }
  };

  const handleFileUpload = async (file: File) => {
    if (file && (file.type === 'application/pdf' || file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')) {
      setIsProcessing(true);
      setError(null);
      
      const tempId = Date.now().toString();
      const newPaper: UploadedPaper = {
        id: tempId,
        fileName: file.name,
        uploadDate: new Date().toISOString().split('T')[0],
        title: file.name,
        authors: '',
        year: new Date().getFullYear().toString(),
        relevanceScore: 0,
        recommendation: 'maybe',
        abstract: '',
        keyFindings: [],
        status: 'analyzing',
        tags: [],
      };

      setUploadedPapers(prev => [...prev, newPaper]);
      setSelectedPaper(tempId);

      try {
        const formData = new FormData();
        formData.append('pdf', file);
        formData.append('research_theme', researchTopic);
        formData.append('option', 'theme');
        formData.append('max_papers', '5');

        const result = await uploadPaper(file, researchTopic);
        setIsProcessing(false);

        if (result.success && result.data) {
          const processedPaper: UploadedPaper = {
            ...result.data,
            status: 'ready' as const,
            tags: result.data.keyFindings?.slice(0, 3) || [],
          };
          
          setUploadedPapers(prev => prev.map(p => 
            p.id === tempId ? processedPaper : p
          ));
          setSelectedPaper(processedPaper.id);
        } else {
          throw new Error(result.error || 'Failed to process paper');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to upload paper');
        setIsProcessing(false);
        setUploadedPapers(prev => prev.filter(p => p.id !== tempId));
      }
    } else {
      setError('Please upload a PDF or DOCX file');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (event: React.DragEvent) => {
    event.preventDefault();
    setIsDragging(false);
    
    const file = event.dataTransfer.files[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleDeletePaper = async (paperId: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      await deletePaper(paperId);
      setUploadedPapers(prev => prev.filter(p => p.id !== paperId));
      if (selectedPaper === paperId) {
        const remaining = uploadedPapers.filter(p => p.id !== paperId);
        setSelectedPaper(remaining.length > 0 ? remaining[0].id : null);
      }
    } catch (err) {
      console.error('Error deleting paper:', err);
    }
  };

  const filteredPapers = uploadedPapers.filter(paper =>
    paper.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    paper.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCitations = (paper: UploadedPaper): CitationFormat[] => {
    try {
      if (!paper) return [];
      return generateCitations(paper);
    } catch (err) {
      console.error('Error generating citations:', err);
      return [
        { format: 'APA', text: `${paper.authors || 'Author'} (${paper.year || 'Year'}). ${paper.title || 'Title'}.` },
        { format: 'MLA', text: `${paper.authors || 'Author'}. "${paper.title || 'Title'}." ${paper.year || 'Year'}.` },
        { format: 'Chicago', text: `${paper.authors || 'Author'}. "${paper.title || 'Title'}" (${paper.year || 'Year'}).` }
      ];
    }
  };

  const handleCopyCitation = (citation: string) => {
    try {
      copyToClipboard(citation);
      setCopiedCitation(citation);
      setTimeout(() => setCopiedCitation(null), 2000);
    } catch (err) {
      console.error('Error copying citation:', err);
    }
  };

  // Toggle favorite for a paper
  const toggleFavorite = (paper: any) => {
    try {
      const paperId = paper.id || paper.paper_info?.arxiv_id || paper.paper_info?.url || paper.title;
      const existingIndex = favorites.findIndex(f => 
        (f.id || f.paper_info?.arxiv_id || f.paper_info?.url || f.title) === paperId
      );

      let updatedFavorites;
      if (existingIndex >= 0) {
        updatedFavorites = favorites.filter((_, idx) => idx !== existingIndex);
      } else {
        updatedFavorites = [
          {
            ...paper,
            favoritedAt: new Date().toISOString()
          },
          ...favorites
        ];
      }

      setFavorites(updatedFavorites);
      saveFavorites(updatedFavorites);
    } catch (err) {
      console.error('Error toggling favorite:', err);
    }
  };

  // Check if paper is favorited
  const isFavorited = (paper: any): boolean => {
    const paperId = paper.id || paper.paper_info?.arxiv_id || paper.paper_info?.url || paper.title;
    return favorites.some(f => 
      (f.id || f.paper_info?.arxiv_id || f.paper_info?.url || f.title) === paperId
    );
  };

  return (
    <div>
      <PageHeader 
        title="Research Match" 
        subtitle="Upload papers and evaluate their relevance to your research topic."
      />

      {/* Upload & Evaluate Section */}
      <YooniCard className="mb-6" topAccent>
        <div className="mb-4">
          <h2 className="text-[20px] text-[#1C1C1C] mb-2" style={{ fontWeight: 600 }}>
            Upload & Evaluate Paper
          </h2>
          <p className="text-[13px] text-[#1C1C1C]/60 leading-relaxed">
            Upload a research paper and enter your research topic to get AI-powered relevance scoring and analysis
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upload Section */}
          <div>
            <h3 className="text-[16px] text-[#1C1C1C] mb-3" style={{ fontWeight: 500 }}>
              Upload Paper
            </h3>
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`relative border border-dashed rounded-lg transition-all duration-200 p-6 ${
                isDragging 
                  ? 'border-[#AEC8A6] bg-[#AEC8A6]/5' 
                  : 'border-[#D7D7D2] hover:border-[#AEC8A6]/50 hover:bg-[#F5F5F2]/30'
              }`}
            >
              <input
                type="file"
                id="file-upload"
                accept=".pdf,.doc,.docx"
                onChange={handleInputChange}
                className="hidden"
                disabled={isProcessing}
              />
              <label
                htmlFor="file-upload"
                className={`flex flex-col items-center justify-center cursor-pointer ${isProcessing ? 'opacity-50' : ''}`}
              >
                <div className="w-12 h-12 rounded-full bg-[#AEC8A6]/15 flex items-center justify-center mb-3">
                  <Upload className="w-6 h-6 text-[#8BAA82]" strokeWidth={1.5} />
                </div>
                <p className="text-[14px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                  {isProcessing ? 'Processing...' : 'Drop PDF here or click to upload'}
                </p>
                <p className="text-[12px] text-[#1C1C1C]/50">
                  Supports PDF, DOC, DOCX
                </p>
              </label>
            </div>
          </div>

          {/* Research Topic Section */}
          <div>
            <h3 className="text-[16px] text-[#1C1C1C] mb-3" style={{ fontWeight: 500 }}>
              Your Research Topic
            </h3>
            <p className="text-[12px] text-[#1C1C1C]/50 mb-3 leading-relaxed">
              Enter your research topic to evaluate the uploaded paper's relevance
            </p>
            <YooniTextarea
              rows={4}
              value={researchTopic}
              onChange={(e) => setResearchTopic(e.target.value)}
              placeholder="Enter your research topic or thesis statement..."
              className="resize-none"
            />
            <p className="text-[11px] text-[#1C1C1C]/40 mt-2">
              💡 Upload a paper first, then enter your research topic to see the relevance score
            </p>
          </div>
        </div>
      </YooniCard>

      {/* Favorites Bar */}
      <YooniCard className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} fill={favorites.length > 0 ? '#8BAA82' : 'none'} />
            <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
              Favorites ({favorites.length})
            </h3>
          </div>
          <YooniButton
            onClick={() => setShowFavorites(!showFavorites)}
            variant="secondary"
            className="text-[13px]"
          >
            {showFavorites ? 'Hide' : 'Show'} Favorites
          </YooniButton>
        </div>
        {showFavorites && favorites.length > 0 && (
          <div className="mt-4 space-y-2 max-h-64 overflow-y-auto">
            {favorites.map((fav, idx) => {
              const paperInfo = fav.paper_info || fav;
              return (
                <div
                  key={idx}
                  className="p-3 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]/50 hover:border-[#AEC8A6]/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-[14px] text-[#1C1C1C] mb-1 line-clamp-2" style={{ fontWeight: 500 }}>
                        {paperInfo.title || fav.title || 'Untitled'}
                      </h4>
                      <p className="text-[12px] text-[#1C1C1C]/60">
                        {Array.isArray(paperInfo.authors) ? paperInfo.authors.join(', ') : paperInfo.authors || fav.authors || 'Unknown'}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleFavorite(fav)}
                      className="p-1.5 hover:bg-[#D7D7D2]/40 rounded transition-colors flex-shrink-0"
                    >
                      <Star className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} fill="#8BAA82" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        {showFavorites && favorites.length === 0 && (
          <div className="mt-4 text-center py-8 text-[#1C1C1C]/50 text-[13px]">
            No favorite papers yet. Star papers to add them here.
          </div>
        )}
      </YooniCard>

      {error && (
        <YooniCard className="mb-6 border-red-200 bg-red-50">
          <div className="text-red-600 text-[14px]">
            {error}
          </div>
        </YooniCard>
      )}

      <div className="grid grid-cols-12 gap-6">
        {/* Left sidebar - Paper Library */}
        <div className="col-span-12 lg:col-span-4">
          <YooniCard>
            <div className="mb-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-[18px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Paper Library
                </h3>
                <div className="px-2.5 py-1 bg-[#F5F5F2] rounded-md">
                  <span className="text-[12px] text-[#1C1C1C]/60" style={{ fontWeight: 500 }}>
                    {uploadedPapers.length}
                  </span>
                </div>
              </div>
              
              {uploadedPapers.length > 0 && (
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
                  <YooniInput
                    placeholder="Search papers..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 py-2 text-[14px]"
                  />
                </div>
              )}
            </div>

            <div className="space-y-1.5 max-h-[520px] overflow-y-auto pr-1">
              {filteredPapers.map((paper) => (
                <div
                  key={paper.id}
                  onClick={() => setSelectedPaper(paper.id)}
                  className={`p-3.5 rounded-lg cursor-pointer transition-all duration-200 group border relative ${
                    selectedPaper === paper.id
                      ? 'bg-[#AEC8A6]/8 border-[#AEC8A6]/25 shadow-sm'
                      : 'border-transparent hover:bg-[#F5F5F2] hover:border-[#D7D7D2]/50'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-2.5">
                    <div className="flex items-start gap-2.5 flex-1 min-w-0">
                      <FileText 
                        className={`w-[18px] h-[18px] mt-0.5 flex-shrink-0 ${
                          selectedPaper === paper.id ? 'text-[#8BAA82]' : 'text-[#1C1C1C]/40'
                        }`} 
                        strokeWidth={1.5} 
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-[14px] text-[#1C1C1C] mb-1 line-clamp-2 leading-snug" style={{ fontWeight: 500 }}>
                          {paper.title}
                        </div>
                        <div className="text-[12px] text-[#1C1C1C]/50">
                          {new Date(paper.uploadDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={(e) => handleDeletePaper(paper.id, e)}
                      className="opacity-0 group-hover:opacity-100 p-1 hover:bg-[#D7D7D2]/40 rounded transition-all"
                    >
                      <X className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                    </button>
                  </div>
                </div>
              ))}
              
              {filteredPapers.length === 0 && searchQuery && (
                <div className="text-center py-8 text-[#1C1C1C]/50 text-[13px]">
                  No papers match your search
                </div>
              )}
              
              {uploadedPapers.length === 0 && (
                <div className="text-center py-10 text-[#1C1C1C]/40 text-[13px]">
                  Upload your first paper to get started
                </div>
              )}
            </div>
          </YooniCard>
        </div>

        {/* Right side - Analysis */}
        <div className="col-span-12 lg:col-span-8">
          {currentPaper && currentPaper.status === 'analyzing' && (
            <YooniCard className="mb-6">
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-[#AEC8A6]/10 flex items-center justify-center mx-auto mb-5">
                  <Sparkles className="w-8 h-8 text-[#8BAA82]" strokeWidth={1.5} />
                </div>
                <p className="text-[17px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                  Analyzing paper
                </p>
                <p className="text-[14px] text-[#1C1C1C]/50 mb-6 max-w-md mx-auto leading-relaxed">
                  Extracting key findings, relevance scoring, and citations
                </p>
                <div className="max-w-xs mx-auto">
                  <div className="w-full h-1 bg-[#D7D7D2]/40 rounded-full overflow-hidden">
                    <div className="h-full bg-[#AEC8A6] rounded-full transition-all" style={{ width: '60%' }} />
                  </div>
                </div>
              </div>
            </YooniCard>
          )}

          {currentPaper && currentPaper.status === 'ready' && (
            <>
              {/* Paper Summary */}
              <YooniCard className="mb-6" topAccent>
                <div className="mb-6">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <h3 className="text-[18px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                      {currentPaper.title || 'Untitled Paper'}
                    </h3>
                    <div className="flex items-center gap-2">
                      <StatusTag label="Analyzed" variant="priority" />
                      <button
                        onClick={() => toggleFavorite(currentPaper)}
                        className={`p-2 rounded-lg transition-colors ${
                          isFavorited(currentPaper) ? 'bg-[#AEC8A6]/20' : 'hover:bg-[#D7D7D2]/40'
                        }`}
                        title={isFavorited(currentPaper) ? 'Remove from favorites' : 'Add to favorites'}
                      >
                        <Star
                          className={`w-5 h-5 ${isFavorited(currentPaper) ? 'text-[#8BAA82]' : 'text-[#1C1C1C]/40'}`}
                          strokeWidth={1.5}
                          fill={isFavorited(currentPaper) ? '#8BAA82' : 'none'}
                        />
                      </button>
                    </div>
                  </div>
                  <div className="text-[14px] text-[#1C1C1C]/60 mb-4">
                    {currentPaper.authors || 'Unknown'} • {currentPaper.year || 'N/A'}
                  </div>
                  {currentPaper.tags && Array.isArray(currentPaper.tags) && currentPaper.tags.length > 0 && (
                    <div className="flex items-center gap-2 flex-wrap mb-4">
                      {currentPaper.tags.map((tag, idx) => (
                        <StatusTag key={idx} label={tag || 'Tag'} variant="course" size="sm" />
                      ))}
                    </div>
                  )}
                </div>

                {currentPaper.abstract && (
                  <div className="prose max-w-none">
                    <p className="text-[15px] text-[#1C1C1C]/70 leading-relaxed mb-6">
                      {currentPaper.abstract}
                    </p>
                  </div>
                )}

                {currentPaper.keyFindings && Array.isArray(currentPaper.keyFindings) && currentPaper.keyFindings.length > 0 && (
                  <div className="pt-6 border-t border-[#D7D7D2]">
                    <div className="mb-4">
                      <div className="text-[13px] uppercase tracking-wide text-[#1C1C1C]/60 mb-3" style={{ fontWeight: 600 }}>
                        Key Contributions
                      </div>
                      <ul className="space-y-2.5 text-[14px] text-[#1C1C1C]/70">
                        {currentPaper.keyFindings.map((finding, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#AEC8A6] mt-2 flex-shrink-0" />
                            <span>{finding || 'Finding'}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </YooniCard>

              {/* Relevance Analysis */}
              <YooniCard className="mb-6">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-[#AEC8A6]/15 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                      Relevance to Your Research
                    </h3>
                    <div className="flex items-center gap-2 mb-4">
                      {[1, 2, 3, 4, 5].map((dot) => {
                        const relevanceScore = typeof currentPaper.relevanceScore === 'number' ? currentPaper.relevanceScore : 0;
                        const score = Math.round(relevanceScore * 5);
                        return (
                          <div
                            key={dot}
                            className={`w-2.5 h-2.5 rounded-full transition-colors ${
                              dot <= score ? 'bg-[#AEC8A6]' : 'bg-[#D7D7D2]'
                            }`}
                          />
                        );
                      })}
                      <span className="ml-2 text-[13px] text-[#1C1C1C]/60">
                        {(() => {
                          const score = typeof currentPaper.relevanceScore === 'number' ? currentPaper.relevanceScore : 0;
                          if (score >= 0.8) return 'Highly Relevant';
                          if (score >= 0.6) return 'Relevant';
                          if (score >= 0.4) return 'Somewhat Relevant';
                          return 'Low Relevance';
                        })()}
                      </span>
                      <span className="ml-2 text-[13px] text-[#1C1C1C]/50">
                        ({Math.round((typeof currentPaper.relevanceScore === 'number' ? currentPaper.relevanceScore : 0) * 100)}%)
                      </span>
                    </div>
                  </div>
                </div>

                {currentPaper.strengths && typeof currentPaper.strengths === 'string' && (
                  <div className="mb-4">
                    <div className="text-[13px] uppercase tracking-wide text-[#1C1C1C]/60 mb-2" style={{ fontWeight: 600 }}>
                      Strengths
                    </div>
                    <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed">
                      {currentPaper.strengths}
                    </p>
                  </div>
                )}

                {currentPaper.limitations && typeof currentPaper.limitations === 'string' && (
                  <div className="mb-6">
                    <div className="text-[13px] uppercase tracking-wide text-[#1C1C1C]/60 mb-2" style={{ fontWeight: 600 }}>
                      Limitations
                    </div>
                    <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed">
                      {currentPaper.limitations}
                    </p>
                  </div>
                )}

                <div className="flex items-center justify-between pt-5 border-t border-[#D7D7D2]">
                  <div className="text-[14px] text-[#1C1C1C]/70">
                    Include in literature review?
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      defaultChecked={currentPaper.recommendation === 'include'} 
                    />
                    <div className="w-11 h-6 bg-[#D7D7D2] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#AEC8A6]/30 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#AEC8A6] transition-colors"></div>
                  </label>
                </div>
              </YooniCard>

              {/* Citations */}
              <YooniCard className="mb-6">
                <div className="mb-6">
                  <h3 className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                    Citation Formats
                  </h3>
                  <p className="text-[13px] text-[#1C1C1C]/60">
                    Copy in your preferred citation style
                  </p>
                </div>

                <div className="space-y-3">
                  {(() => {
                    try {
                      const citations = getCitations(currentPaper);
                      if (!citations || citations.length === 0) {
                        return (
                          <div className="text-[13px] text-[#1C1C1C]/50 p-4">
                            Citation data not available
                          </div>
                        );
                      }
                      return citations.map((citation) => (
                        <div key={citation.format} className="p-4 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]/50 hover:border-[#D7D7D2] transition-colors">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/50 mb-2" style={{ fontWeight: 600 }}>
                                {citation.format || 'Citation'}
                              </div>
                              <div className="text-[13px] text-[#1C1C1C]/80 leading-relaxed break-words">
                                {citation.text || 'Citation text not available'}
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                try {
                                  handleCopyCitation(citation.text || '');
                                } catch (err) {
                                  console.error('Error copying citation:', err);
                                }
                              }}
                              className="flex-shrink-0 p-2 hover:bg-[#D7D7D2]/40 rounded-lg transition-colors"
                            >
                              {copiedCitation === citation.text ? (
                                <CheckCircle2 className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                              ) : (
                                <Copy className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                              )}
                            </button>
                          </div>
                        </div>
                      ));
                    } catch (err) {
                      console.error('Error rendering citations:', err);
                      return (
                        <div className="text-[13px] text-[#1C1C1C]/50 p-4">
                          Error loading citations
                        </div>
                      );
                    }
                  })()}
                </div>
              </YooniCard>
            </>
          )}

          {!currentPaper && uploadedPapers.length > 0 && (
            <YooniCard>
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-full bg-[#D7D7D2]/30 flex items-center justify-center mx-auto mb-4">
                  <FileText className="w-8 h-8 text-[#1C1C1C]/40" strokeWidth={1.5} />
                </div>
                <p className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                  Select a paper to view analysis
                </p>
                <p className="text-[14px] text-[#1C1C1C]/50">
                  Choose from your paper library on the left
                </p>
              </div>
            </YooniCard>
          )}

          {uploadedPapers.length === 0 && (
            <YooniCard>
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-full bg-[#AEC8A6]/15 flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-[#8BAA82]" strokeWidth={1.5} />
                </div>
                <p className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                  Upload your first research paper
                </p>
                <p className="text-[14px] text-[#1C1C1C]/60">
                  Get AI-powered analysis, relevance scoring, and citation formatting
                </p>
              </div>
            </YooniCard>
          )}
        </div>
      </div>
    </div>
  );
}

