import React, { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { StatusTag } from '../StatusTag';
import { Search, Filter, BookOpen, FileText, ExternalLink, Download, Plus, X, Tag, Edit2, BookmarkPlus, CheckCircle2, Clock, BookMarked } from 'lucide-react';
import { YooniInput } from '../YooniInput';
import { YooniButton } from '../YooniButton';

type PaperStatus = 'read' | 'reading' | 'to-read';
type ViewMode = 'all' | 'collection';
type SortBy = 'recent' | 'title' | 'year' | 'citations';

interface Paper {
  id: number;
  title: string;
  authors: string;
  year: number;
  venue: string;
  tags: string[];
  cited: number;
  notes: number;
  status: PaperStatus;
  collection?: string;
  addedDate: string;
  usedInProjects?: string[];
  abstract?: string;
}

export function LibraryPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPaper, setSelectedPaper] = useState<number | null>(null);
  const [activeCollection, setActiveCollection] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<PaperStatus | 'all'>('all');
  const [sortBy, setSortBy] = useState<SortBy>('recent');
  const [showFilters, setShowFilters] = useState(false);

  const papers: Paper[] = [
    {
      id: 1,
      title: 'Attention Is All You Need',
      authors: 'Vaswani, A., Shazeer, N., Parmar, N., et al.',
      year: 2017,
      venue: 'NeurIPS',
      tags: ['Transformers', 'Attention', 'Architecture'],
      cited: 12,
      notes: 3,
      status: 'read',
      collection: 'Transformers & Attention',
      addedDate: '2025-11-10',
      usedInProjects: ['Research Proposal', 'Literature Review'],
      abstract: 'The dominant sequence transduction models are based on complex recurrent or convolutional neural networks. We propose a new simple network architecture based entirely on attention mechanisms.'
    },
    {
      id: 2,
      title: 'BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding',
      authors: 'Devlin, J., Chang, M.W., Lee, K., Toutanova, K.',
      year: 2019,
      venue: 'NAACL',
      tags: ['Language Models', 'Pre-training', 'BERT'],
      cited: 8,
      notes: 5,
      status: 'read',
      collection: 'Language Models',
      addedDate: '2025-11-12',
      usedInProjects: ['Literature Review'],
      abstract: 'We introduce a new language representation model called BERT, which stands for Bidirectional Encoder Representations from Transformers.'
    },
    {
      id: 3,
      title: 'Language Models are Few-Shot Learners',
      authors: 'Brown, T., Mann, B., Ryder, N., et al.',
      year: 2020,
      venue: 'NeurIPS',
      tags: ['GPT-3', 'Few-shot Learning', 'Large Models'],
      cited: 15,
      notes: 7,
      status: 'read',
      collection: 'Language Models',
      addedDate: '2025-11-08',
      usedInProjects: ['Research Proposal', 'Literature Review', 'Methodology Section'],
      abstract: 'Recent work has demonstrated substantial gains on many NLP tasks and benchmarks by pre-training on a large corpus of text followed by fine-tuning on a specific task.'
    },
    {
      id: 4,
      title: 'Sentiment Analysis in Social Networks',
      authors: 'Pak, A., Paroubek, P.',
      year: 2010,
      venue: 'LREC',
      tags: ['Sentiment Analysis', 'Social Media'],
      cited: 3,
      notes: 2,
      status: 'reading',
      collection: 'Sentiment Analysis',
      addedDate: '2025-11-13',
      usedInProjects: ['Research Proposal'],
      abstract: 'We present a method for automatic collection of a corpus that can be used to train a sentiment classifier.'
    },
    {
      id: 5,
      title: 'Deep Learning for Sentiment Analysis: A Survey',
      authors: 'Zhang, L., Wang, S., Liu, B.',
      year: 2018,
      venue: 'WIREs Data Mining',
      tags: ['Survey', 'Deep Learning', 'Sentiment'],
      cited: 0,
      notes: 0,
      status: 'to-read',
      collection: 'Sentiment Analysis',
      addedDate: '2025-11-14',
      abstract: 'This paper surveys the field of sentiment analysis and opinion mining with a focus on deep learning methods.'
    },
    {
      id: 6,
      title: 'Neural Machine Translation by Jointly Learning to Align and Translate',
      authors: 'Bahdanau, D., Cho, K., Bengio, Y.',
      year: 2015,
      venue: 'ICLR',
      tags: ['Attention', 'NMT', 'Seq2Seq'],
      cited: 7,
      notes: 4,
      status: 'read',
      collection: 'Transformers & Attention',
      addedDate: '2025-11-11',
      usedInProjects: ['Literature Review'],
      abstract: 'Neural machine translation is a recently proposed approach to machine translation. We conjecture that the use of a fixed-length vector is a bottleneck.'
    }
  ];

  const collections = [
    { name: 'Transformers & Attention', count: papers.filter(p => p.collection === 'Transformers & Attention').length, color: 'text-[#AEC8A6]' },
    { name: 'Sentiment Analysis', count: papers.filter(p => p.collection === 'Sentiment Analysis').length, color: 'text-[#8BAA82]' },
    { name: 'Language Models', count: papers.filter(p => p.collection === 'Language Models').length, color: 'text-[#AEC8A6]' },
    { name: 'Key Papers', count: 5, color: 'text-[#8BAA82]' }
  ];

  // Filter and sort papers
  let filteredPapers = papers.filter(paper => {
    const matchesSearch = 
      paper.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      paper.authors.toLowerCase().includes(searchQuery.toLowerCase()) ||
      paper.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || paper.status === statusFilter;
    const matchesCollection = !activeCollection || paper.collection === activeCollection;
    
    return matchesSearch && matchesStatus && matchesCollection;
  });

  // Sort papers
  filteredPapers = [...filteredPapers].sort((a, b) => {
    switch (sortBy) {
      case 'recent':
        return new Date(b.addedDate).getTime() - new Date(a.addedDate).getTime();
      case 'title':
        return a.title.localeCompare(b.title);
      case 'year':
        return b.year - a.year;
      case 'citations':
        return b.cited - a.cited;
      default:
        return 0;
    }
  });

  const currentPaper = papers.find(p => p.id === selectedPaper);

  const getStatusIcon = (status: PaperStatus) => {
    switch (status) {
      case 'read':
        return <CheckCircle2 className="w-4 h-4" strokeWidth={1.5} />;
      case 'reading':
        return <BookOpen className="w-4 h-4" strokeWidth={1.5} />;
      case 'to-read':
        return <BookMarked className="w-4 h-4" strokeWidth={1.5} />;
    }
  };

  return (
    <div>
      <PageHeader 
        title="Library" 
        subtitle="Your curated collection of research papers."
      />

      <div className="grid grid-cols-12 gap-6">
        {/* Search and Filters */}
        <div className="col-span-12">
          <YooniCard>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex-1 min-w-[300px] relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
                <YooniInput
                  placeholder="Search papers by title, author, or keywords..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              {/* Sort Dropdown */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortBy)}
                className="px-4 py-2 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-[14px] text-[#1C1C1C] bg-white cursor-pointer"
              >
                <option value="recent">Recently Added</option>
                <option value="title">Title A-Z</option>
                <option value="year">Year (Newest)</option>
                <option value="citations">Most Cited</option>
              </select>

              {/* Status Filter Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setStatusFilter('all')}
                  className={`px-3 py-2 rounded-lg transition-colors text-[13px] flex items-center gap-1.5 ${
                    statusFilter === 'all'
                      ? 'bg-[#AEC8A6]/15 text-[#8BAA82] border border-[#AEC8A6]/30'
                      : 'border border-[#D7D7D2] text-[#1C1C1C]/60 hover:bg-[#F5F5F2]'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setStatusFilter('read')}
                  className={`px-3 py-2 rounded-lg transition-colors text-[13px] flex items-center gap-1.5 ${
                    statusFilter === 'read'
                      ? 'bg-[#AEC8A6]/15 text-[#8BAA82] border border-[#AEC8A6]/30'
                      : 'border border-[#D7D7D2] text-[#1C1C1C]/60 hover:bg-[#F5F5F2]'
                  }`}
                >
                  {getStatusIcon('read')}
                  Read
                </button>
                <button
                  onClick={() => setStatusFilter('reading')}
                  className={`px-3 py-2 rounded-lg transition-colors text-[13px] flex items-center gap-1.5 ${
                    statusFilter === 'reading'
                      ? 'bg-[#AEC8A6]/15 text-[#8BAA82] border border-[#AEC8A6]/30'
                      : 'border border-[#D7D7D2] text-[#1C1C1C]/60 hover:bg-[#F5F5F2]'
                  }`}
                >
                  {getStatusIcon('reading')}
                  Reading
                </button>
                <button
                  onClick={() => setStatusFilter('to-read')}
                  className={`px-3 py-2 rounded-lg transition-colors text-[13px] flex items-center gap-1.5 ${
                    statusFilter === 'to-read'
                      ? 'bg-[#AEC8A6]/15 text-[#8BAA82] border border-[#AEC8A6]/30'
                      : 'border border-[#D7D7D2] text-[#1C1C1C]/60 hover:bg-[#F5F5F2]'
                  }`}
                >
                  {getStatusIcon('to-read')}
                  To Read
                </button>
              </div>
            </div>
          </YooniCard>
        </div>

        {/* Collections Sidebar */}
        <div className="col-span-12 lg:col-span-3">
          <YooniCard>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60" style={{ fontWeight: 600 }}>
                Collections
              </h3>
              <button className="p-1 hover:bg-[#D7D7D2]/30 rounded transition-colors">
                <Plus className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
              </button>
            </div>
            <div className="space-y-1">
              <button
                onClick={() => setActiveCollection(null)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors text-left ${
                  activeCollection === null
                    ? 'bg-[#AEC8A6]/15 text-[#1C1C1C]'
                    : 'hover:bg-[#F5F5F2] text-[#1C1C1C]/70'
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                  <span className="text-[14px]">All Papers</span>
                </div>
                <span className="text-[13px] text-[#1C1C1C]/50">{papers.length}</span>
              </button>
              {collections.map((collection, index) => (
                <button
                  key={index}
                  onClick={() => setActiveCollection(collection.name)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors text-left ${
                    activeCollection === collection.name
                      ? 'bg-[#AEC8A6]/15 text-[#1C1C1C]'
                      : 'hover:bg-[#F5F5F2] text-[#1C1C1C]/70'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <BookOpen className={collection.color} strokeWidth={1.5} />
                    <span className="text-[14px]">{collection.name}</span>
                  </div>
                  <span className="text-[13px] text-[#1C1C1C]/50">{collection.count}</span>
                </button>
              ))}
            </div>
          </YooniCard>

          <YooniCard className="mt-6">
            <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60 mb-4" style={{ fontWeight: 600 }}>
              Quick Stats
            </h3>
            <div className="space-y-3">
              <div>
                <div className="text-[24px] text-[#1C1C1C] mb-1" style={{ fontWeight: 600 }}>
                  {papers.length}
                </div>
                <div className="text-[13px] text-[#1C1C1C]/60">Total Papers</div>
              </div>
              <div>
                <div className="text-[24px] text-[#1C1C1C] mb-1" style={{ fontWeight: 600 }}>
                  {papers.reduce((sum, p) => sum + p.cited, 0)}
                </div>
                <div className="text-[13px] text-[#1C1C1C]/60">Citations Used</div>
              </div>
              <div>
                <div className="text-[24px] text-[#1C1C1C] mb-1" style={{ fontWeight: 600 }}>
                  {papers.reduce((sum, p) => sum + p.notes, 0)}
                </div>
                <div className="text-[13px] text-[#1C1C1C]/60">Notes Created</div>
              </div>
            </div>
          </YooniCard>
        </div>

        {/* Papers List or Detail View */}
        <div className="col-span-12 lg:col-span-9">
          {selectedPaper && currentPaper ? (
            // Paper Detail View
            <div className="space-y-6">
              <YooniCard>
                <div className="flex items-start justify-between mb-6">
                  <button
                    onClick={() => setSelectedPaper(null)}
                    className="flex items-center gap-2 text-[14px] text-[#1C1C1C]/60 hover:text-[#1C1C1C] transition-colors"
                  >
                    <X className="w-4 h-4" strokeWidth={1.5} />
                    Back to Library
                  </button>
                  <div className="flex items-center gap-2">
                    <button className="p-2 rounded-lg hover:bg-[#F5F5F2] transition-colors">
                      <Edit2 className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                    </button>
                    <button className="p-2 rounded-lg hover:bg-[#F5F5F2] transition-colors">
                      <Download className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                    </button>
                  </div>
                </div>

                <div className="mb-6">
                  <h2 className="text-[22px] text-[#1C1C1C] mb-3" style={{ fontWeight: 500 }}>
                    {currentPaper.title}
                  </h2>
                  <p className="text-[15px] text-[#1C1C1C]/60 mb-4">
                    {currentPaper.authors} • {currentPaper.year} • {currentPaper.venue}
                  </p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {currentPaper.tags.map((tag, idx) => (
                      <StatusTag key={idx} label={tag} variant="course" size="sm" />
                    ))}
                    {currentPaper.status === 'read' && <StatusTag label="Read" variant="priority" size="sm" />}
                    {currentPaper.status === 'reading' && <StatusTag label="Reading" variant="due" size="sm" />}
                    {currentPaper.status === 'to-read' && <StatusTag label="To Read" variant="status" size="sm" />}
                  </div>
                </div>

                {currentPaper.abstract && (
                  <div className="mb-6 pb-6 border-b border-[#D7D7D2]">
                    <h3 className="text-[13px] uppercase tracking-wide text-[#1C1C1C]/60 mb-3" style={{ fontWeight: 600 }}>
                      Abstract
                    </h3>
                    <p className="text-[15px] text-[#1C1C1C]/70 leading-relaxed">
                      {currentPaper.abstract}
                    </p>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-4 mb-6 pb-6 border-b border-[#D7D7D2]">
                  <div className="text-center p-4 bg-[#F5F5F2] rounded-lg">
                    <div className="text-[24px] text-[#1C1C1C] mb-1" style={{ fontWeight: 600 }}>
                      {currentPaper.cited}
                    </div>
                    <div className="text-[13px] text-[#1C1C1C]/60">Citations in Your Work</div>
                  </div>
                  <div className="text-center p-4 bg-[#F5F5F2] rounded-lg">
                    <div className="text-[24px] text-[#1C1C1C] mb-1" style={{ fontWeight: 600 }}>
                      {currentPaper.notes}
                    </div>
                    <div className="text-[13px] text-[#1C1C1C]/60">Notes Created</div>
                  </div>
                  <div className="text-center p-4 bg-[#F5F5F2] rounded-lg">
                    <div className="text-[24px] text-[#1C1C1C] mb-1" style={{ fontWeight: 600 }}>
                      {currentPaper.usedInProjects?.length || 0}
                    </div>
                    <div className="text-[13px] text-[#1C1C1C]/60">Projects</div>
                  </div>
                </div>

                {currentPaper.usedInProjects && currentPaper.usedInProjects.length > 0 && (
                  <div>
                    <h3 className="text-[13px] uppercase tracking-wide text-[#1C1C1C]/60 mb-3" style={{ fontWeight: 600 }}>
                      Used in Writing Projects
                    </h3>
                    <div className="space-y-2">
                      {currentPaper.usedInProjects.map((project, idx) => (
                        <div
                          key={idx}
                          className="flex items-center gap-3 p-3 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]/50 hover:border-[#AEC8A6]/30 transition-colors cursor-pointer"
                        >
                          <FileText className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                          <span className="text-[14px] text-[#1C1C1C]">{project}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </YooniCard>

              {/* Quick Actions */}
              <YooniCard>
                <h3 className="text-[15px] text-[#1C1C1C] mb-4" style={{ fontWeight: 500 }}>
                  Quick Actions
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <button className="flex items-center gap-2 px-4 py-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left">
                    <Edit2 className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                    <span className="text-[14px] text-[#1C1C1C]">Add Note</span>
                  </button>
                  <button className="flex items-center gap-2 px-4 py-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left">
                    <BookmarkPlus className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                    <span className="text-[14px] text-[#1C1C1C]">Add to Collection</span>
                  </button>
                  <button className="flex items-center gap-2 px-4 py-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left">
                    <Tag className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                    <span className="text-[14px] text-[#1C1C1C]">Manage Tags</span>
                  </button>
                  <button className="flex items-center gap-2 px-4 py-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left">
                    <ExternalLink className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                    <span className="text-[14px] text-[#1C1C1C]">Open Original</span>
                  </button>
                </div>
              </YooniCard>
            </div>
          ) : (
            // Papers List View
            <YooniCard>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60 mb-1" style={{ fontWeight: 600 }}>
                    {activeCollection || 'All Papers'}
                  </h3>
                  <p className="text-sm text-[#1C1C1C]/50">
                    {filteredPapers.length} {filteredPapers.length === 1 ? 'paper' : 'papers'}
                    {statusFilter !== 'all' && ` • ${statusFilter === 'to-read' ? 'to read' : statusFilter}`}
                  </p>
                </div>
                <button className="px-4 py-2 bg-[#AEC8A6]/15 text-[#8BAA82] rounded-lg hover:bg-[#AEC8A6]/25 transition-colors text-[14px]" style={{ fontWeight: 500 }}>
                  <Plus className="w-4 h-4 inline-block mr-1.5" strokeWidth={1.5} />
                  Add Paper
                </button>
              </div>

              {filteredPapers.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full bg-[#D7D7D2]/30 flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-[#1C1C1C]/40" strokeWidth={1.5} />
                  </div>
                  <p className="text-[15px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                    No papers found
                  </p>
                  <p className="text-[14px] text-[#1C1C1C]/60">
                    Try adjusting your search or filters
                  </p>
                </div>
              ) : (
                <div className="space-y-0">
                  {filteredPapers.map((paper) => (
                    <div
                      key={paper.id}
                      onClick={() => setSelectedPaper(paper.id)}
                      className="py-5 border-b border-[#D7D7D2] last:border-b-0 hover:bg-[#F5F5F2] -mx-6 px-6 transition-colors cursor-pointer group"
                    >
                      <div className="flex items-start gap-4">
                        <div className="flex-1">
                          <div className="flex items-start gap-3 mb-2">
                            <FileText className="w-5 h-5 text-[#AEC8A6] flex-shrink-0 mt-0.5" strokeWidth={1.5} />
                            <div className="flex-1">
                              <h4 className="text-[16px] text-[#1C1C1C] mb-2 group-hover:text-[#8BAA82] transition-colors" style={{ fontWeight: 500 }}>
                                {paper.title}
                              </h4>
                              <p className="text-[13px] text-[#1C1C1C]/60 mb-3">
                                {paper.authors} • {paper.year} • {paper.venue}
                              </p>
                              <div className="flex items-center gap-2 mb-3 flex-wrap">
                                {paper.tags.slice(0, 3).map((tag, idx) => (
                                  <StatusTag key={idx} label={tag} variant="course" size="sm" />
                                ))}
                                {paper.tags.length > 3 && (
                                  <span className="text-[12px] text-[#1C1C1C]/40">+{paper.tags.length - 3}</span>
                                )}
                              </div>
                              <div className="flex items-center gap-4 text-[12px] text-[#1C1C1C]/50">
                                <div className="flex items-center gap-1.5">
                                  {getStatusIcon(paper.status)}
                                  <span className="capitalize">{paper.status === 'to-read' ? 'To Read' : paper.status}</span>
                                </div>
                                {paper.cited > 0 && (
                                  <>
                                    <span>•</span>
                                    <span>{paper.cited} citations</span>
                                  </>
                                )}
                                {paper.notes > 0 && (
                                  <>
                                    <span>•</span>
                                    <span>{paper.notes} notes</span>
                                  </>
                                )}
                                {paper.usedInProjects && paper.usedInProjects.length > 0 && (
                                  <>
                                    <span>•</span>
                                    <span>{paper.usedInProjects.length} projects</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                            className="p-2 rounded-lg hover:bg-[#D7D7D2]/40 transition-colors"
                          >
                            <ExternalLink className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                            className="p-2 rounded-lg hover:bg-[#D7D7D2]/40 transition-colors"
                          >
                            <Download className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </YooniCard>
          )}
        </div>
      </div>
    </div>
  );
}