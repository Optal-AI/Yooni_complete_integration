import React, { useState, useEffect } from 'react';
import { YooniCard } from '../YooniCard';
import { YooniButton } from '../YooniButton';
import { ScoreChip } from '../ScoreChip';
import { EssayTextWithCitations } from '../EssayTextWithCitations';
import { 
  ArrowLeft, 
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  FileText,
  X
} from 'lucide-react';
import { evaluateWriting, improveWriting, getDefaultRubric, WritingEvaluation } from '../../services/writingService';

interface ProjectScorePageProps {
  projectId: string;
  onBack: () => void;
  onApplyImprovedContent: (content: string) => void;
  writingContent?: string;
  rubricContent?: string;
}

interface SectionScore {
  name: string;
  score: number;
  improvedScore: number;
  maxScore: number;
  feedback: string;
  improvementNote: string;
}

export function ProjectScorePage({ projectId, onBack, onApplyImprovedContent, writingContent, rubricContent }: ProjectScorePageProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [hasAnalyzed, setHasAnalyzed] = useState(false);
  const [showImprovedVersion, setShowImprovedVersion] = useState(false);
  const [isImproving, setIsImproving] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const [sectionScores, setSectionScores] = useState<SectionScore[]>([]);
  const [currentEvaluation, setCurrentEvaluation] = useState<WritingEvaluation | null>(null);
  const [improvedContent, setImprovedContent] = useState<string>('');
  const [improvedEvaluation, setImprovedEvaluation] = useState<WritingEvaluation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [actualRubricContent, setActualRubricContent] = useState<string | undefined>(rubricContent);
  const [originalEssay, setOriginalEssay] = useState<string>(writingContent || '');

  // Load rubric and evaluate writing on mount
  useEffect(() => {
    const loadRubricAndEvaluate = async () => {
      if (!writingContent) {
        setError('No writing content provided');
        return;
      }

      setIsAnalyzing(true);
      setError(null);

      try {
        // Get rubric content (from prop, localStorage, or default)
        let rubric = actualRubricContent;
        
        if (!rubric) {
          // Try to get from localStorage
          const storedRubric = localStorage.getItem(`rubric_content_${projectId}`);
          if (storedRubric) {
            rubric = storedRubric;
            setActualRubricContent(rubric);
          } else {
            // Get default rubric
            const defaultRubricResult = await getDefaultRubric();
            if (defaultRubricResult.success && defaultRubricResult.rubric_content) {
              rubric = defaultRubricResult.rubric_content;
              setActualRubricContent(rubric);
            }
          }
        }

        // Evaluate writing
        const evaluationResult = await evaluateWriting(writingContent, rubric);
        
        if (evaluationResult.success && evaluationResult.evaluation) {
          setCurrentEvaluation(evaluationResult.evaluation);
          
          // Convert evaluation to section scores
          const sections: SectionScore[] = evaluationResult.evaluation.sections.map(section => ({
            name: section.name,
            score: section.score,
            improvedScore: section.score, // Will be updated after improvement
            maxScore: section.maxScore,
            feedback: section.feedback,
            improvementNote: ''
          }));
          
          setSectionScores(sections);
          setHasAnalyzed(true);
        } else {
          setError(evaluationResult.error || 'Failed to evaluate writing');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to evaluate writing');
      } finally {
        setIsAnalyzing(false);
      }
    };

    if (writingContent) {
      loadRubricAndEvaluate();
    }
  }, [projectId, writingContent, actualRubricContent]);

  const currentTotal = currentEvaluation?.totalScore || sectionScores.reduce((sum, s) => sum + s.score, 0);
  const improvedTotal = improvedEvaluation?.totalScore || sectionScores.reduce((sum, s) => sum + s.improvedScore, 0);
  const maxTotal = currentEvaluation?.maxTotalScore || sectionScores.reduce((sum, s) => sum + s.maxScore, 0);

  const handleImproveScore = async () => {
    if (!writingContent) {
      setError('No writing content to improve');
      return;
    }

    setIsImproving(true);
    setError(null);

    try {
      // Ensure we have rubric content (use default if none uploaded)
      let rubricToUse = actualRubricContent;
      
      if (!rubricToUse) {
        // Try localStorage
        const storedRubric = localStorage.getItem(`rubric_content_${projectId}`);
        if (storedRubric) {
          rubricToUse = storedRubric;
          setActualRubricContent(rubricToUse);
        } else {
          // Get default rubric
          const defaultRubricResult = await getDefaultRubric();
          if (defaultRubricResult.success && defaultRubricResult.rubric_content) {
            rubricToUse = defaultRubricResult.rubric_content;
            setActualRubricContent(rubricToUse);
          }
        }
      }

      const improvementResult = await improveWriting(
        writingContent,
        rubricToUse,
        currentEvaluation || undefined
      );

      if (improvementResult.success && improvementResult.improved_content) {
        setImprovedContent(improvementResult.improved_content);
        
        if (improvementResult.improved_evaluation) {
          setImprovedEvaluation(improvementResult.improved_evaluation);
          
          // Update section scores with improved scores
          const updatedSections = sectionScores.map((section, index) => {
            const improvedSection = improvementResult.improved_evaluation?.sections[index];
            if (improvedSection) {
              return {
                ...section,
                improvedScore: improvedSection.score,
                improvementNote: `Improved from ${section.score}/${section.maxScore} to ${improvedSection.score}/${section.maxScore}`
              };
            }
            return section;
          });
          
          setSectionScores(updatedSections);
        }
        
        setShowImprovedVersion(true);
      } else {
        setError(improvementResult.error || 'Failed to improve writing');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to improve writing');
    } finally {
      setIsImproving(false);
    }
  };

  return (
    <div>
      {/* Back Button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#1C1C1C]/60 hover:text-[#1C1C1C] mb-6"
      >
        <ArrowLeft className="w-5 h-5" strokeWidth={1.5} />
        <span>Back to Project</span>
      </button>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-start gap-4 mb-4">
          <div className="w-12 h-12 rounded-lg bg-[#AEC8A6]/10 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-[#8BAA82]" strokeWidth={1.5} />
          </div>
          <div>
            <h1 className="text-[#1C1C1C] mb-2">Rubric Analysis</h1>
            <p className="text-[#1C1C1C]/60">Research Proposal — Neural approaches to sentiment analysis</p>
          </div>
        </div>
      </div>

      <div className="max-w-4xl">
        {/* Overall Score Card */}
        <YooniCard className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60 mb-2" style={{ fontWeight: 600 }}>
                {showImprovedVersion ? 'Improved Overall Score' : 'Current Overall Score'}
              </h3>
              <div className="flex items-baseline gap-3">
                <div className="text-[48px] text-[#1C1C1C]" style={{ fontWeight: 600 }}>
                  {showImprovedVersion ? improvedTotal : currentTotal}
                </div>
                <div className="text-[24px] text-[#1C1C1C]/40">
                  / {maxTotal}
                </div>
              </div>
              <div className="mt-2 text-[14px] text-[#1C1C1C]/60">
                {showImprovedVersion 
                  ? `Increased by ${improvedTotal - currentTotal} points`
                  : `${Math.round((currentTotal / maxTotal) * 100)}% of maximum score`
                }
              </div>
            </div>
            
            {showImprovedVersion && (
              <div className="flex flex-col items-end">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#AEC8A6]/10 border border-[#AEC8A6]/30">
                  <TrendingUp className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
                  <span className="text-[18px] text-[#8BAA82]" style={{ fontWeight: 600 }}>
                    +{improvedTotal - currentTotal}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Score breakdown */}
          <div className="pt-6 border-t border-[#D7D7D2]">
            <div className="grid grid-cols-2 gap-4">
              {sectionScores.length > 0 ? (
                sectionScores.map((section, index) => (
                  <ScoreChip
                    key={index}
                    label={section.name}
                    score={showImprovedVersion ? section.improvedScore : section.score}
                    maxScore={section.maxScore}
                  />
                ))
              ) : (
                <div className="text-[14px] text-[#1C1C1C]/60">Loading scores...</div>
              )}
            </div>
          </div>
        </YooniCard>

        {/* Error Message */}
        {error && (
          <YooniCard className="mb-8 border-red-200 bg-red-50">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" strokeWidth={1.5} />
              <div className="text-red-600 text-[14px]">
                {error}
              </div>
            </div>
          </YooniCard>
        )}

        {/* Loading State */}
        {isAnalyzing && !hasAnalyzed && (
          <YooniCard className="mb-8">
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-full bg-[#AEC8A6]/10 flex items-center justify-center mx-auto mb-5">
                <Sparkles className="w-8 h-8 text-[#8BAA82]" strokeWidth={1.5} />
              </div>
              <p className="text-[17px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                Analyzing your writing
              </p>
              <p className="text-[14px] text-[#1C1C1C]/50 mb-6 max-w-md mx-auto leading-relaxed">
                Evaluating against rubric criteria...
              </p>
              <div className="max-w-xs mx-auto">
                <div className="w-full h-1 bg-[#D7D7D2]/40 rounded-full overflow-hidden">
                  <div className="h-full bg-[#AEC8A6] rounded-full animate-pulse" style={{ width: '60%' }} />
                </div>
              </div>
            </div>
          </YooniCard>
        )}

        {/* Please Fix Button - Always visible */}
        {!isAnalyzing && (
          <div className="mb-8">
            <YooniButton variant="primary" onClick={handleImproveScore} disabled={isImproving || !writingContent}>
              <Sparkles className="w-4 h-4 mr-2" strokeWidth={1.5} />
              {isImproving ? 'Rewriting to improve...' : 'Please Fix'}
            </YooniButton>
            {isImproving && (
              <div className="mt-4">
                <div className="w-full h-1 bg-[#D7D7D2] rounded-full overflow-hidden">
                  <div className="h-full bg-[#AEC8A6] rounded-full animate-pulse" style={{ width: '70%' }} />
                </div>
                <p className="text-sm text-[#1C1C1C]/60 mt-2">
                  {actualRubricContent 
                    ? 'Analyzing uploaded rubric and rewriting to improve your writing...'
                    : 'Using default academic rubric and rewriting to improve your writing...'}
                </p>
              </div>
            )}
            {!writingContent && (
              <p className="text-sm text-[#1C1C1C]/50 mt-2">
                Please add writing content to enable fixing
              </p>
            )}
          </div>
        )}

        {/* Success Banner */}
        {showImprovedVersion && (
          <div className="mb-8 p-5 bg-[#AEC8A6]/10 rounded-lg border border-[#AEC8A6]/30">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#8BAA82] flex-shrink-0 mt-0.5" strokeWidth={1.5} />
              <div className="flex-1">
                <div className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                  Improved version ready
                </div>
                <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed mb-4">
                  Your essay has been rewritten to improve rubric scores while maintaining your authentic voice and writing style. Review the improvements below.
                </p>
                <div className="flex items-center gap-4">
                  <YooniButton variant="primary" onClick={() => onApplyImprovedContent(improvedContent || '')}>
                    <FileText className="w-4 h-4 mr-2" strokeWidth={1.5} />
                    Apply to Project
                  </YooniButton>
                  <YooniButton variant="secondary" onClick={() => setShowComparison(true)}>
                    Compare Side-by-Side
                  </YooniButton>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Section-by-Section Analysis */}
        <YooniCard className="mb-8">
          <div className="mb-6">
            <h3 className="text-[#1C1C1C] mb-2">Detailed Analysis by Section</h3>
            <p className="text-sm text-[#1C1C1C]/60">
              How each rubric criterion was evaluated
            </p>
          </div>

          <div className="space-y-4">
            {sectionScores.length > 0 ? sectionScores.map((section, index) => (
              <div key={index} className="p-5 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                    {section.name}
                  </h4>
                  <div className="flex items-center gap-3">
                    <ScoreChip
                      label="Current"
                      score={section.score}
                      maxScore={section.maxScore}
                    />
                    {showImprovedVersion && (
                      <>
                        <span className="text-[#1C1C1C]/40">→</span>
                        <ScoreChip
                          label="Improved"
                          score={section.improvedScore}
                          maxScore={section.maxScore}
                        />
                      </>
                    )}
                  </div>
                </div>

                <div className="mb-3">
                  <div className="text-sm text-[#1C1C1C]/60 mb-1.5">Feedback:</div>
                  <div className="text-[14px] text-[#1C1C1C]/70 leading-relaxed">
                    {section.feedback}
                  </div>
                </div>

                {showImprovedVersion && (
                  <div className="pt-3 border-t border-[#D7D7D2]">
                    <div className="text-sm text-[#1C1C1C]/60 mb-1.5">What was improved:</div>
                    <div className="text-[14px] text-[#8BAA82] leading-relaxed">
                      {section.improvementNote}
                    </div>
                  </div>
                )}
              </div>
            )) : (
              <div className="text-center py-8 text-[#1C1C1C]/60 text-[14px]">
                {isAnalyzing ? 'Loading analysis...' : 'No evaluation data available'}
              </div>
            )}
          </div>
        </YooniCard>

        {/* Essay Preview */}
        <YooniCard className="mb-8">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-[#1C1C1C]">
              {showImprovedVersion ? 'Improved Essay' : 'Your Essay'}
            </h3>
            {showImprovedVersion && (
              <div className="flex items-center gap-2 text-sm text-[#1C1C1C]/60">
                <div className="w-3 h-3 rounded bg-[#AEC8A6]/20 border-b-2 border-[#AEC8A6]/40" />
                <span>New citations highlighted</span>
              </div>
            )}
          </div>
          <div className="p-5 bg-[#F5F5F2] rounded-lg">
            <EssayTextWithCitations
              text={showImprovedVersion ? (improvedContent || '') : originalEssay}
              highlightCitations={showImprovedVersion}
            />
          </div>
        </YooniCard>
      </div>

      {/* Comparison Modal */}
      {showComparison && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-[#1C1C1C]/40 z-50"
            onClick={() => setShowComparison(false)}
          />
          
          {/* Modal */}
          <div className="fixed inset-4 z-50 bg-white rounded-lg shadow-2xl flex flex-col overflow-hidden max-w-7xl mx-auto">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-[#D7D7D2]">
              <div>
                <h2 className="text-[20px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                  Side-by-Side Comparison
                </h2>
                <p className="text-[14px] text-[#1C1C1C]/60">
                  Original version vs. Improved version
                </p>
              </div>
              <button
                onClick={() => setShowComparison(false)}
                className="p-2 hover:bg-[#D7D7D2]/30 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-[#1C1C1C]/60" strokeWidth={1.5} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto p-6">
              <div className="grid grid-cols-2 gap-6 h-full">
                {/* Original */}
                <div className="flex flex-col">
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-[15px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                        Original
                      </h3>
                      <div className="flex items-center gap-2">
                        <ScoreChip label="Score" score={currentTotal} maxScore={maxTotal} />
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 p-5 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2] overflow-auto">
                    <EssayTextWithCitations
                      text={originalEssay}
                      highlightCitations={false}
                    />
                  </div>
                </div>

                {/* Improved */}
                <div className="flex flex-col">
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-[15px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                        Improved
                      </h3>
                      <div className="flex items-center gap-2">
                        <ScoreChip label="Score" score={improvedTotal} maxScore={maxTotal} />
                        <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#AEC8A6]/15 border border-[#AEC8A6]/30">
                          <TrendingUp className="w-3.5 h-3.5 text-[#8BAA82]" strokeWidth={1.5} />
                          <span className="text-[13px] text-[#8BAA82]" style={{ fontWeight: 500 }}>
                            +{improvedTotal - currentTotal}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 p-5 bg-[#F5F5F2] rounded-lg border border-[#AEC8A6]/30 overflow-auto">
                    <EssayTextWithCitations
                      text={improvedContent || ''}
                      highlightCitations={true}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-[#D7D7D2] bg-[#F5F5F2]">
              <p className="text-[13px] text-[#1C1C1C]/60">
                Review the changes and apply them to your project
              </p>
              <div className="flex items-center gap-3">
                <YooniButton variant="secondary" onClick={() => setShowComparison(false)}>
                  Close
                </YooniButton>
                <YooniButton 
                  variant="primary" 
                  onClick={() => {
                    onApplyImprovedContent(improvedContent || '');
                    setShowComparison(false);
                  }}
                >
                  <FileText className="w-4 h-4 mr-2" strokeWidth={1.5} />
                  Apply to Project
                </YooniButton>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}