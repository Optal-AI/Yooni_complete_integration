import React, { useState, useEffect } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { YooniButton } from '../YooniButton';
import { YooniInput } from '../YooniInput';
import { YooniTextarea } from '../YooniTextarea';
import { StatusTag } from '../StatusTag';
import { Copy, CheckCircle2, Search, Star, Trash2, Plus, BookOpen } from 'lucide-react';
import { copyToClipboard } from '../../utils/clipboard';
import { API_CONFIG } from '../../config/api';

export function SearchPapersPage() {
  const [copiedCitation, setCopiedCitation] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Topic search and sessions
  const [searchTopic, setSearchTopic] = useState('');
  const [maxPapers, setMaxPapers] = useState(5);
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any>(null);
  const [sessions, setSessions] = useState<any[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [showFavorites, setShowFavorites] = useState(false);

  // Load sessions and favorites on mount
  useEffect(() => {
    loadSessions();
    loadFavorites();
  }, []);

  // Load sessions from localStorage
  const loadSessions = () => {
    try {
      const saved = localStorage.getItem('researchSessions');
      if (saved) {
        const sessionsList = JSON.parse(saved);
        setSessions(sessionsList);
        if (sessionsList.length > 0 && !activeSessionId) {
          setActiveSessionId(sessionsList[0].id);
          setSearchResults(sessionsList[0].data);
        }
      }
    } catch (err) {
      console.error('Error loading sessions:', err);
    }
  };

  // Load favorites from localStorage
  const loadFavorites = () => {
    try {
      const saved = localStorage.getItem('favoritePapers');
      if (saved) {
        setFavorites(JSON.parse(saved));
      }
    } catch (err) {
      console.error('Error loading favorites:', err);
    }
  };

  // Save sessions to localStorage
  const saveSessions = (sessionsList: any[]) => {
    try {
      localStorage.setItem('researchSessions', JSON.stringify(sessionsList));
    } catch (err) {
      console.error('Error saving sessions:', err);
    }
  };

  // Save favorites to localStorage
  const saveFavorites = (favs: any[]) => {
    try {
      localStorage.setItem('favoritePapers', JSON.stringify(favs));
    } catch (err) {
      console.error('Error saving favorites:', err);
    }
  };

  // Find papers for a topic
  const handleFindPapers = async () => {
    if (!searchTopic.trim()) {
      setError('Please enter a research topic');
      return;
    }

    setIsSearching(true);
    setError(null);

    try {
      const response = await fetch(`${API_CONFIG.ENDPOINTS.FIND_PAPERS}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          research_topic: searchTopic,
          max_papers: maxPapers
        })
      });

      const data = await response.json();
      setIsSearching(false);

      if (response.ok && data.evaluated_papers) {
        // Create a new session
        const sessionId = `session_${Date.now()}`;
        const newSession = {
          id: sessionId,
          topic: searchTopic,
          maxPapers,
          data: data,
          createdAt: new Date().toISOString(),
          papersCount: data.evaluated_papers.length
        };

        const updatedSessions = [newSession, ...sessions];
        setSessions(updatedSessions);
        saveSessions(updatedSessions);
        setActiveSessionId(sessionId);
        setSearchResults(data);
      } else {
        setError(data.error || 'Failed to find papers');
      }
    } catch (err) {
      setIsSearching(false);
      setError(err instanceof Error ? err.message : 'Failed to search papers');
    }
  };


  const handleCopyCitation = (citation: string) => {
    try {
      copyToClipboard(citation);
      setCopiedCitation(citation);
      setTimeout(() => setCopiedCitation(null), 2000);
    } catch (err) {
      console.error('Error copying citation:', err);
    }
  };


  // Delete a session
  const handleDeleteSession = (sessionId: string) => {
    const updatedSessions = sessions.filter(s => s.id !== sessionId);
    setSessions(updatedSessions);
    saveSessions(updatedSessions);
    
    if (activeSessionId === sessionId) {
      if (updatedSessions.length > 0) {
        setActiveSessionId(updatedSessions[0].id);
        setSearchResults(updatedSessions[0].data);
      } else {
        setActiveSessionId(null);
        setSearchResults(null);
      }
    }
  };

  // Create a new session
  const handleNewSession = () => {
    setSearchTopic('');
    setMaxPapers(5);
    setSearchResults(null);
    setActiveSessionId(null);
    setError(null);
  };

  // Toggle favorite for a paper
  const toggleFavorite = (paper: any) => {
    try {
      const paperId = paper.paper_info?.arxiv_id || paper.paper_info?.url || paper.title;
      const existingIndex = favorites.findIndex(f => 
        (f.paper_info?.arxiv_id || f.paper_info?.url || f.title) === paperId
      );

      let updatedFavorites;
      if (existingIndex >= 0) {
        // Remove from favorites
        updatedFavorites = favorites.filter((_, idx) => idx !== existingIndex);
      } else {
        // Add to favorites
        updatedFavorites = [
          {
            ...paper,
            favoritedAt: new Date().toISOString()
          },
          ...favorites
        ];
      }

      setFavorites(updatedFavorites);
      saveFavorites(updatedFavorites);
    } catch (err) {
      console.error('Error toggling favorite:', err);
    }
  };

  // Check if paper is favorited
  const isFavorited = (paper: any): boolean => {
    const paperId = paper.paper_info?.arxiv_id || paper.paper_info?.url || paper.title;
    return favorites.some(f => 
      (f.paper_info?.arxiv_id || f.paper_info?.url || f.title) === paperId
    );
  };

  // Generate APA citation for a paper
  const generateAPACitation = (paper: any): string => {
    try {
      const paperInfo = paper.paper_info || paper;
      const authors = paperInfo.authors || [];
      const title = paperInfo.title || 'Untitled';
      const year = paperInfo.published?.split('-')[0] || new Date().getFullYear().toString();
      const arxivId = paperInfo.arxiv_id || '';
      
      let authorString = '';
      if (Array.isArray(authors) && authors.length > 0) {
        if (authors.length === 1) {
          authorString = formatAuthorName(authors[0]);
        } else if (authors.length <= 7) {
          authorString = authors.map((a: string) => formatAuthorName(a)).join(', ');
          authorString = authorString.replace(/,([^,]*)$/, ', &$1');
        } else {
          authorString = authors.slice(0, 6).map((a: string) => formatAuthorName(a)).join(', ') + 
                         ', ... ' + formatAuthorName(authors[authors.length - 1]);
        }
      } else {
        authorString = 'Author, A. A.';
      }
      
      let citation = `${authorString} (${year}). ${title}`;
      if (arxivId) {
        citation += `. arXiv preprint arXiv:${arxivId}`;
      }
      if (paperInfo.url || paperInfo.pdf_url) {
        citation += `. ${paperInfo.url || paperInfo.pdf_url}`;
      } else {
        citation += '.';
      }
      
      return citation;
    } catch (err) {
      console.error('Error generating APA citation:', err);
      return 'Citation not available';
    }
  };

  const formatAuthorName = (fullName: string): string => {
    if (!fullName) return 'Author, A. A.';
    const parts = fullName.trim().split(/\s+/);
    if (parts.length === 0) return 'Author, A. A.';
    
    const lastName = parts[parts.length - 1];
    const firstNames = parts.slice(0, -1);
    
    let initials = '';
    if (firstNames.length > 0) {
      initials = firstNames.map((name: string) => name.charAt(0).toUpperCase() + '.').join(' ');
    } else {
      initials = 'A.';
    }
    
    return `${lastName}, ${initials}`;
  };

  return (
    <div>
      <PageHeader 
        title="Search Papers" 
        subtitle="Find relevant research papers based on keywords with AI-powered relevance scoring."
      />

      {/* Section 2: Find Relevant Papers by Keyword */}
      <YooniCard className="mb-6" topAccent>
        <div className="mb-4">
          <h2 className="text-[20px] text-[#1C1C1C] mb-2" style={{ fontWeight: 600 }}>
            Find Relevant Papers
          </h2>
          <p className="text-[13px] text-[#1C1C1C]/60 leading-relaxed">
            Search for papers related to your research topic with AI-powered relevance scoring and summaries
          </p>
        </div>
        <div className="flex gap-3">
          <YooniInput
            type="text"
            value={searchTopic}
            onChange={(e) => setSearchTopic(e.target.value)}
            placeholder="e.g., transformer models in NLP"
            className="flex-1"
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !isSearching) {
                handleFindPapers();
              }
            }}
          />
          <div className="flex items-center gap-2">
            <label className="text-[13px] text-[#1C1C1C]/60 whitespace-nowrap">Max:</label>
            <YooniInput
              type="number"
              value={maxPapers}
              onChange={(e) => setMaxPapers(Math.max(1, Math.min(20, parseInt(e.target.value) || 5)))}
              min={1}
              max={20}
              className="w-20"
            />
          </div>
          <YooniButton
            onClick={handleFindPapers}
            disabled={isSearching || !searchTopic.trim()}
            className="whitespace-nowrap"
          >
            {isSearching ? 'Searching...' : 'Find Papers'}
          </YooniButton>
        </div>
      </YooniCard>

      {/* Sessions Management */}
      {sessions.length > 0 && (
        <YooniCard className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
              Search Sessions
            </h3>
            <YooniButton
              onClick={handleNewSession}
              variant="secondary"
              className="flex items-center gap-2"
            >
              <Plus className="w-4 h-4" strokeWidth={1.5} />
              New Session
            </YooniButton>
          </div>
          <div className="flex flex-wrap gap-2">
            {sessions.map((session) => (
              <div
                key={session.id}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-colors cursor-pointer ${
                  activeSessionId === session.id
                    ? 'bg-[#AEC8A6]/20 border-[#AEC8A6]'
                    : 'bg-[#F5F5F2] border-[#D7D7D2] hover:border-[#AEC8A6]/50'
                }`}
                onClick={() => {
                  setActiveSessionId(session.id);
                  setSearchResults(session.data);
                }}
              >
                <BookOpen className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                <span className="text-[13px] text-[#1C1C1C]">
                  {session.topic.substring(0, 30)}{session.topic.length > 30 ? '...' : ''}
                </span>
                <span className="text-[11px] text-[#1C1C1C]/50">
                  ({session.papersCount} papers)
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteSession(session.id);
                  }}
                  className="ml-1 p-1 hover:bg-[#D7D7D2]/40 rounded transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5 text-[#1C1C1C]/50" strokeWidth={1.5} />
                </button>
              </div>
            ))}
          </div>
        </YooniCard>
      )}

      {/* Favorites Bar */}
      <YooniCard className="mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} fill={favorites.length > 0 ? '#8BAA82' : 'none'} />
            <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
              Favorites ({favorites.length})
            </h3>
          </div>
          <YooniButton
            onClick={() => setShowFavorites(!showFavorites)}
            variant="secondary"
            className="text-[13px]"
          >
            {showFavorites ? 'Hide' : 'Show'} Favorites
          </YooniButton>
        </div>
        {showFavorites && favorites.length > 0 && (
          <div className="mt-4 space-y-2 max-h-64 overflow-y-auto">
            {favorites.map((fav, idx) => {
              const paperInfo = fav.paper_info || fav;
              return (
                <div
                  key={idx}
                  className="p-3 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]/50 hover:border-[#AEC8A6]/50 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-[14px] text-[#1C1C1C] mb-1 line-clamp-2" style={{ fontWeight: 500 }}>
                        {paperInfo.title || 'Untitled'}
                      </h4>
                      <p className="text-[12px] text-[#1C1C1C]/60">
                        {Array.isArray(paperInfo.authors) ? paperInfo.authors.join(', ') : paperInfo.authors || 'Unknown'}
                      </p>
                    </div>
                    <button
                      onClick={() => toggleFavorite(fav)}
                      className="p-1.5 hover:bg-[#D7D7D2]/40 rounded transition-colors flex-shrink-0"
                    >
                      <Star className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} fill="#8BAA82" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        {showFavorites && favorites.length === 0 && (
          <div className="mt-4 text-center py-8 text-[#1C1C1C]/50 text-[13px]">
            No favorite papers yet. Star papers to add them here.
          </div>
        )}
      </YooniCard>

      {error && (
        <YooniCard className="mb-6 border-red-200 bg-red-50">
          <div className="text-red-600 text-[14px]">
            {error}
          </div>
        </YooniCard>
      )}

      {/* Main Content Area - Search Results */}
      <div>
        {/* Search Results Section */}
        {searchResults && searchResults.evaluated_papers && searchResults.evaluated_papers.length > 0 && (
            <YooniCard className="mb-6">
              <div className="mb-6">
                <h3 className="text-[18px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                  Search Results: {searchResults.research_topic || 'Research Papers'}
                </h3>
                <p className="text-[13px] text-[#1C1C1C]/60">
                  Found {searchResults.papers_found} papers, evaluated {searchResults.evaluated_papers.length}
                </p>
              </div>

              <div className="space-y-4">
                {searchResults.evaluated_papers.map((item: any, idx: number) => {
                  const paperInfo = item.paper_info || {};
                  const evaluation = item.evaluation || {};
                  const isFav = isFavorited(item);
                  const apaCitation = generateAPACitation(item);
                  
                  return (
                    <div
                      key={idx}
                      className="p-5 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]/50 hover:border-[#AEC8A6]/50 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <div className="flex-1">
                          <h4 className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                            {idx + 1}. {paperInfo.title || 'Untitled Paper'}
                          </h4>
                          <div className="text-[13px] text-[#1C1C1C]/60 mb-2">
                            {Array.isArray(paperInfo.authors) ? paperInfo.authors.join(', ') : paperInfo.authors || 'Unknown'} • {paperInfo.published?.split('-')[0] || 'N/A'}
                          </div>
                          {evaluation.overall_match_percentage !== undefined && (
                            <div className="flex items-center gap-2 mb-3">
                              <span className="text-[12px] text-[#1C1C1C]/50">Match:</span>
                              <span className={`text-[14px] font-semibold ${
                                evaluation.overall_match_percentage >= 70 ? 'text-[#8BAA82]' :
                                evaluation.overall_match_percentage >= 50 ? 'text-[#AEC8A6]' :
                                'text-[#1C1C1C]/60'
                              }`}>
                                {evaluation.overall_match_percentage}%
                              </span>
                              {evaluation.relevance_score !== undefined && (
                                <span className="text-[12px] text-[#1C1C1C]/50">
                                  (Relevance: {evaluation.relevance_score}/10)
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => toggleFavorite(item)}
                          className={`p-2 rounded-lg transition-colors flex-shrink-0 ${
                            isFav ? 'bg-[#AEC8A6]/20' : 'hover:bg-[#D7D7D2]/40'
                          }`}
                          title={isFav ? 'Remove from favorites' : 'Add to favorites'}
                        >
                          <Star
                            className={`w-5 h-5 ${isFav ? 'text-[#8BAA82]' : 'text-[#1C1C1C]/40'}`}
                            strokeWidth={1.5}
                            fill={isFav ? '#8BAA82' : 'none'}
                          />
                        </button>
                      </div>

                      {item.summary && (
                        <div className="mb-4">
                          <div className="text-[12px] uppercase tracking-wide text-[#1C1C1C]/60 mb-2" style={{ fontWeight: 600 }}>
                            Summary
                          </div>
                          <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed">
                            {item.summary}
                          </p>
                        </div>
                      )}

                      {evaluation.reasoning && (
                        <div className="mb-4">
                          <div className="text-[12px] uppercase tracking-wide text-[#1C1C1C]/60 mb-2" style={{ fontWeight: 600 }}>
                            Evaluation
                          </div>
                          <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed">
                            {evaluation.reasoning}
                          </p>
                        </div>
                      )}

                      {/* Citations */}
                      <div className="mt-4 pt-4 border-t border-[#D7D7D2]">
                        <div className="text-[12px] uppercase tracking-wide text-[#1C1C1C]/60 mb-3" style={{ fontWeight: 600 }}>
                          Citations
                        </div>
                        <div className="space-y-2">
                          {['APA', 'MLA', 'Chicago'].map((format) => {
                            let citationText = '';
                            if (format === 'APA') {
                              citationText = apaCitation;
                            } else if (format === 'MLA') {
                              const authors = Array.isArray(paperInfo.authors) ? paperInfo.authors.join(', ') : paperInfo.authors || 'Author';
                              const title = paperInfo.title || 'Title';
                              const year = paperInfo.published?.split('-')[0] || 'Year';
                              citationText = `${authors}. "${title}." ${year}.`;
                            } else if (format === 'Chicago') {
                              const authors = Array.isArray(paperInfo.authors) ? paperInfo.authors.join(', ') : paperInfo.authors || 'Author';
                              const title = paperInfo.title || 'Title';
                              const year = paperInfo.published?.split('-')[0] || 'Year';
                              citationText = `${authors}. "${title}" (${year}).`;
                            }

                            return (
                              <div key={format} className="flex items-center justify-between gap-3 p-2 bg-white rounded border border-[#D7D7D2]/50">
                                <div className="flex-1 min-w-0">
                                  <div className="text-[11px] uppercase tracking-wide text-[#1C1C1C]/50 mb-1" style={{ fontWeight: 600 }}>
                                    {format}
                                  </div>
                                  <div className="text-[12px] text-[#1C1C1C]/80 break-words">
                                    {citationText}
                                  </div>
                                </div>
                                <button
                                  onClick={() => handleCopyCitation(citationText)}
                                  className="flex-shrink-0 p-1.5 hover:bg-[#D7D7D2]/40 rounded transition-colors"
                                  title="Copy citation"
                                >
                                  {copiedCitation === citationText ? (
                                    <CheckCircle2 className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                                  ) : (
                                    <Copy className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                                  )}
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Paper Links */}
                      {(paperInfo.pdf_url || paperInfo.arxiv_url || paperInfo.url) && (
                        <div className="mt-3 flex gap-2">
                          {paperInfo.pdf_url && (
                            <a
                              href={paperInfo.pdf_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[12px] text-[#8BAA82] hover:underline"
                            >
                              PDF
                            </a>
                          )}
                          {paperInfo.arxiv_url && (
                            <a
                              href={paperInfo.arxiv_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[12px] text-[#8BAA82] hover:underline"
                            >
                              arXiv
                            </a>
                          )}
                          {paperInfo.url && !paperInfo.pdf_url && !paperInfo.arxiv_url && (
                            <a
                              href={paperInfo.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[12px] text-[#8BAA82] hover:underline"
                            >
                              View Paper
                            </a>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </YooniCard>
          )}

        {!searchResults && (
          <YooniCard>
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-full bg-[#AEC8A6]/15 flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-[#8BAA82]" strokeWidth={1.5} />
              </div>
              <p className="text-[16px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                Search for research papers
              </p>
              <p className="text-[14px] text-[#1C1C1C]/60">
                Enter a research topic above to find relevant papers with AI-powered relevance scoring
              </p>
            </div>
          </YooniCard>
        )}
      </div>
    </div>
  );
}