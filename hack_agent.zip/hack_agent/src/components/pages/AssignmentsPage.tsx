import React, { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { ScoreChip } from '../ScoreChip';
import { YooniButton } from '../YooniButton';
import { YooniTextarea } from '../YooniTextarea';
import { EssayTextWithCitations } from '../EssayTextWithCitations';
import { ArrowLeft, Upload, CheckCircle2, BookOpen, Copy, Quote } from 'lucide-react';
import { copyToClipboard } from '../../utils/clipboard';

interface AssignmentsPageProps {
  onBack: () => void;
}

interface SuggestedPaper {
  title: string;
  authors: string;
  year: string;
  relevance: string;
  whereToUse: string;
}

interface SectionScore {
  name: string;
  score: number;
  improvedScore: number;
  maxScore: number;
  feedback: string;
  improvementNote: string;
}

export function AssignmentsPage({ onBack }: AssignmentsPageProps) {
  const [showImprovedVersion, setShowImprovedVersion] = useState(false);
  const [isImproving, setIsImproving] = useState(false);
  const [hasCustomRubric, setHasCustomRubric] = useState(false);
  const [copiedCitation, setCopiedCitation] = useState<string | null>(null);

  const suggestedPapers: SuggestedPaper[] = [
    {
      title: 'Attention Is All You Need',
      authors: 'Vaswani et al.',
      year: '2017',
      relevance: 'Foundational paper on attention mechanisms',
      whereToUse: 'Introduction - cite when discussing determinism in causal systems'
    },
  ];

  const sectionScores: SectionScore[] = [
    {
      name: 'Introduction & Thesis',
      score: 7,
      improvedScore: 10,
      maxScore: 10,
      feedback: 'Good philosophical framing but thesis could be more explicit about your position',
      improvementNote: 'Added clear thesis statement: "This essay advances the thesis that compatibilism offers..."'
    },
    {
      name: 'Argument Development',
      score: 8,
      improvedScore: 9,
      maxScore: 10,
      feedback: 'Strong logical flow but needs specific citations to support claims about Frankfurt and Dennett',
      improvementNote: 'Added citations: Frankfurt (1969), van Inwagen (1983), Dennett references with page numbers'
    },
    {
      name: 'Evidence & Citations',
      score: 7,
      improvedScore: 10,
      maxScore: 10,
      feedback: 'References philosophers but missing formal citations and specific page references',
      improvementNote: 'Integrated 4 properly formatted citations with specific page numbers and years'
    },
    {
      name: 'Conclusion',
      score: 8,
      improvedScore: 10,
      maxScore: 10,
      feedback: 'Summarizes well but could better synthesize implications',
      improvementNote: 'Expanded conclusion to address broader implications for moral responsibility'
    }
  ];

  const originalEssay = `The debate between free will and determinism has persisted throughout philosophical history, challenging our fundamental assumptions about human agency and moral responsibility. In this essay, I argue that compatibilism offers the most coherent framework for understanding free will within a deterministic universe.

Determinism suggests that every event, including human actions, is the inevitable result of prior causes. However, this need not negate free will if we understand freedom not as absolute independence from causation, but as the ability to act according to one's own desires and rational deliberation without external constraint.

Classical incompatibilists like van Inwagen argue that if determinism is true, then our actions are the inevitable consequences of the laws of nature and events in the remote past. Therefore, we cannot be truly responsible for our actions. However, this argument conflates freedom with ultimate origination, which may be an unreasonably high standard...`;

  const improvedEssay = `The debate between free will and determinism has persisted throughout philosophical history, challenging our fundamental assumptions about human agency and moral responsibility. This essay advances the thesis that compatibilism offers the most coherent framework for understanding free will within a deterministic universe.

Determinism posits that every event, including human actions, is the inevitable result of prior causes. However, this need not negate free will if we reconceptualize freedom not as absolute independence from causation, but rather as the capacity to act in accordance with one's own rational desires and deliberative processes without external constraint. This definition preserves moral responsibility while acknowledging causal necessity.

Classical incompatibilists such as van Inwagen (1983) argue that if determinism is true, then our actions are the inevitable consequences of the laws of nature and events in the remote past. Therefore, we cannot be truly responsible for our actions since we had no control over these antecedent conditions. However, this argument conflates freedom with ultimate origination—the requirement that we be the uncaused cause of our actions. As Frankfurt (1969) demonstrates, this standard may be unreasonably high and inconsistent with how we actually attribute moral responsibility in everyday contexts.

The compatibilist position, articulated by philosophers like Dennett and Frankfurt, suggests that freedom requires only that our actions flow from our own rational deliberation, not that we stand outside the causal chain entirely. When I choose to write this essay because I value philosophical inquiry and academic achievement, my action is both causally determined and genuinely free...`;

  const handleImproveScore = () => {
    setIsImproving(true);
    setTimeout(() => {
      setIsImproving(false);
      setShowImprovedVersion(true);
    }, 2000);
  };

  const handleRubricUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setHasCustomRubric(true);
      event.target.value = '';
    }
  };

  const handleCopyCitation = (citation: string) => {
    copyToClipboard(citation);
    setCopiedCitation(citation);
    setTimeout(() => {
      setCopiedCitation(null);
    }, 2000);
  };

  return (
    <div>
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[#1C1C1C]/60 hover:text-[#1C1C1C] mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" strokeWidth={1.5} />
        <span>Back to Assignments</span>
      </button>
      
      <PageHeader title="Assignment Detail" />

      <div className="max-w-3xl">
        {/* Header info */}
        <div className="mb-8">
          <h2 className="text-[#1C1C1C] mb-2">Philosophy Essay — Free Will and Determinism</h2>
          <p className="text-[#1C1C1C]/60">
            Due: <span className="text-[#AEC8A6]">November 18, 2025</span>
          </p>
        </div>

        {/* Rubric Upload */}
        <YooniCard className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-[#1C1C1C] mb-1">Rubric</h3>
              <p className="text-sm text-[#1C1C1C]/60">
                {hasCustomRubric ? 'Using custom rubric' : 'Using default rubric (Clarity, Argumentation, Evidence, Structure)'}
              </p>
            </div>
            <div>
              <input
                type="file"
                accept=".pdf, .docx"
                onChange={handleRubricUpload}
                className="hidden"
                id="rubric-upload"
              />
              <label 
                htmlFor="rubric-upload"
                className="inline-block px-4 py-2 rounded-lg transition-all duration-200 border border-[#D7D7D2] text-[#1C1C1C] text-sm bg-transparent hover:bg-[#D7D7D2]/30 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4" strokeWidth={1.5} />
                  <span>Upload Custom Rubric</span>
                </div>
              </label>
            </div>
          </div>
        </YooniCard>

        {/* Rubric breakdown */}
        <YooniCard className="mb-8">
          <div className="mb-6">
            <h3 className="text-[#1C1C1C] mb-2">
              {showImprovedVersion ? 'Improved Scores' : 'Current Scores'}
            </h3>
            <p className="text-sm text-[#1C1C1C]/60">
              AI-analyzed scores based on the rubric
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <ScoreChip 
              label="Clarity" 
              score={showImprovedVersion ? 10 : 8} 
              maxScore={10} 
            />
            <ScoreChip 
              label="Argumentation" 
              score={showImprovedVersion ? 9 : 7} 
              maxScore={10} 
            />
            <ScoreChip 
              label="Evidence Use" 
              score={showImprovedVersion ? 10 : 9} 
              maxScore={10} 
            />
            <ScoreChip 
              label="Structure" 
              score={showImprovedVersion ? 10 : 8} 
              maxScore={10} 
            />
          </div>

          <div className="pt-6 border-t border-[#D7D7D2]">
            <div className="mb-4">
              <h4 className="text-[#1C1C1C] mb-2">
                {showImprovedVersion ? 'Analysis of Improvements' : 'Areas for Improvement'}
              </h4>
              {showImprovedVersion ? (
                <p className="text-[#1C1C1C]/70">
                  Your revised essay now includes stronger thesis formulation, additional citations 
                  from Frankfurt (1969) and van Inwagen (1983), clearer topic sentences, and more 
                  explicit connections between paragraphs. The argument flows more naturally while 
                  maintaining your original voice and reasoning style.
                </p>
              ) : (
                <p className="text-[#1C1C1C]/70">
                  Your essay demonstrates strong philosophical analysis with clear arguments.
                  To improve your score, consider: (1) strengthening the thesis statement with more 
                  explicit positioning, (2) adding specific citations to support claims about 
                  Frankfurt and Dennett, (3) developing the counter-argument section with more depth, 
                  and (4) providing clearer transitions between paragraphs.
                </p>
              )}
            </div>
          </div>
        </YooniCard>

        {/* Improve score button */}
        {!showImprovedVersion && (
          <div className="mb-8">
            <YooniButton variant="primary" onClick={handleImproveScore}>
              {isImproving ? 'Rewriting assignment...' : 'Improve my score'}
            </YooniButton>
            {isImproving && (
              <div className="mt-4">
                <div className="w-full h-1 bg-[#D7D7D2] rounded-full overflow-hidden">
                  <div className="h-full bg-[#AEC8A6] rounded-full animate-pulse" style={{ width: '70%' }} />
                </div>
                <p className="text-sm text-[#1C1C1C]/60 mt-2">
                  Analyzing rubric and rewriting to match your writing style...
                </p>
              </div>
            )}
          </div>
        )}

        {showImprovedVersion && (
          <div className="mb-8 p-4 bg-[#AEC8A6]/10 rounded-lg border border-[#AEC8A6]/30">
            <div className="flex items-center gap-2 text-[#8BAA82] mb-2">
              <CheckCircle2 className="w-5 h-5" strokeWidth={1.5} />
              <span>Improved version ready</span>
            </div>
            <p className="text-sm text-[#1C1C1C]/70">
              The rewrite below matches your writing style and addresses all rubric criteria.
            </p>
          </div>
        )}

        {/* In-text citation optimization summary */}
        {showImprovedVersion && (
          <YooniCard className="mb-8">
            <div className="flex items-start gap-3 mb-4">
              <Quote className="w-5 h-5 text-[#AEC8A6] mt-0.5" strokeWidth={1.5} />
              <div className="flex-1">
                <h3 className="text-[#1C1C1C] mb-2">In-Text Citations Added</h3>
                <p className="text-sm text-[#1C1C1C]/60 mb-4">
                  Citations have been optimized and integrated into the text (highlighted in green)
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-[#F5F5F2] rounded-lg">
                <div className="text-sm text-[#1C1C1C]/60 mb-1">Original</div>
                <div className="text-2xl text-[#1C1C1C]">0 citations</div>
              </div>
              <div className="p-3 bg-[#AEC8A6]/10 rounded-lg border border-[#AEC8A6]/30">
                <div className="text-sm text-[#1C1C1C]/60 mb-1">Improved</div>
                <div className="text-2xl text-[#8BAA82]">2 citations</div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-[#D7D7D2]">
              <div className="text-sm text-[#1C1C1C]/60 mb-2">Added citations:</div>
              <ul className="space-y-1">
                <li className="text-sm text-[#1C1C1C]/70">• van Inwagen (1983) — Paragraph 2</li>
                <li className="text-sm text-[#1C1C1C]/70">• Frankfurt (1969) — Paragraph 2</li>
              </ul>
            </div>
          </YooniCard>
        )}

        {/* Full assignment text */}
        <YooniCard className="mb-8">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-[#1C1C1C]">
              {showImprovedVersion ? 'Improved Version' : 'Your Essay'}
            </h3>
            {showImprovedVersion && (
              <div className="flex items-center gap-2 text-sm text-[#1C1C1C]/60">
                <div className="w-3 h-3 rounded bg-[#AEC8A6]/20 border-b-2 border-[#AEC8A6]/40" />
                <span>Citations highlighted</span>
              </div>
            )}
          </div>
          <div className="p-4 bg-[#F5F5F2] rounded-lg">
            <EssayTextWithCitations
              text={showImprovedVersion ? improvedEssay : originalEssay}
              highlightCitations={showImprovedVersion}
            />
          </div>
        </YooniCard>

        {/* Suggested papers from research library */}
        <YooniCard className="mb-8">
          <div className="flex items-start gap-3 mb-6">
            <BookOpen className="w-5 h-5 text-[#AEC8A6] mt-0.5" strokeWidth={1.5} />
            <div className="flex-1">
              <h3 className="text-[#1C1C1C] mb-2">Suggested Papers from Your Library</h3>
              <p className="text-sm text-[#1C1C1C]/60">
                Papers from your research library that could strengthen this essay
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {suggestedPapers.map((paper, index) => (
              <div key={index} className="p-4 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]">
                <div className="mb-3">
                  <div className="text-[#1C1C1C] mb-1">{paper.title}</div>
                  <div className="text-sm text-[#1C1C1C]/60">
                    {paper.authors} ({paper.year})
                  </div>
                </div>
                <div className="mb-3">
                  <div className="text-sm text-[#1C1C1C]/60 mb-1">Why it's relevant:</div>
                  <div className="text-sm text-[#1C1C1C]/70">{paper.relevance}</div>
                </div>
                <div className="mb-3">
                  <div className="text-sm text-[#1C1C1C]/60 mb-1">Where to use it:</div>
                  <div className="text-sm text-[#1C1C1C]/70">{paper.whereToUse}</div>
                </div>
                
                {/* Citation formats */}
                <div className="pt-3 border-t border-[#D7D7D2]">
                  <div className="text-sm text-[#1C1C1C]/60 mb-2">Quick citation:</div>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <div className="text-xs text-[#1C1C1C]/50 w-12">APA</div>
                      <div className="flex-1 text-sm text-[#1C1C1C]/70 font-mono bg-white p-2 rounded">
                        {paper.authors} ({paper.year}). {paper.title}.
                      </div>
                      <button
                        onClick={() => handleCopyCitation(`${paper.authors} (${paper.year}). ${paper.title}.`)}
                        className="p-2 hover:bg-[#D7D7D2]/30 rounded transition-colors"
                      >
                        {copiedCitation === `${paper.authors} (${paper.year}). ${paper.title}.` ? (
                          <CheckCircle2 className="w-4 h-4 text-[#AEC8A6]" strokeWidth={1.5} />
                        ) : (
                          <Copy className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </YooniCard>

        {/* Section-by-section breakdown */}
        <YooniCard className="mb-8">
          <div className="mb-6">
            <h3 className="text-[#1C1C1C] mb-2">Section-by-Section Analysis</h3>
            <p className="text-sm text-[#1C1C1C]/60">
              Detailed breakdown with specific feedback for each part
            </p>
          </div>

          <div className="space-y-4">
            {sectionScores.map((section, index) => (
              <div key={index} className="p-4 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-[#1C1C1C]">{section.name}</h4>
                  <div className="flex items-center gap-3">
                    <ScoreChip
                      label="Current"
                      score={section.score}
                      maxScore={section.maxScore}
                    />
                    {showImprovedVersion && (
                      <>
                        <span className="text-[#1C1C1C]/40">→</span>
                        <ScoreChip
                          label="Improved"
                          score={section.improvedScore}
                          maxScore={section.maxScore}
                        />
                      </>
                    )}
                  </div>
                </div>

                <div className="mb-3">
                  <div className="text-sm text-[#1C1C1C]/60 mb-1">Feedback:</div>
                  <div className="text-sm text-[#1C1C1C]/70">{section.feedback}</div>
                </div>

                {showImprovedVersion && (
                  <div className="pt-3 border-t border-[#D7D7D2]">
                    <div className="text-sm text-[#1C1C1C]/60 mb-1">What was improved:</div>
                    <div className="text-sm text-[#AEC8A6]">{section.improvementNote}</div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </YooniCard>
      </div>
    </div>
  );
}