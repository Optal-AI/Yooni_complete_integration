import React, { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { YooniCard } from '../YooniCard';
import { StatusTag } from '../StatusTag';
import { 
  User, 
  BookOpen, 
  FileText, 
  Bell, 
  Palette, 
  Languages,
  Shield,
  Download,
  ChevronRight
} from 'lucide-react';

export function SettingsPage() {
  const [settings, setSettings] = useState({
    // Research Settings
    autoAnalyzePapers: true,
    citationFormat: 'APA',
    highlightKeyFindings: true,
    generateSummaries: true,
    
    // Writing Settings
    preserveWritingStyle: true,
    grammarChecking: true,
    styleConsistency: true,
    wordCountGoal: 2000,
    
    // Notifications
    dailyDigest: true,
    researchAlerts: true,
    writingReminders: true,
    
    // Appearance
    compactMode: false,
    fontSize: 'medium',
  });

  const toggleSetting = (key: string) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const citationFormats = ['APA', 'MLA', 'Chicago', 'Harvard', 'IEEE', 'Vancouver'];

  return (
    <div>
      <PageHeader 
        title="Settings" 
        subtitle="Customize your research and writing experience."
      />

      <div className="grid grid-cols-12 gap-6">
        {/* Profile Section */}
        <div className="col-span-12 lg:col-span-4">
          <YooniCard>
            <div className="text-center mb-6">
              <div className="w-20 h-20 rounded-full bg-[#AEC8A6]/20 flex items-center justify-center mx-auto mb-4">
                <User className="w-10 h-10 text-[#8BAA82]" strokeWidth={1.5} />
              </div>
              <h3 className="text-[18px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
                Sarah Chen
              </h3>
              <p className="text-[14px] text-[#1C1C1C]/60 mb-4">
                sarah.chen@university.edu
              </p>
              <div className="flex items-center justify-center gap-2">
                <StatusTag label="Pro Plan" variant="priority" />
              </div>
            </div>
            
            <div className="border-t border-[#D7D7D2] pt-4">
              <button className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-[#F5F5F2] transition-colors text-left">
                <span className="text-[14px] text-[#1C1C1C]">Manage Account</span>
                <ChevronRight className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
              </button>
              <button className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-[#F5F5F2] transition-colors text-left">
                <span className="text-[14px] text-[#1C1C1C]">Subscription</span>
                <ChevronRight className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
              </button>
              <button className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-[#F5F5F2] transition-colors text-left">
                <span className="text-[14px] text-[#1C1C1C]">Privacy & Data</span>
                <ChevronRight className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
              </button>
            </div>
          </YooniCard>

          {/* Usage Stats */}
          <YooniCard className="mt-6">
            <h3 className="text-xs uppercase tracking-wide text-[#1C1C1C]/60 mb-4" style={{ fontWeight: 600 }}>
              This Month
            </h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[14px] text-[#1C1C1C]/60">Papers Analyzed</span>
                <span className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>24</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[14px] text-[#1C1C1C]/60">Words Written</span>
                <span className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>12,847</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[14px] text-[#1C1C1C]/60">Citations Generated</span>
                <span className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>186</span>
              </div>
            </div>
          </YooniCard>
        </div>

        {/* Settings Panels */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
          
          {/* Research Settings */}
          <YooniCard>
            <div className="flex items-center gap-3 mb-6">
              <BookOpen className="w-5 h-5 text-[#AEC8A6]" strokeWidth={1.5} />
              <div>
                <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Research Analysis
                </h3>
                <p className="text-[13px] text-[#1C1C1C]/50">
                  Configure how papers are analyzed
                </p>
              </div>
            </div>

            <div className="space-y-0">
              <SettingRow
                label="Auto-analyze uploaded papers"
                description="Automatically extract key findings and summaries"
                enabled={settings.autoAnalyzePapers}
                onToggle={() => toggleSetting('autoAnalyzePapers')}
              />
              <SettingRow
                label="Highlight key findings"
                description="Emphasize important results and conclusions"
                enabled={settings.highlightKeyFindings}
                onToggle={() => toggleSetting('highlightKeyFindings')}
              />
              <SettingRow
                label="Generate summaries"
                description="Create concise summaries for each paper"
                enabled={settings.generateSummaries}
                onToggle={() => toggleSetting('generateSummaries')}
                isLast
              />
            </div>

            <div className="mt-6 pt-6 border-t border-[#D7D7D2]">
              <label className="block mb-3">
                <span className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Citation Format
                </span>
                <p className="text-[13px] text-[#1C1C1C]/50 mt-1 mb-3">
                  Default format for citations and references
                </p>
              </label>
              <div className="flex flex-wrap gap-2">
                {citationFormats.map(format => (
                  <button
                    key={format}
                    onClick={() => setSettings(prev => ({ ...prev, citationFormat: format }))}
                    className={`px-4 py-2 rounded-lg border transition-colors ${
                      settings.citationFormat === format
                        ? 'bg-[#AEC8A6]/15 border-[#AEC8A6] text-[#8BAA82]'
                        : 'border-[#D7D7D2] text-[#1C1C1C]/60 hover:bg-[#F5F5F2]'
                    }`}
                  >
                    <span className="text-[14px]">{format}</span>
                  </button>
                ))}
              </div>
            </div>
          </YooniCard>

          {/* Writing Settings */}
          <YooniCard>
            <div className="flex items-center gap-3 mb-6">
              <FileText className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
              <div>
                <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Writing Assistance
                </h3>
                <p className="text-[13px] text-[#1C1C1C]/50">
                  Customize your writing support preferences
                </p>
              </div>
            </div>

            <div className="space-y-0">
              <SettingRow
                label="Preserve writing style"
                description="Maintain your unique voice in all suggestions"
                enabled={settings.preserveWritingStyle}
                onToggle={() => toggleSetting('preserveWritingStyle')}
              />
              <SettingRow
                label="Grammar & spelling"
                description="Check for grammatical errors and typos"
                enabled={settings.grammarChecking}
                onToggle={() => toggleSetting('grammarChecking')}
              />
              <SettingRow
                label="Style consistency"
                description="Ensure consistent tone and terminology"
                enabled={settings.styleConsistency}
                onToggle={() => toggleSetting('styleConsistency')}
                isLast
              />
            </div>

            <div className="mt-6 pt-6 border-t border-[#D7D7D2]">
              <label className="block mb-3">
                <span className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Daily Word Count Goal
                </span>
                <p className="text-[13px] text-[#1C1C1C]/50 mt-1">
                  Target words per day
                </p>
              </label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="500"
                  max="5000"
                  step="100"
                  value={settings.wordCountGoal}
                  onChange={(e) => setSettings(prev => ({ ...prev, wordCountGoal: parseInt(e.target.value) }))}
                  className="flex-1 h-2 bg-[#D7D7D2] rounded-lg appearance-none cursor-pointer"
                  style={{
                    background: `linear-gradient(to right, #AEC8A6 0%, #AEC8A6 ${((settings.wordCountGoal - 500) / 4500) * 100}%, #D7D7D2 ${((settings.wordCountGoal - 500) / 4500) * 100}%, #D7D7D2 100%)`
                  }}
                />
                <div className="text-[16px] text-[#1C1C1C] min-w-[80px] text-right" style={{ fontWeight: 500 }}>
                  {settings.wordCountGoal} words
                </div>
              </div>
            </div>
          </YooniCard>

          {/* Notifications */}
          <YooniCard>
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-5 h-5 text-[#AEC8A6]" strokeWidth={1.5} />
              <div>
                <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Notifications
                </h3>
                <p className="text-[13px] text-[#1C1C1C]/50">
                  Manage how you receive updates
                </p>
              </div>
            </div>

            <div className="space-y-0">
              <SettingRow
                label="Daily digest"
                description="Summary of activity and progress each morning"
                enabled={settings.dailyDigest}
                onToggle={() => toggleSetting('dailyDigest')}
              />
              <SettingRow
                label="Research alerts"
                description="New papers matching your interests"
                enabled={settings.researchAlerts}
                onToggle={() => toggleSetting('researchAlerts')}
              />
              <SettingRow
                label="Writing reminders"
                description="Gentle nudges to meet your daily goals"
                enabled={settings.writingReminders}
                onToggle={() => toggleSetting('writingReminders')}
                isLast
              />
            </div>
          </YooniCard>

          {/* Appearance */}
          <YooniCard>
            <div className="flex items-center gap-3 mb-6">
              <Palette className="w-5 h-5 text-[#8BAA82]" strokeWidth={1.5} />
              <div>
                <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Appearance
                </h3>
                <p className="text-[13px] text-[#1C1C1C]/50">
                  Customize the interface
                </p>
              </div>
            </div>

            <div className="space-y-0">
              <SettingRow
                label="Compact mode"
                description="Reduce spacing for more content on screen"
                enabled={settings.compactMode}
                onToggle={() => toggleSetting('compactMode')}
                isLast
              />
            </div>

            <div className="mt-6 pt-6 border-t border-[#D7D7D2]">
              <label className="block mb-3">
                <span className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Font Size
                </span>
              </label>
              <div className="flex gap-2">
                {['small', 'medium', 'large'].map(size => (
                  <button
                    key={size}
                    onClick={() => setSettings(prev => ({ ...prev, fontSize: size }))}
                    className={`flex-1 px-4 py-2.5 rounded-lg border transition-colors ${
                      settings.fontSize === size
                        ? 'bg-[#AEC8A6]/15 border-[#AEC8A6] text-[#8BAA82]'
                        : 'border-[#D7D7D2] text-[#1C1C1C]/60 hover:bg-[#F5F5F2]'
                    }`}
                  >
                    <span className="text-[14px] capitalize">{size}</span>
                  </button>
                ))}
              </div>
            </div>
          </YooniCard>

          {/* Data & Privacy */}
          <YooniCard>
            <div className="flex items-center gap-3 mb-6">
              <Shield className="w-5 h-5 text-[#AEC8A6]" strokeWidth={1.5} />
              <div>
                <h3 className="text-[16px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                  Data & Privacy
                </h3>
                <p className="text-[13px] text-[#1C1C1C]/50">
                  Manage your data and exports
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <button className="w-full flex items-center justify-between px-4 py-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left">
                <div className="flex items-center gap-3">
                  <Download className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                  <div>
                    <div className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                      Export all data
                    </div>
                    <div className="text-[13px] text-[#1C1C1C]/50">
                      Download papers, notes, and writing
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
              </button>

              <button className="w-full flex items-center justify-between px-4 py-3 rounded-lg border border-[#D7D7D2] hover:bg-[#F5F5F2] transition-colors text-left">
                <div className="flex items-center gap-3">
                  <Shield className="w-4 h-4 text-[#1C1C1C]/50" strokeWidth={1.5} />
                  <div>
                    <div className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
                      Privacy settings
                    </div>
                    <div className="text-[13px] text-[#1C1C1C]/50">
                      Control how your data is used
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-[#1C1C1C]/40" strokeWidth={1.5} />
              </button>
            </div>
          </YooniCard>
        </div>
      </div>
    </div>
  );
}

// Helper Component
function SettingRow({ 
  label, 
  description, 
  enabled, 
  onToggle,
  isLast = false 
}: { 
  label: string; 
  description: string; 
  enabled: boolean; 
  onToggle: () => void;
  isLast?: boolean;
}) {
  return (
    <div className={`py-5 flex items-center justify-between ${!isLast ? 'border-b border-[#D7D7D2]' : ''}`}>
      <div className="flex-1 mr-8">
        <h4 className="text-[14px] text-[#1C1C1C] mb-1" style={{ fontWeight: 500 }}>
          {label}
        </h4>
        <p className="text-[13px] text-[#1C1C1C]/60">{description}</p>
      </div>
      <label className="relative inline-flex items-center cursor-pointer">
        <input
          type="checkbox"
          className="sr-only peer"
          checked={enabled}
          onChange={onToggle}
        />
        <div className="w-11 h-6 bg-[#D7D7D2] peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-[#AEC8A6]/30 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#AEC8A6] transition-colors"></div>
      </label>
    </div>
  );
}