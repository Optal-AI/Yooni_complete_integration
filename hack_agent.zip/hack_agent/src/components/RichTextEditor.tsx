import React, { useRef, useEffect } from 'react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  onFocus?: () => void;
  onBlur?: () => void;
}

export const RichTextEditor = React.forwardRef<HTMLDivElement, RichTextEditorProps>(
  function RichTextEditor({ value, onChange, placeholder, className = '', onFocus, onBlur }, ref) {
    const editorRef = useRef<HTMLDivElement>(null);
    const actualRef = (ref as React.RefObject<HTMLDivElement>) || editorRef;

    useEffect(() => {
      if (actualRef.current && actualRef.current.innerHTML !== value) {
        actualRef.current.innerHTML = value;
      }
    }, [value]);

    const handleInput = () => {
      if (actualRef.current) {
        onChange(actualRef.current.innerHTML);
      }
    };

    const handlePaste = (e: React.ClipboardEvent) => {
      e.preventDefault();
      const text = e.clipboardData.getData('text/plain');
      document.execCommand('insertText', false, text);
    };

    return (
      <div className="relative">
        <div
          ref={actualRef}
          contentEditable
          onInput={handleInput}
          onPaste={handlePaste}
          onFocus={onFocus}
          onBlur={onBlur}
          className={`w-full px-4 py-3 bg-white border border-[#D7D7D2] rounded-lg text-[#1C1C1C] focus:outline-none focus:ring-1 focus:ring-[#AEC8A6] transition-shadow overflow-auto ${className}`}
          style={{
            fontFamily: "'Inter Tight', sans-serif",
            lineHeight: '2',
            minHeight: '500px',
            maxHeight: '70vh'
          }}
          data-placeholder={placeholder}
        />
        {!value && placeholder && (
          <div 
            className="absolute top-3 left-4 text-[#1C1C1C]/40 pointer-events-none"
            style={{ fontFamily: "'Inter Tight', sans-serif" }}
          >
            {placeholder}
          </div>
        )}
        <style>{`
          [contenteditable]:empty:before {
            content: attr(data-placeholder);
            color: rgba(28, 28, 28, 0.4);
            pointer-events: none;
            position: absolute;
          }
          [contenteditable]:focus:before {
            content: '';
          }
        `}</style>
      </div>
    );
  }
);
