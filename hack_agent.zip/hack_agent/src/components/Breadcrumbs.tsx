import React from 'react';
import { ChevronRight } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export function Breadcrumbs({ items }: BreadcrumbsProps) {
  return (
    <div className="flex items-center gap-2 text-[13px] mb-6">
      {items.map((item, index) => (
        <React.Fragment key={index}>
          {index > 0 && (
            <ChevronRight className="w-4 h-4 text-[#1C1C1C]/30" strokeWidth={1.5} />
          )}
          {item.onClick ? (
            <button
              onClick={item.onClick}
              className="text-[#1C1C1C]/60 hover:text-[#8BAA82] transition-colors"
            >
              {item.label}
            </button>
          ) : (
            <span className="text-[#1C1C1C]">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}
