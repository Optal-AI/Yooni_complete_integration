import React from 'react';

interface YooniCardProps {
  children: React.ReactNode;
  className?: string;
  topAccent?: boolean;
  hover?: boolean;
}

export function YooniCard({ children, className = '', topAccent = false, hover = false }: YooniCardProps) {
  return (
    <div
      className={`bg-white border border-[#D7D7D2] rounded-lg p-6 transition-shadow duration-150 ${
        topAccent ? 'border-t-2 border-t-[#AEC8A6]' : ''
      } ${hover ? 'hover:shadow-[0_4px_8px_rgba(0,0,0,0.06)]' : ''} ${className}`}
      style={{
        boxShadow: '0 2px 5px rgba(0, 0, 0, 0.04)',
      }}
    >
      {children}
    </div>
  );
}