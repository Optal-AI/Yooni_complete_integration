import React, { useState } from 'react';
import { YooniCard } from './YooniCard';
import { YooniButton } from './YooniButton';
import { YooniInput } from './YooniInput';
import { BibliographyGenerator } from './BibliographyGenerator';
import { 
  BookOpen, 
  Plus, 
  X,
  Quote,
  Search,
  Copy,
  Check
} from 'lucide-react';

interface Citation {
  id: string;
  authors: string;
  year: string;
  title: string;
  source: string;
  pages?: string;
  doi?: string;
  url?: string;
}

interface CitationManagerProps {
  citationStyle: 'APA' | 'MLA' | 'Chicago' | 'Harvard';
  onInsertCitation: (citation: Citation, inTextFormat: string) => void;
}

export function CitationManager({ citationStyle, onInsertCitation }: CitationManagerProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showBibliography, setShowBibliography] = useState(false);

  const [citations, setCitations] = useState<Citation[]>([
    {
      id: '1',
      authors: 'van Inwagen, P.',
      year: '1983',
      title: 'An Essay on Free Will',
      source: 'Oxford University Press',
      pages: '55-82'
    },
    {
      id: '2',
      authors: 'Dennett, D. C.',
      year: '2003',
      title: 'Freedom Evolves',
      source: 'Viking Press',
      pages: '101-125'
    },
    {
      id: '3',
      authors: 'Frankfurt, H. G.',
      year: '1971',
      title: 'Freedom of the Will and the Concept of a Person',
      source: 'The Journal of Philosophy',
      pages: '5-20',
      doi: '10.2307/2024717'
    }
  ]);

  const formatInTextCitation = (citation: Citation): string => {
    switch (citationStyle) {
      case 'APA':
        return `(${citation.authors.split(',')[0].trim()}, ${citation.year})`;
      case 'MLA':
        return `(${citation.authors.split(',')[0].trim()} ${citation.pages ? citation.pages.split('-')[0] : ''})`.trim();
      case 'Chicago':
        return `(${citation.authors.split(',')[0].trim()} ${citation.year})`;
      case 'Harvard':
        return `(${citation.authors.split(',')[0].trim()} ${citation.year})`;
      default:
        return `(${citation.authors.split(',')[0].trim()}, ${citation.year})`;
    }
  };

  const formatFullCitation = (citation: Citation): string => {
    switch (citationStyle) {
      case 'APA':
        return `${citation.authors} (${citation.year}). ${citation.title}. ${citation.source}${citation.pages ? `, ${citation.pages}` : ''}${citation.doi ? `. https://doi.org/${citation.doi}` : ''}`;
      case 'MLA':
        return `${citation.authors} "${citation.title}." ${citation.source}, ${citation.year}${citation.pages ? `, pp. ${citation.pages}` : ''}.`;
      case 'Chicago':
        return `${citation.authors} ${citation.title}. ${citation.source}, ${citation.year}${citation.pages ? `, ${citation.pages}` : ''}.`;
      case 'Harvard':
        return `${citation.authors} ${citation.year}. ${citation.title}. ${citation.source}${citation.pages ? `, pp. ${citation.pages}` : ''}.`;
      default:
        return `${citation.authors} (${citation.year}). ${citation.title}. ${citation.source}.`;
    }
  };

  const handleCopyCitation = (citation: Citation) => {
    const inTextFormat = formatInTextCitation(citation);
    navigator.clipboard.writeText(inTextFormat);
    setCopiedId(citation.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleInsertCitation = (citation: Citation) => {
    const inTextFormat = formatInTextCitation(citation);
    onInsertCitation(citation, inTextFormat);
  };

  const filteredCitations = citations.filter(c => 
    c.authors.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.year.includes(searchQuery)
  );

  return (
    <YooniCard>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-[#AEC8A6]" strokeWidth={1.5} />
          <h3 className="text-[#1C1C1C]" style={{ fontWeight: 500 }}>
            Citations
          </h3>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="text-[#AEC8A6] hover:text-[#8BAA82]"
        >
          {showAddForm ? (
            <X className="w-5 h-5" strokeWidth={1.5} />
          ) : (
            <Plus className="w-5 h-5" strokeWidth={1.5} />
          )}
        </button>
      </div>

      {/* Search */}
      {citations.length > 0 && (
        <div className="mb-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#1C1C1C]/40" strokeWidth={1.5} />
            <YooniInput
              placeholder="Search citations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 text-[14px]"
            />
          </div>
        </div>
      )}

      {/* Add Citation Form */}
      {showAddForm && (
        <div className="mb-4 p-4 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2] space-y-3">
          <div className="text-sm text-[#1C1C1C]" style={{ fontWeight: 500 }}>
            Add New Citation
          </div>
          <YooniInput placeholder="Authors (Last, F. M.)" className="text-[14px]" />
          <YooniInput placeholder="Year" className="text-[14px]" />
          <YooniInput placeholder="Title" className="text-[14px]" />
          <YooniInput placeholder="Source/Journal" className="text-[14px]" />
          <YooniInput placeholder="Pages (optional)" className="text-[14px]" />
          <YooniInput placeholder="DOI or URL (optional)" className="text-[14px]" />
          <div className="flex gap-2">
            <YooniButton variant="primary" className="flex-1">
              Add Citation
            </YooniButton>
            <YooniButton variant="secondary" onClick={() => setShowAddForm(false)}>
              Cancel
            </YooniButton>
          </div>
        </div>
      )}

      {/* Citation List */}
      {filteredCitations.length === 0 ? (
        <div className="text-center py-8 text-[#1C1C1C]/40">
          <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-40" strokeWidth={1.5} />
          <p className="text-sm">
            {searchQuery ? 'No citations found' : 'No citations yet'}
          </p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[400px] overflow-y-auto">
          {filteredCitations.map((citation) => (
            <div
              key={citation.id}
              className="p-3 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2] hover:border-[#AEC8A6] transition-colors"
            >
              {/* In-text format */}
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 flex-1">
                  <Quote className="w-4 h-4 text-[#AEC8A6] flex-shrink-0" strokeWidth={1.5} />
                  <code className="text-[13px] text-[#1C1C1C] bg-white px-2 py-1 rounded border border-[#D7D7D2]">
                    {formatInTextCitation(citation)}
                  </code>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleCopyCitation(citation)}
                    className="p-1.5 hover:bg-white rounded transition-colors"
                    title="Copy in-text citation"
                  >
                    {copiedId === citation.id ? (
                      <Check className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
                    ) : (
                      <Copy className="w-4 h-4 text-[#1C1C1C]/60" strokeWidth={1.5} />
                    )}
                  </button>
                </div>
              </div>

              {/* Full citation */}
              <div className="text-[12px] text-[#1C1C1C]/70 leading-relaxed mb-3 pl-6">
                {formatFullCitation(citation)}
              </div>

              {/* Actions */}
              <div className="flex gap-2 pl-6">
                <button
                  onClick={() => handleInsertCitation(citation)}
                  className="text-[12px] text-[#AEC8A6] hover:text-[#8BAA82] transition-colors"
                  style={{ fontWeight: 500 }}
                >
                  Insert at cursor
                </button>
                <button className="text-[12px] text-[#1C1C1C]/40 hover:text-[#1C1C1C]/60 transition-colors">
                  Edit
                </button>
                <button className="text-[12px] text-[#1C1C1C]/40 hover:text-red-600 transition-colors">
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Bibliography preview */}
      {citations.length > 0 && (
        <div className="mt-4 pt-4 border-t border-[#D7D7D2]">
          <button 
            onClick={() => setShowBibliography(true)}
            className="text-[13px] text-[#AEC8A6] hover:text-[#8BAA82] transition-colors w-full text-left"
          >
            Generate {citationStyle === 'MLA' ? 'Works Cited' : citationStyle === 'Chicago' ? 'Bibliography' : 'References'} →
          </button>
        </div>
      )}

      {/* Bibliography Modal */}
      {showBibliography && (
        <BibliographyGenerator
          citations={citations}
          citationStyle={citationStyle}
          onClose={() => setShowBibliography(false)}
        />
      )}
    </YooniCard>
  );
}