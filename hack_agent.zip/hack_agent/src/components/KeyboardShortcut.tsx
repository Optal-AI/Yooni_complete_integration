import React, { useEffect } from 'react';

interface KeyboardShortcutProps {
  keys: string[];
  onTrigger: () => void;
  disabled?: boolean;
}

export function KeyboardShortcut({ keys, onTrigger, disabled = false }: KeyboardShortcutProps) {
  useEffect(() => {
    if (disabled) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const modKey = isMac ? e.metaKey : e.ctrlKey;

      // Check if the key combination matches
      const keyMatch = keys.every(key => {
        if (key === 'mod') return modKey;
        if (key === 'shift') return e.shiftKey;
        if (key === 'alt') return e.altKey;
        return e.key.toLowerCase() === key.toLowerCase();
      });

      if (keyMatch) {
        e.preventDefault();
        onTrigger();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [keys, onTrigger, disabled]);

  return null;
}

export function KeyboardShortcutBadge({ keys }: { keys: string[] }) {
  const isMac = typeof navigator !== 'undefined' && navigator.platform.toUpperCase().indexOf('MAC') >= 0;
  
  const displayKeys = keys.map(key => {
    if (key === 'mod') return isMac ? '⌘' : 'Ctrl';
    if (key === 'shift') return '⇧';
    if (key === 'alt') return isMac ? '⌥' : 'Alt';
    return key.toUpperCase();
  });

  return (
    <div className="flex items-center gap-1">
      {displayKeys.map((key, index) => (
        <React.Fragment key={index}>
          {index > 0 && <span className="text-[#1C1C1C]/30 text-[11px]">+</span>}
          <kbd className="px-1.5 py-0.5 text-[11px] bg-[#D7D7D2]/40 text-[#1C1C1C]/70 rounded border border-[#D7D7D2]">
            {key}
          </kbd>
        </React.Fragment>
      ))}
    </div>
  );
}
