import React from 'react';

interface YooniInputProps {
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  className?: string;
}

export function YooniInput({ placeholder, value, onChange, className = '' }: YooniInputProps) {
  return (
    <input
      type="text"
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      className={`w-full px-4 py-3 bg-[#F5F5F2] border border-[#D7D7D2] rounded-lg text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:ring-1 focus:ring-[#AEC8A6] transition-shadow ${className}`}
    />
  );
}
