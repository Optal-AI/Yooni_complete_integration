import React from 'react';

interface ScoreChipProps {
  label: string;
  score: number;
  maxScore: number;
  onClick?: () => void;
}

export function ScoreChip({ label, score, maxScore, onClick }: ScoreChipProps) {
  return (
    <button
      onClick={onClick}
      className="border border-[#AEC8A6] rounded-lg px-4 py-3 text-left hover:bg-[#AEC8A6]/10 transition-colors"
    >
      <div className="text-sm text-[#1C1C1C]/60 mb-1">{label}</div>
      <div className="text-[#1C1C1C]">
        {score} / {maxScore}
      </div>
    </button>
  );
}
