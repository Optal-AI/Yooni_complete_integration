import React, { useState } from 'react';
import {
  Home,
  FileText,
  FlaskConical,
  BookOpen,
  Settings,
  User,
  ChevronRight,
  HelpCircle,
  LogOut,
  UserCircle,
  Search,
} from 'lucide-react';

interface YooniSidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const tabs = [
  { id: 'today', label: 'Dashboard', icon: Home },
  { id: 'research-match', label: 'Research Match', icon: FlaskConical },
  { id: 'search-papers', label: 'Search Papers', icon: Search },
  { id: 'writing', label: 'Writing Projects', icon: FileText },
  { id: 'library', label: 'Library', icon: BookOpen },
];

export function YooniSidebar({ activeTab, onTabChange }: YooniSidebarProps) {
  const [showAccountMenu, setShowAccountMenu] = useState(false);

  return (
    <aside className="w-56 bg-white border-r border-[#D7D7D2] h-screen flex flex-col sticky top-0">
      {/* Logo / Brand */}
      <div className="px-6 pt-6 pb-5 border-b border-[#D7D7D2]">
        <div className="flex items-center gap-3 mb-2.5">
          {/* Sprout Icon in Circle */}
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="20" cy="20" r="19.5" stroke="#AEC8A6" strokeWidth="1.5"/>
            {/* Simple sprout with two leaves */}
            {/* Left leaf */}
            <path 
              d="M20 24C20 24 16 22 14 18C13 16 13.5 14 14.5 13.5C15.5 13 17 13.5 18 15C19 16.5 19.5 18.5 20 20.5"
              fill="#AEC8A6"
              stroke="#AEC8A6"
              strokeWidth="1"
              strokeLinejoin="round"
            />
            {/* Right leaf */}
            <path 
              d="M20 24C20 24 24 22 26 18C27 16 26.5 14 25.5 13.5C24.5 13 23 13.5 22 15C21 16.5 20.5 18.5 20 20.5"
              fill="#AEC8A6"
              stroke="#AEC8A6"
              strokeWidth="1"
              strokeLinejoin="round"
            />
            {/* Stem */}
            <path 
              d="M20 20.5L20 27" 
              stroke="#8BAA82" 
              strokeWidth="1.5"
              strokeLinecap="round"
            />
          </svg>
          
          {/* Yooni Wordmark */}
          <div>
            <span className="text-[32px] text-[#8B9E83] tracking-wide" style={{ fontFamily: 'Inter Tight', fontWeight: 600, letterSpacing: '0.02em' }}>
              yooni
            </span>
          </div>
        </div>
        <p className="text-[11px] text-[#1C1C1C]/40">Research & Writing</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 px-4">
        <ul className="space-y-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <li key={tab.id}>
                <button
                  onClick={() => onTabChange(tab.id)}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200
                    ${isActive 
                      ? 'bg-[#AEC8A6]/15 text-[#1C1C1C]' 
                      : 'text-[#1C1C1C]/50 hover:text-[#1C1C1C]/70 hover:bg-[#F5F5F2]'
                    }
                  `}
                >
                  <Icon 
                    className={isActive ? 'text-[#8BAA82]' : 'text-[#1C1C1C]/40'} 
                    strokeWidth={1.5}
                    size={22}
                  />
                  <span className="text-[15px]" style={{ fontWeight: isActive ? 500 : 400 }}>
                    {tab.label}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Account Button with Popup */}
      <div className="px-3 pb-4 border-t border-[#D7D7D2] pt-4 relative">
        <button 
          onClick={() => setShowAccountMenu(!showAccountMenu)}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-[#D7D7D2]/20 group"
        >
          <div className="w-8 h-8 rounded-full bg-[#AEC8A6]/20 flex items-center justify-center flex-shrink-0">
            <User className="w-4 h-4 text-[#8BAA82]" strokeWidth={1.5} />
          </div>
          <div className="flex-1 text-left">
            <div className="text-[14px] text-[#1C1C1C]" style={{ fontWeight: 500 }}>
              Sarah Chen
            </div>
            <div className="text-[12px] text-[#1C1C1C]/50">
              Pro
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-[#1C1C1C]/30 group-hover:text-[#1C1C1C]/60 transition-colors" strokeWidth={1.5} />
        </button>

        {/* Account Menu Popup */}
        {showAccountMenu && (
          <>
            {/* Backdrop */}
            <div 
              className="fixed inset-0 z-40" 
              onClick={() => setShowAccountMenu(false)}
            />
            
            {/* Menu */}
            <div className="absolute bottom-full left-3 right-3 mb-2 bg-white rounded-lg shadow-lg z-50 overflow-hidden border border-[#D7D7D2]">
              {/* Email Header */}
              <div className="px-4 py-3 border-b border-[#D7D7D2]">
                <div className="flex items-center gap-3">
                  <UserCircle className="w-5 h-5 text-[#1C1C1C]/40" strokeWidth={1.5} />
                  <span className="text-[14px] text-[#1C1C1C]/60">sarah.chen@university.edu</span>
                </div>
              </div>

              {/* Menu Items */}
              <div className="py-2">
                <button
                  onClick={() => {
                    onTabChange('settings');
                    setShowAccountMenu(false);
                  }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[#F5F5F2] transition-colors text-left"
                >
                  <Settings className="w-5 h-5 text-[#1C1C1C]/50" strokeWidth={1.5} />
                  <span className="text-[15px] text-[#1C1C1C]">Settings</span>
                </button>

                <button
                  className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-[#F5F5F2] transition-colors text-left"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 text-[#1C1C1C]/50" strokeWidth={1.5} />
                    <span className="text-[15px] text-[#1C1C1C]">Help</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#1C1C1C]/30" strokeWidth={1.5} />
                </button>
              </div>

              {/* Divider */}
              <div className="h-px bg-[#D7D7D2] mx-3" />

              {/* Log out */}
              <div className="py-2">
                <button
                  className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-[#F5F5F2] transition-colors text-left"
                >
                  <LogOut className="w-5 h-5 text-[#1C1C1C]/50" strokeWidth={1.5} />
                  <span className="text-[15px] text-[#1C1C1C]">Log out</span>
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </aside>
  );
}