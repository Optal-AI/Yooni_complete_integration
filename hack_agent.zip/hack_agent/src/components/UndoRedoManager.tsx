import { useEffect, useRef, useCallback } from 'react';

interface UndoRedoState {
  past: string[];
  present: string;
  future: string[];
}

export function useUndoRedo(initialValue: string) {
  const history = useRef<UndoRedoState>({
    past: [],
    present: initialValue,
    future: []
  });

  const lastSaveTime = useRef<number>(Date.now());

  const setValue = useCallback((newValue: string) => {
    const now = Date.now();
    const timeSinceLastSave = now - lastSaveTime.current;

    // Only save to history if enough time has passed (debounce)
    // or if the change is significant (more than 10 characters)
    const shouldSaveToHistory = 
      timeSinceLastSave > 500 || 
      Math.abs(newValue.length - history.current.present.length) > 10;

    if (shouldSaveToHistory && newValue !== history.current.present) {
      history.current = {
        past: [...history.current.past, history.current.present],
        present: newValue,
        future: []
      };
      lastSaveTime.current = now;
    } else {
      history.current.present = newValue;
    }

    return newValue;
  }, []);

  const undo = useCallback(() => {
    if (history.current.past.length === 0) return history.current.present;

    const previous = history.current.past[history.current.past.length - 1];
    const newPast = history.current.past.slice(0, history.current.past.length - 1);

    history.current = {
      past: newPast,
      present: previous,
      future: [history.current.present, ...history.current.future]
    };

    return history.current.present;
  }, []);

  const redo = useCallback(() => {
    if (history.current.future.length === 0) return history.current.present;

    const next = history.current.future[0];
    const newFuture = history.current.future.slice(1);

    history.current = {
      past: [...history.current.past, history.current.present],
      present: next,
      future: newFuture
    };

    return history.current.present;
  }, []);

  const canUndo = () => history.current.past.length > 0;
  const canRedo = () => history.current.future.length > 0;

  const reset = useCallback((newValue: string) => {
    history.current = {
      past: [],
      present: newValue,
      future: []
    };
  }, []);

  return {
    setValue,
    undo,
    redo,
    canUndo,
    canRedo,
    reset,
    getCurrentValue: () => history.current.present
  };
}
