import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { YooniButton } from './YooniButton';

interface ConfirmDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'danger' | 'warning' | 'info';
}

export function ConfirmDialog({
  isOpen,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'warning'
}: ConfirmDialogProps) {
  if (!isOpen) return null;

  const handleConfirm = () => {
    onConfirm();
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-[#1C1C1C]/40 z-50 animate-in fade-in duration-200"
        onClick={onClose}
      />
      
      {/* Dialog */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
        <div className="bg-white rounded-lg shadow-2xl max-w-md w-full pointer-events-auto animate-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="flex items-start gap-4 p-6 pb-4">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
              variant === 'danger' ? 'bg-red-50' : 'bg-[#AEC8A6]/10'
            }`}>
              <AlertTriangle 
                className={`w-5 h-5 ${variant === 'danger' ? 'text-red-500' : 'text-[#8BAA82]'}`} 
                strokeWidth={1.5} 
              />
            </div>
            <div className="flex-1">
              <h3 className="text-[18px] text-[#1C1C1C] mb-2" style={{ fontWeight: 500 }}>
                {title}
              </h3>
              <p className="text-[14px] text-[#1C1C1C]/70 leading-relaxed">
                {description}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-[#D7D7D2]/30 rounded transition-colors"
            >
              <X className="w-5 h-5 text-[#1C1C1C]/40" strokeWidth={1.5} />
            </button>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-3 px-6 pb-6">
            <YooniButton variant="secondary" onClick={onClose}>
              {cancelLabel}
            </YooniButton>
            <YooniButton 
              variant={variant === 'danger' ? 'primary' : 'primary'} 
              onClick={handleConfirm}
            >
              {confirmLabel}
            </YooniButton>
          </div>
        </div>
      </div>
    </>
  );
}
