import React from 'react';

interface LoadingSkeletonProps {
  variant?: 'text' | 'card' | 'avatar' | 'project' | 'paper';
  count?: number;
}

export function LoadingSkeleton({ variant = 'text', count = 1 }: LoadingSkeletonProps) {
  const renderSkeleton = () => {
    switch (variant) {
      case 'text':
        return (
          <div className="animate-pulse space-y-3">
            {Array.from({ length: count }).map((_, i) => (
              <div key={i} className="h-4 bg-[#D7D7D2]/40 rounded" style={{ width: `${Math.random() * 40 + 60}%` }} />
            ))}
          </div>
        );
      
      case 'card':
        return (
          <div className="animate-pulse space-y-4">
            {Array.from({ length: count }).map((_, i) => (
              <div key={i} className="bg-white rounded-lg border border-[#D7D7D2] p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-[#D7D7D2]/40 rounded-lg" />
                  <div className="flex-1 space-y-3">
                    <div className="h-5 bg-[#D7D7D2]/40 rounded w-3/4" />
                    <div className="h-4 bg-[#D7D7D2]/30 rounded w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      
      case 'avatar':
        return (
          <div className="animate-pulse flex items-center gap-3">
            <div className="w-10 h-10 bg-[#D7D7D2]/40 rounded-full" />
            <div className="space-y-2 flex-1">
              <div className="h-4 bg-[#D7D7D2]/40 rounded w-24" />
              <div className="h-3 bg-[#D7D7D2]/30 rounded w-32" />
            </div>
          </div>
        );
      
      case 'project':
        return (
          <div className="animate-pulse space-y-4">
            {Array.from({ length: count }).map((_, i) => (
              <div key={i} className="bg-white rounded-lg border border-[#D7D7D2] p-5">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1 space-y-3">
                    <div className="h-5 bg-[#D7D7D2]/40 rounded w-3/5" />
                    <div className="h-4 bg-[#D7D7D2]/30 rounded w-2/5" />
                  </div>
                  <div className="flex gap-2">
                    <div className="w-20 h-8 bg-[#D7D7D2]/40 rounded-lg" />
                    <div className="w-20 h-8 bg-[#D7D7D2]/40 rounded-lg" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <div className="w-16 h-6 bg-[#D7D7D2]/30 rounded" />
                  <div className="w-16 h-6 bg-[#D7D7D2]/30 rounded" />
                </div>
              </div>
            ))}
          </div>
        );
      
      case 'paper':
        return (
          <div className="animate-pulse space-y-4">
            {Array.from({ length: count }).map((_, i) => (
              <div key={i} className="py-5 border-b border-[#D7D7D2]">
                <div className="flex items-start gap-4">
                  <div className="w-5 h-5 bg-[#D7D7D2]/40 rounded flex-shrink-0" />
                  <div className="flex-1 space-y-3">
                    <div className="h-5 bg-[#D7D7D2]/40 rounded w-4/5" />
                    <div className="h-4 bg-[#D7D7D2]/30 rounded w-2/5" />
                    <div className="flex gap-2">
                      <div className="w-16 h-5 bg-[#D7D7D2]/30 rounded" />
                      <div className="w-16 h-5 bg-[#D7D7D2]/30 rounded" />
                      <div className="w-16 h-5 bg-[#D7D7D2]/30 rounded" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        );
      
      default:
        return null;
    }
  };

  return renderSkeleton();
}
