import React from 'react';

interface YooniTextareaProps {
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  rows?: number;
  className?: string;
  readOnly?: boolean;
}

export const YooniTextarea = React.forwardRef<HTMLTextAreaElement, YooniTextareaProps>(
  function YooniTextarea({
    placeholder,
    value,
    onChange,
    rows = 10,
    className = '',
    readOnly = false,
  }, ref) {
    return (
      <textarea
        ref={ref}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        rows={rows}
        readOnly={readOnly}
        className={`w-full px-4 py-3 bg-[#F5F5F2] border border-[#D7D7D2] rounded-lg text-[#1C1C1C] placeholder:text-[#1C1C1C]/40 focus:outline-none focus:ring-1 focus:ring-[#AEC8A6] transition-shadow resize-none ${className}`}
      />
    );
  }
);