import React from 'react';

interface PriorityDotProps {
  level: 'high' | 'medium' | 'low';
  animate?: boolean;
}

export function PriorityDot({ level, animate = false }: PriorityDotProps) {
  const colors = {
    high: 'bg-[#AEC8A6]',
    medium: 'bg-[#D7D7D2]',
    low: 'bg-[#D7D7D2]/50'
  };

  return (
    <div 
      className={`w-2 h-2 rounded-full ${colors[level]} ${animate ? 'animate-pulse' : ''}`}
      aria-label={`${level} priority`}
    />
  );
}
