import React from 'react';

interface EssayTextWithCitationsProps {
  text: string;
  highlightCitations?: boolean;
}

export function EssayTextWithCitations({ text, highlightCitations = false }: EssayTextWithCitationsProps) {
  // Regular expression to match in-text citations like (Author, Year) or (Author et al., Year)
  const citationRegex = /\(([A-Z][a-zA-Z\s]+(?:et al\.)?),?\s+(\d{4})\)/g;
  
  if (!highlightCitations) {
    return (
      <div className="prose prose-sm max-w-none">
        {text.split('\n\n').map((paragraph, index) => (
          <p key={index} className="mb-4 text-[#1C1C1C]/70 leading-relaxed">
            {paragraph}
          </p>
        ))}
      </div>
    );
  }

  // Split text into paragraphs
  const paragraphs = text.split('\n\n');

  return (
    <div className="prose prose-sm max-w-none">
      {paragraphs.map((paragraph, pIndex) => {
        const parts: React.ReactNode[] = [];
        let lastIndex = 0;
        let match;
        let citationCount = 0;

        // Reset regex
        citationRegex.lastIndex = 0;

        // Find all citations in the paragraph
        while ((match = citationRegex.exec(paragraph)) !== null) {
          citationCount++;
          
          // Add text before citation
          if (match.index > lastIndex) {
            parts.push(paragraph.slice(lastIndex, match.index));
          }

          // Add highlighted citation
          parts.push(
            <span
              key={`${pIndex}-${citationCount}`}
              className="bg-[#AEC8A6]/20 text-[#1C1C1C] px-1 rounded border-b-2 border-[#AEC8A6]/40"
              title="Added citation"
            >
              {match[0]}
            </span>
          );

          lastIndex = match.index + match[0].length;
        }

        // Add remaining text
        if (lastIndex < paragraph.length) {
          parts.push(paragraph.slice(lastIndex));
        }

        return (
          <p key={pIndex} className="mb-4 text-[#1C1C1C]/70 leading-relaxed">
            {parts.length > 0 ? parts : paragraph}
          </p>
        );
      })}
    </div>
  );
}
