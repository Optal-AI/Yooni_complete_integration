import React from 'react';

interface YooniButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'upload';
  className?: string;
  type?: 'button' | 'submit';
}

export function YooniButton({
  children,
  onClick,
  variant = 'primary',
  className = '',
  type = 'button',
}: YooniButtonProps) {
  const baseStyles = 'px-6 py-3 rounded-lg transition-all duration-200 inline-flex items-center justify-center whitespace-nowrap';

  const variantStyles = {
    primary:
      'bg-[#8BAA82] text-[#1C1C1C] hover:shadow-[0_0_12px_rgba(174,200,166,0.3)]',
    secondary: 'border border-[#AEC8A6] text-[#1C1C1C] bg-transparent hover:bg-[#AEC8A6]/10',
    upload: 'border border-[#AEC8A6] text-[#1C1C1C] bg-transparent hover:bg-[#AEC8A6]/10',
  };

  return (
    <button
      type={type}
      onClick={onClick}
      className={`${baseStyles} ${variantStyles[variant]} ${className}`}
    >
      {children}
    </button>
  );
}