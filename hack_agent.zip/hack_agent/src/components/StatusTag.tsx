import React from 'react';

interface StatusTagProps {
  label: string;
  variant?: 'priority' | 'due' | 'course' | 'status' | 'new';
  size?: 'sm' | 'md';
}

export function StatusTag({ label, variant = 'status', size = 'sm' }: StatusTagProps) {
  const variants = {
    priority: 'bg-[#AEC8A6]/20 text-[#8BAA82] border-[#AEC8A6]/30',
    due: 'bg-[#AEC8A6]/10 text-[#1C1C1C]/70 border-[#D7D7D2]',
    course: 'bg-[#F5F5F2] text-[#1C1C1C]/60 border-[#D7D7D2]',
    status: 'bg-[#D7D7D2]/30 text-[#1C1C1C]/70 border-[#D7D7D2]',
    new: 'bg-[#AEC8A6]/20 text-[#8BAA82] border-[#AEC8A6]/40'
  };

  const sizes = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm'
  };

  return (
    <span 
      className={`inline-flex items-center rounded border ${variants[variant]} ${sizes[size]} transition-colors`}
    >
      {label}
    </span>
  );
}
