import React from 'react';

interface PageHeaderProps {
  title: string;
  subtitle?: string;
}

export function PageHeader({ title, subtitle }: PageHeaderProps) {
  return (
    <div className="mb-10">
      <h1 className="text-[#1C1C1C] mb-2" style={{ fontSize: '26px', fontWeight: 500, letterSpacing: '-0.02em' }}>
        {title}
      </h1>
      {subtitle && (
        <p className="serif text-[#1C1C1C]/50" style={{ fontWeight: 300, fontSize: '17px' }}>
          {subtitle}
        </p>
      )}
    </div>
  );
}