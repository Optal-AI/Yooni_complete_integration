import React from 'react';
import { YooniCard } from './YooniCard';
import { YooniButton } from './YooniButton';
import { X, Copy, Check, Download } from 'lucide-react';

interface Citation {
  id: string;
  authors: string;
  year: string;
  title: string;
  source: string;
  pages?: string;
  doi?: string;
  url?: string;
}

interface BibliographyGeneratorProps {
  citations: Citation[];
  citationStyle: 'APA' | 'MLA' | 'Chicago' | 'Harvard';
  onClose: () => void;
}

export function BibliographyGenerator({ citations, citationStyle, onClose }: BibliographyGeneratorProps) {
  const [copied, setCopied] = React.useState(false);

  const formatFullCitation = (citation: Citation): string => {
    switch (citationStyle) {
      case 'APA':
        return `${citation.authors} (${citation.year}). ${citation.title}. ${citation.source}${citation.pages ? `, ${citation.pages}` : ''}${citation.doi ? `. https://doi.org/${citation.doi}` : ''}`;
      case 'MLA':
        return `${citation.authors} "${citation.title}." ${citation.source}, ${citation.year}${citation.pages ? `, pp. ${citation.pages}` : ''}.`;
      case 'Chicago':
        return `${citation.authors} ${citation.title}. ${citation.source}, ${citation.year}${citation.pages ? `, ${citation.pages}` : ''}.`;
      case 'Harvard':
        return `${citation.authors} ${citation.year}. ${citation.title}. ${citation.source}${citation.pages ? `, pp. ${citation.pages}` : ''}.`;
      default:
        return `${citation.authors} (${citation.year}). ${citation.title}. ${citation.source}.`;
    }
  };

  const getTitle = (): string => {
    switch (citationStyle) {
      case 'MLA':
        return 'Works Cited';
      case 'Chicago':
        return 'Bibliography';
      case 'APA':
      case 'Harvard':
      default:
        return 'References';
    }
  };

  const sortedCitations = [...citations].sort((a, b) => {
    const authorA = a.authors.split(',')[0].trim().toLowerCase();
    const authorB = b.authors.split(',')[0].trim().toLowerCase();
    return authorA.localeCompare(authorB);
  });

  const bibliographyText = `${getTitle()}\n\n${sortedCitations.map(c => formatFullCitation(c)).join('\n\n')}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(bibliographyText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([bibliographyText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${getTitle().toLowerCase().replace(' ', '_')}_${citationStyle.toLowerCase()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50 p-6">
      <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#D7D7D2]">
          <div>
            <h2 className="text-[#1C1C1C] mb-1">
              {getTitle()}
            </h2>
            <p className="text-[14px] text-[#1C1C1C]/60">
              Formatted in {citationStyle} style · {citations.length} {citations.length === 1 ? 'source' : 'sources'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#F5F5F2] rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#1C1C1C]/60" strokeWidth={1.5} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(80vh-180px)]">
          <div className="p-6 bg-[#F5F5F2] rounded-lg border border-[#D7D7D2]">
            <div className="text-center mb-6">
              <h3 className="text-[20px] text-[#1C1C1C]" style={{ fontWeight: 600 }}>
                {getTitle()}
              </h3>
            </div>
            
            <div className="space-y-4">
              {sortedCitations.map((citation, index) => (
                <div
                  key={citation.id}
                  className="text-[14px] text-[#1C1C1C] leading-relaxed"
                  style={{ 
                    textIndent: citationStyle === 'APA' || citationStyle === 'Harvard' ? '-2em' : '0',
                    paddingLeft: citationStyle === 'APA' || citationStyle === 'Harvard' ? '2em' : '0'
                  }}
                >
                  {formatFullCitation(citation)}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-6 border-t border-[#D7D7D2]">
          <div className="text-[13px] text-[#1C1C1C]/60">
            Tip: Copy and paste into your document
          </div>
          <div className="flex gap-3">
            <YooniButton variant="secondary" onClick={handleDownload}>
              <Download className="w-4 h-4 mr-2" strokeWidth={1.5} />
              Download
            </YooniButton>
            <YooniButton variant="primary" onClick={handleCopy}>
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-2" strokeWidth={1.5} />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" strokeWidth={1.5} />
                  Copy All
                </>
              )}
            </YooniButton>
          </div>
        </div>
      </div>
    </div>
  );
}
