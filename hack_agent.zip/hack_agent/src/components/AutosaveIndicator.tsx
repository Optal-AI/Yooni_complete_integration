import React, { useEffect, useState } from 'react';
import { Check, Cloud } from 'lucide-react';

interface AutosaveIndicatorProps {
  isSaving: boolean;
  lastSaved: Date | null;
}

export function AutosaveIndicator({ isSaving, lastSaved }: AutosaveIndicatorProps) {
  const [timeAgo, setTimeAgo] = useState('');

  useEffect(() => {
    if (!lastSaved) return;

    const updateTimeAgo = () => {
      const seconds = Math.floor((Date.now() - lastSaved.getTime()) / 1000);
      
      if (seconds < 5) {
        setTimeAgo('Just now');
      } else if (seconds < 60) {
        setTimeAgo(`${seconds}s ago`);
      } else if (seconds < 3600) {
        const minutes = Math.floor(seconds / 60);
        setTimeAgo(`${minutes}m ago`);
      } else {
        const hours = Math.floor(seconds / 3600);
        setTimeAgo(`${hours}h ago`);
      }
    };

    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 1000);

    return () => clearInterval(interval);
  }, [lastSaved]);

  if (isSaving) {
    return (
      <div className="flex items-center gap-2 text-[13px] text-[#1C1C1C]/60">
        <Cloud className="w-4 h-4 animate-pulse" strokeWidth={1.5} />
        <span>Saving...</span>
      </div>
    );
  }

  if (lastSaved) {
    return (
      <div className="flex items-center gap-2 text-[13px] text-[#8BAA82]">
        <Check className="w-4 h-4" strokeWidth={1.5} />
        <span>Saved {timeAgo}</span>
      </div>
    );
  }

  return null;
}
