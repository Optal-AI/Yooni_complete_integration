/**
 * API Configuration
 * Central place to configure backend endpoints and settings
 */

// Backend API base URL
// Use proxy in development (Vite proxy at /api), direct URL in production or if env var is set
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || (import.meta.env.MODE === 'development' ? '' : 'http://localhost:5001');

export const API_CONFIG = {
  // Backend mode: 'mock' or 'production'
  MODE: 'production' as 'mock' | 'production',
  
  // API base URL
  BASE_URL: API_BASE_URL,
  
  // API endpoints (Flask backend)
  ENDPOINTS: {
    // Research - Flask backend endpoints
    UPLOAD_PAPER: `${API_BASE_URL}/api/evaluate-pdf`,
    EVALUATE_PAPER_URL: `${API_BASE_URL}/api/evaluate-paper`,
    FIND_PAPERS: `${API_BASE_URL}/api/find-papers`,
    GET_PAPERS: `${API_BASE_URL}/api/papers`, // For library
    DELETE_PAPER: `${API_BASE_URL}/api/papers/:id`,
    ANALYZE_RELEVANCE: `${API_BASE_URL}/api/evaluate-paper`,
    VISUALIZATION_DATA: `${API_BASE_URL}/api/visualization-data`,
    
    // Assignments
    ANALYZE_ASSIGNMENT: `${API_BASE_URL}/api/assignments/analyze`,
    IMPROVE_ASSIGNMENT: `${API_BASE_URL}/api/assignments/improve`,
    SUGGEST_PAPERS: `${API_BASE_URL}/api/assignments/suggest-papers`,
    SAVE_ASSIGNMENT: `${API_BASE_URL}/api/assignments/save`,
    
    // Writing Style
    UPLOAD_SAMPLE: `${API_BASE_URL}/api/writing-style/upload`,
    ANALYZE_STYLE: `${API_BASE_URL}/api/writing-style/analyze`,
    APPLY_STYLE: `${API_BASE_URL}/api/writing-style/apply`,
    
    // Citations
    FORMAT_CITATION: `${API_BASE_URL}/api/citations/format`,
    GENERATE_BIBLIOGRAPHY: `${API_BASE_URL}/api/citations/bibliography`,
    
    // Writing Projects & Rubrics
    UPLOAD_RUBRIC: `${API_BASE_URL}/api/upload-rubric`,
    EVALUATE_WRITING: `${API_BASE_URL}/api/evaluate-writing`,
    IMPROVE_WRITING: `${API_BASE_URL}/api/improve-writing`,
    DEFAULT_RUBRIC: `${API_BASE_URL}/api/default-rubric`,
  },
  
  // Feature flags
  FEATURES: {
    ENABLE_FILE_UPLOAD: true,
    ENABLE_AI_ANALYSIS: true,
    ENABLE_CITATIONS: true,
    ENABLE_WRITING_STYLE: true,
    ENABLE_BATCH_UPLOAD: true,
  },
  
  // Limits
  LIMITS: {
    MAX_FILE_SIZE_MB: 10,
    MAX_PAPERS_PER_TOPIC: 50,
    MAX_WRITING_SAMPLES: 10,
    MAX_ASSIGNMENT_LENGTH: 10000, // characters
  }
};

/**
 * Helper to check if we're in mock mode
 */
export const isMockMode = () => API_CONFIG.MODE === 'mock';

/**
 * Helper to get full endpoint URL
 */
export const getEndpoint = (key: keyof typeof API_CONFIG.ENDPOINTS, params?: Record<string, string>) => {
  let endpoint = API_CONFIG.ENDPOINTS[key];
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      endpoint = endpoint.replace(`:${key}`, value);
    });
  }
  
  return endpoint;
};
