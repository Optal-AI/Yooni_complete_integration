import React, { useState } from 'react';
import { YooniSidebar } from './components/YooniSidebar';
import { TodayPage } from './components/pages/TodayPage';
import { SearchPapersPage } from './components/pages/ResearchPage';
import { ResearchMatchPage } from './components/pages/ResearchMatchPage';
import { WritingProjectsPage } from './components/pages/WritingProjectsPage';
import { WritingProjectDetailPage } from './components/pages/WritingProjectDetailPage';
import { ProjectScorePage } from './components/pages/ProjectScorePage';
import { LibraryPage } from './components/pages/LibraryPage';
import { SettingsPage } from './components/pages/SettingsPage';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  const [activeTab, setActiveTab] = useState('today');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [scoringProjectId, setScoringProjectId] = useState<string | null>(null);
  const [improvedContent, setImprovedContent] = useState<string | null>(null);

  const handleOpenProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setScoringProjectId(null);
    setImprovedContent(null);
    setActiveTab('writing');
  };

  const handleCheckScore = (projectId: string) => {
    setScoringProjectId(projectId);
    setSelectedProjectId(null);
  };

  const handleBackToProjects = () => {
    setSelectedProjectId(null);
    setScoringProjectId(null);
    setImprovedContent(null);
  };

  const handleCheckScoreFromDetail = () => {
    if (selectedProjectId) {
      setScoringProjectId(selectedProjectId);
      setSelectedProjectId(null);
    }
  };

  const handleApplyImprovedContent = (content: string) => {
    setImprovedContent(content);
    setSelectedProjectId(scoringProjectId);
    setScoringProjectId(null);
  };

  const handleNavigateToTab = (tab: string) => {
    setActiveTab(tab);
    setSelectedProjectId(null);
    setScoringProjectId(null);
    setImprovedContent(null);
  };

  const renderPage = () => {
    // Handle Writing Projects sub-navigation
    if (activeTab === 'writing') {
      if (scoringProjectId) {
        // Get writing content and rubric from localStorage
        const writingContent = localStorage.getItem(`writing_content_${scoringProjectId}`) || '';
        const rubricContent = localStorage.getItem(`rubric_content_${scoringProjectId}`) || undefined;
        
        return (
          <ProjectScorePage 
            projectId={scoringProjectId} 
            onBack={handleBackToProjects}
            onApplyImprovedContent={handleApplyImprovedContent}
            writingContent={writingContent}
            rubricContent={rubricContent}
          />
        );
      }
      
      if (selectedProjectId) {
        return (
          <WritingProjectDetailPage 
            projectId={selectedProjectId} 
            onBack={handleBackToProjects}
            onCheckScore={handleCheckScoreFromDetail}
            improvedContent={improvedContent}
            onClearImprovedContent={() => setImprovedContent(null)}
          />
        );
      }

      return (
        <WritingProjectsPage 
          onOpenProject={handleOpenProject}
          onCheckScore={handleCheckScore}
        />
      );
    }

    // Other pages
    switch (activeTab) {
      case 'today':
        return <TodayPage onNavigate={handleNavigateToTab} onOpenProject={handleOpenProject} />;
      case 'research-match':
        return (
          <ErrorBoundary>
            <ResearchMatchPage />
          </ErrorBoundary>
        );
      case 'search-papers':
        return (
          <ErrorBoundary>
            <SearchPapersPage />
          </ErrorBoundary>
        );
      case 'library':
        return <LibraryPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <TodayPage onNavigate={handleNavigateToTab} onOpenProject={handleOpenProject} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F5F5F2]">
      <YooniSidebar activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="flex-1 overflow-auto">
        <div className="max-w-[1200px] mx-auto px-12 py-12">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}