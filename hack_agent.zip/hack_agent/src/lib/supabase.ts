/**
 * Supabase Client
 * Initialize and export Supabase client for use in services
 * 
 * USAGE:
 * 1. Install: npm install @supabase/supabase-js
 * 2. Add env variables to .env.local:
 *    NEXT_PUBLIC_SUPABASE_URL=your_project_url
 *    NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
 * 3. Uncomment the code below
 * 4. Import in services: import { supabase } from '../lib/supabase';
 */

// Uncomment when ready to use Supabase:

// import { createClient } from '@supabase/supabase-js';
// import { Database } from '../types/supabase'; // Generate with: npx supabase gen types typescript

// const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
// const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

// Helper functions for common operations
// export const supabaseHelpers = {
//   /**
//    * Get current user
//    */
//   async getCurrentUser() {
//     const { data: { user }, error } = await supabase.auth.getUser();
//     if (error) throw error;
//     return user;
//   },

//   /**
//    * Upload file to storage
//    */
//   async uploadFile(bucket: string, path: string, file: File) {
//     const { data, error } = await supabase.storage
//       .from(bucket)
//       .upload(path, file, {
//         cacheControl: '3600',
//         upsert: false
//       });
//     if (error) throw error;
//     return data;
//   },

//   /**
//    * Get public URL for file
//    */
//   getPublicUrl(bucket: string, path: string) {
//     const { data } = supabase.storage
//       .from(bucket)
//       .getPublicUrl(path);
//     return data.publicUrl;
//   },

//   /**
//    * Delete file from storage
//    */
//   async deleteFile(bucket: string, path: string) {
//     const { error } = await supabase.storage
//       .from(bucket)
//       .remove([path]);
//     if (error) throw error;
//   },

//   /**
//    * Call Edge Function
//    */
//   async callFunction<T = any>(functionName: string, body: any): Promise<T> {
//     const { data, error } = await supabase.functions.invoke(functionName, {
//       body
//     });
//     if (error) throw error;
//     return data as T;
//   }
// };

// Mock export for development (remove when Supabase is set up)
export const supabase = null;
export const supabaseHelpers = {
  async getCurrentUser() {
    return { id: 'mock-user-id', email: 'user@example.com' };
  },
  async uploadFile() {
    return { path: 'mock-path' };
  },
  getPublicUrl() {
    return 'mock-url';
  },
  async deleteFile() {
    return;
  },
  async callFunction<T = any>(): Promise<T> {
    throw new Error('Supabase not configured');
  }
};
