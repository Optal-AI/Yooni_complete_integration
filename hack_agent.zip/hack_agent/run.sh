#!/bin/bash

# Quick start script for Research Paper Evaluator

echo "🔬 Research Paper Evaluator - Starting..."
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚠️  Warning: .env file not found"
    echo "Please create a .env file with your OPENAI_API_KEY"
    echo "Example: echo 'OPENAI_API_KEY=your_key_here' > .env"
    echo ""
fi

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "🔌 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📥 Installing dependencies..."
pip install -q -r requirements.txt

# Start the Flask server
echo ""
echo "🚀 Starting Flask server..."
echo "📱 Open http://localhost:5000 in your browser"
echo "🛑 Press Ctrl+C to stop"
echo ""

python app.py

